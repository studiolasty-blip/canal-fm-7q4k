#!/usr/bin/env bash
# Instalador da Fábrica de Motion (skill para o Claude Code).
#
#   bash instalar.sh                 instala tudo e roda o teste
#   bash instalar.sh --sim           o mesmo, sem perguntar nada (é assim que o Claude roda)
#   bash instalar.sh --conferir      não instala nada: só confere se a instalação está funcionando
#   bash instalar.sh --pasta DIR     pasta de trabalho (padrão: ~/FabricaDeMotion)
#   bash instalar.sh --skills DIR    pasta de skills do Claude (padrão: ~/.claude/skills)
#   bash instalar.sh --sem-teste     pula o vídeo de teste
#
# Programas que faltarem (Node, ffmpeg, uv, Python) são instalados sem senha de administrador: pelo Homebrew, se você
# já tiver, ou baixados das fontes oficiais para a sua pasta pessoal (~/.local). Nada é instalado no sistema.
# Nunca apaga nem sobrescreve trabalho seu: arquivos que já existem na pasta de trabalho ficam como estão,
# e uma skill instalada antes é guardada numa cópia com a data.
set -u

AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PASTA="$HOME/FabricaDeMotion"; PASTA_DADA=0
SKILLS="$HOME/.claude/skills"
SIM=0; TESTE=1; SO_CONFERIR=0; SEM_CLAUDE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --pasta) PASTA="${2:?falta o caminho depois de --pasta}"; PASTA_DADA=1; shift 2 ;;
    --skills) SKILLS="${2:?falta o caminho depois de --skills}"; shift 2 ;;
    --sim) SIM=1; shift ;;
    --sem-teste) TESTE=0; shift ;;
    --conferir) SO_CONFERIR=1; shift ;;
    --sem-claude) SEM_CLAUDE=1; shift ;;
    -h|--help) sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Opção desconhecida: $1 (use --help)"; exit 2 ;;
  esac
done
case "$PASTA" in "~"*) PASTA="$HOME${PASTA#\~}" ;; esac
case "$SKILLS" in "~"*) SKILLS="$HOME${SKILLS#\~}" ;; esac
SKILL="$SKILLS/fabrica-de-motion"

if [ -t 1 ]; then V=$'\033[32m'; R=$'\033[31m'; A=$'\033[33m'; N=$'\033[1m'; Z=$'\033[0m'; else V=""; R=""; A=""; N=""; Z=""; fi
ok()    { echo "  ${V}ok${Z}     $*"; }
falha() { echo "  ${R}FALHOU${Z} $*"; ERROS=$((ERROS + 1)); }
aviso() { echo "  ${A}aviso${Z}  $*"; }
passo() { echo; echo "${N}$*${Z}"; }
ERROS=0
LOG="$(mktemp -t fabrica-de-motion.XXXXXX)"

perguntar() {  # perguntar "texto" → 0 se sim
  [ "$SIM" = 1 ] && return 0
  [ -t 0 ] || return 1
  printf "%s [S/n] " "$1"; read -r resp; case "$resp" in n|N|nao|não|Nao|Não) return 1 ;; *) return 0 ;; esac
}

# ───────── 1. programas necessários ─────────
passo "1. Programas necessários"
FALTAM=()
LOCAL="$HOME/.local/bin"                              # programas instalados só para você, sem senha de administrador
APOIO="$HOME/.local/share/fabrica-de-motion"
PATH_ANTES="$PATH"
[ -d "$LOCAL" ] && case ":$PATH:" in *":$LOCAL:"*) ;; *) PATH="$LOCAL:$PATH" ;; esac
tem() { command -v "$1" >/dev/null 2>&1; }
# no Mac sem as ferramentas de desenvolvedor, /usr/bin/python3 é só um aviso que abre uma janela de instalação
python_de_verdade() {
  tem python3 || return 1
  if [ "$(uname)" = "Darwin" ] && [ "$(command -v python3)" = "/usr/bin/python3" ]; then
    [ -n "${FM_TESTE_SEM_PYTHON:-}" ] && return 1                   # só para testar o instalador
    xcode-select -p >/dev/null 2>&1 || return 1
  fi
  return 0
}
conferir_programas() {
  FALTAM=()
  if tem node; then
    MAJOR="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
    if [ "$MAJOR" -ge 18 ]; then ok "Node $(node -v)"; else aviso "Node $(node -v) é antigo (precisa do 18 ou mais novo)"; FALTAM+=(node); fi
  else aviso "Node não encontrado (roda o projeto de vídeo)"; FALTAM+=(node); fi
  if tem ffmpeg && tem ffprobe; then ok "ffmpeg $(ffmpeg -version 2>/dev/null | head -1 | awk '{print $3}')"; else aviso "ffmpeg não encontrado (mixagem e conferência)"; FALTAM+=(ffmpeg); fi
  if tem uv; then ok "uv $(uv --version 2>/dev/null | awk '{print $2}')"; else aviso "uv não encontrado (roda os scripts de som)"; FALTAM+=(uv); fi
  if python_de_verdade; then ok "Python $(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:3])))')"; else aviso "python3 não encontrado (fichário de clientes)"; FALTAM+=(python); fi
}

# ── instalação sem senha: cada programa vem da fonte oficial, conferido pelo código de verificação quando ela publica um
TMPI="$(mktemp -d -t fabrica-instalar.XXXXXX)"
baixar() { curl -fL --retry 2 -sS -o "$2" "$1"; }
sha_ok() { [ -n "$2" ] && [ "$(shasum -a 256 "$1" 2>/dev/null | awk '{print $1}')" = "$2" ]; }
instalar_uv() {
  local alvo
  case "$(uname)-$(uname -m)" in
    Darwin-arm64) alvo=aarch64-apple-darwin ;; Darwin-x86_64) alvo=x86_64-apple-darwin ;;
    Linux-x86_64) alvo=x86_64-unknown-linux-gnu ;; Linux-aarch64) alvo=aarch64-unknown-linux-gnu ;; *) return 1 ;;
  esac
  local url="https://github.com/astral-sh/uv/releases/latest/download/uv-$alvo.tar.gz"
  baixar "$url" "$TMPI/uv.tgz" && baixar "$url.sha256" "$TMPI/uv.sha" && sha_ok "$TMPI/uv.tgz" "$(awk '{print $1}' "$TMPI/uv.sha")" \
    && tar -xzf "$TMPI/uv.tgz" -C "$TMPI" && cp "$TMPI/uv-$alvo/uv" "$TMPI/uv-$alvo/uvx" "$LOCAL/" && chmod +x "$LOCAL/uv" "$LOCAL/uvx"
}
instalar_node() {
  local so arq base linha nome
  case "$(uname)" in Darwin) so=darwin ;; Linux) so=linux ;; *) return 1 ;; esac
  case "$(uname -m)" in arm64|aarch64) arq=arm64 ;; x86_64) arq=x64 ;; *) return 1 ;; esac
  base="https://nodejs.org/dist/latest-v22.x"
  linha="$(curl -fsSL "$base/SHASUMS256.txt" | grep "node-v.*-$so-$arq\.tar\.gz$")" || return 1
  nome="${linha##* }"
  baixar "$base/$nome" "$TMPI/$nome" && sha_ok "$TMPI/$nome" "${linha%% *}" || return 1
  mkdir -p "$APOIO" && rm -rf "$APOIO/node" "$APOIO/${nome%.tar.gz}" && tar -xzf "$TMPI/$nome" -C "$APOIO" && mv "$APOIO/${nome%.tar.gz}" "$APOIO/node" || return 1
  for b in node npm npx; do ln -sf "$APOIO/node/bin/$b" "$LOCAL/$b"; done
}
instalar_ffmpeg() {   # precisa do Node: os pacotes ffmpeg-static e ffprobe-static trazem os programas prontos
  tem npm || return 1
  mkdir -p "$APOIO/ffmpeg" && (cd "$APOIO/ffmpeg" && { [ -f package.json ] || echo '{"name":"ffmpeg-local","private":true}' > package.json; } \
    && npm install --no-audit --no-fund ffmpeg-static ffprobe-static >"$LOG" 2>&1) || return 1
  local f p
  f="$(cd "$APOIO/ffmpeg" && node -p 'require("ffmpeg-static")' 2>/dev/null)"; p="$(cd "$APOIO/ffmpeg" && node -p 'require("ffprobe-static").path' 2>/dev/null)"
  [ -x "$f" ] && [ -x "$p" ] || return 1
  local raiz="$APOIO/ffmpeg/node_modules/ffprobe-static/bin" so arq d
  so="$(basename "$(dirname "$(dirname "$p")")")"; arq="$(basename "$(dirname "$p")")"
  if [ -d "$raiz/$so/$arq" ]; then
    for d in "$raiz"/*; do [ "$(basename "$d")" = "$so" ] || rm -rf "$d"; done
    for d in "$raiz/$so"/*; do [ "$(basename "$d")" = "$arq" ] || rm -rf "$d"; done
  fi
  ln -sf "$f" "$LOCAL/ffmpeg" && ln -sf "$p" "$LOCAL/ffprobe"
}
instalar_python() {   # precisa do uv
  tem uv || return 1
  uv python install 3.12 >"$LOG" 2>&1 || return 1
  local py; py="$(uv python find 3.12 2>/dev/null)"
  [ -x "$py" ] && ln -sf "$py" "$LOCAL/python3"
}
instalar_sem_senha() {
  mkdir -p "$LOCAL" "$APOIO" || return 1
  case ":$PATH:" in *":$LOCAL:"*) ;; *) PATH="$LOCAL:$PATH" ;; esac
  # a ordem importa: o ffmpeg vem pelo Node e o Python vem pelo uv
  for prog in uv node ffmpeg python; do
    case " ${FALTAM[*]} " in *" $prog "*) ;; *) continue ;; esac
    echo "  baixando ${prog}…"
    if "instalar_$prog"; then ok "$prog instalado em $LOCAL"; else aviso "não consegui instalar $prog sozinho"; fi
  done
  hash -r 2>/dev/null
}
# quem instalou algo em ~/.local/bin precisa dessa pasta no caminho das próximas janelas de terminal e do Claude
garantir_caminho() {
  case ":$PATH_ANTES:" in *":$LOCAL:"*) return 0 ;; esac
  local linha='export PATH="$HOME/.local/bin:$PATH"  # Fábrica de Motion' f
  for f in "$HOME/.zprofile" "$HOME/.zshrc" "$HOME/.bash_profile"; do
    [ "$f" = "$HOME/.bash_profile" ] && [ ! -f "$f" ] && continue
    grep -qs 'Fábrica de Motion' "$f" || printf '\n%s\n' "$linha" >> "$f"
  done
  REABRIR=1
}
REABRIR=0

# espaço em disco: com o disco cheio os downloads saem corrompidos e o erro aparece longe da causa
LIVRE_KB="$(df -Pk "$HOME" 2>/dev/null | awk 'NR==2 {print $4}')"; LIVRE_KB="${LIVRE_KB:-99999999}"
if [ "$SO_CONFERIR" = 0 ] && [ -z "${FM_IGNORAR_ESPACO:-}" ]; then
  if [ "$LIVRE_KB" -lt 1048576 ]; then
    echo "${R}Há menos de 1 GB livre no disco da sua pasta pessoal.${Z} A instalação usa uns 5 GB. Libere espaço e rode de novo."; exit 1
  elif [ "$LIVRE_KB" -lt 5242880 ]; then aviso "há só $((LIVRE_KB / 1048576)) GB livres no disco; a instalação usa uns 5 GB e pode faltar espaço"; fi
fi

conferir_programas
if [ ${#FALTAM[@]} -gt 0 ]; then
  if [ "$SO_CONFERIR" = 1 ]; then
    falha "faltam programas: ${FALTAM[*]}"
  else
    echo; echo "  Faltam: ${FALTAM[*]}"
    if tem brew && perguntar "  Instalar agora com o Homebrew (brew install ${FALTAM[*]})?"; then
      brew install "${FALTAM[@]}" || true
      echo; conferir_programas
    fi
    if [ ${#FALTAM[@]} -gt 0 ]; then
      if perguntar "  Baixar ${FALTAM[*]} das fontes oficiais para a sua pasta pessoal ($LOCAL), sem senha de administrador?"; then
        instalar_sem_senha; garantir_caminho
        echo; conferir_programas
      elif [ ! -t 0 ]; then
        echo "  (sem ninguém para responder: rode de novo com --sim para instalar o que falta)"
      fi
    fi
    if [ ${#FALTAM[@]} -gt 0 ]; then
      echo; echo "${R}Ainda faltam: ${FALTAM[*]}.${Z}"
      echo "Instale e rode este instalador de novo. No Mac, o caminho mais simples é o Homebrew (https://brew.sh):"
      echo "  brew install ${FALTAM[*]}"
      exit 1
    fi
  fi
fi
CLAUDE_BIN="$(command -v claude 2>/dev/null || true)"; [ -z "$CLAUDE_BIN" ] && [ -x "$HOME/.local/bin/claude" ] && CLAUDE_BIN="$HOME/.local/bin/claude"
if [ -z "$CLAUDE_BIN" ] && [ "$SO_CONFERIR" = 0 ] && [ "$SEM_CLAUDE" = 0 ] && tem npm; then
  echo "  instalando o Claude Code de terminal (é ele que responde dentro do painel)…"
  if npm install -g --prefix "$HOME/.local" --no-audit --no-fund @anthropic-ai/claude-code >"$LOG" 2>&1 && [ -x "$HOME/.local/bin/claude" ]; then
    CLAUDE_BIN="$HOME/.local/bin/claude"; mkdir -p "$LOCAL"; garantir_caminho
  else aviso "não consegui instalar o Claude Code de terminal — veja $LOG"; fi
fi
if [ -n "$CLAUDE_BIN" ]; then
  if "$CLAUDE_BIN" auth status >/dev/null 2>&1; then ok "Claude Code de terminal instalado e logado: a conversa ao vivo no painel vai funcionar"
  else FALTA_LOGIN=1; aviso "Claude Code de terminal instalado, mas ainda sem a sua conta: no painel, abra um cliente e clique em Conectar minha conta"; fi
else aviso "Claude Code de terminal não encontrado: o painel funciona no modo recado. Para a conversa ao vivo: npm install -g @anthropic-ai/claude-code"; fi

# ───────── 2. instalação ─────────
if [ "$SO_CONFERIR" = 0 ]; then
  passo "2. Instalação"
  # se já existe uma skill instalada e você não escolheu pasta, a pasta de trabalho dela é mantida
  if [ -f "$SKILL/config.json" ] && [ "$PASTA_DADA" = 0 ] && tem python3; then
    ANT="$(python3 -c 'import json,os,sys; c=json.load(open(sys.argv[1])); print(os.path.dirname(os.path.expanduser(c["template"])))' "$SKILL/config.json" 2>/dev/null || true)"
    [ -n "$ANT" ] && [ -d "$ANT" ] && { PASTA="$ANT"; aviso "já existe uma instalação; mantendo a pasta de trabalho $PASTA"; }
  fi
  mkdir -p "$PASTA/entregas" "$PASTA/clientes" "$PASTA/painel/fichas" "$PASTA/template" "$SKILLS" || { falha "não consegui criar $PASTA"; exit 1; }

  if [ -d "$SKILL" ]; then
    COPIA="$SKILLS/fabrica-de-motion.antes-$(date +%Y%m%d-%H%M%S)"
    cp -R "$SKILL" "$COPIA" && aviso "skill anterior guardada em $COPIA"
  fi
  mkdir -p "$SKILL" && cp -R "$AQUI/skill/." "$SKILL/" && ok "skill em $SKILL" || falha "não consegui copiar a skill para $SKILL"
  cat > "$SKILL/config.json" <<EOF
{
  "painel": "$PASTA/painel",
  "entregas": "$PASTA/entregas",
  "projetos": "$PASTA/clientes",
  "template": "$PASTA/template",
  "python": "$(command -v python3)"
}
EOF
  # reinstalação ou atualização: os ajustes que a pessoa fez no config antigo continuam valendo
  if [ -n "${COPIA:-}" ] && [ -f "$COPIA/config.json" ]; then
    if [ "$PASTA_DADA" = 0 ]; then python3 "$SKILL/ferramentas/juntar_config.py" "$SKILL/config.json" "$COPIA/config.json" --manter-caminhos 2>/dev/null
    else python3 "$SKILL/ferramentas/juntar_config.py" "$SKILL/config.json" "$COPIA/config.json" 2>/dev/null; fi
  fi
  # das cópias antigas da skill ficam só as duas mais recentes
  ls -d "$SKILLS"/fabrica-de-motion.antes-* 2>/dev/null | sort -r | tail -n +3 | while IFS= read -r velha; do rm -rf "$velha"; done

  # projeto de vídeo e painel: só entram os arquivos que ainda não existem
  if tem rsync; then
    rsync -a --ignore-existing --exclude node_modules --exclude out "$AQUI/template/" "$PASTA/template/" && ok "projeto de vídeo em $PASTA/template" || falha "não consegui copiar o projeto de vídeo"
    rsync -a --ignore-existing "$AQUI/painel/" "$PASTA/painel/" && ok "painel em $PASTA/painel" || falha "não consegui copiar o painel"
  else
    cp -Rn "$AQUI/template/." "$PASTA/template/" 2>/dev/null; cp -Rn "$AQUI/painel/." "$PASTA/painel/" 2>/dev/null
    ok "projeto de vídeo e painel em $PASTA"
  fi
  mkdir -p "$PASTA/template/out" "$PASTA/template/audio" "$PASTA/template/public"
  [ -f "$PASTA/painel/clientes.json" ] || echo "[]" > "$PASTA/painel/clientes.json"
  # o programa do painel é sempre atualizado; os dados (clientes, conversas, anexos, ajustes) nunca são tocados
  for f in servidor.mjs motor.mjs regras.mjs aprovador.mjs index.html isolado.json painel.mjs painel.sh logo-fabrica.png; do
    [ -f "$AQUI/painel/$f" ] && cp -f "$AQUI/painel/$f" "$PASTA/painel/$f"
  done
  chmod +x "$PASTA/painel/painel.sh" 2>/dev/null
  # atalho de dois cliques: liga o painel em segundo plano e abre a página
  ATALHO="$PASTA/Abrir Painel.command"
  printf '%s\n' '#!/bin/bash' '# Dois cliques: liga o painel da Fábrica de Motion (se ainda não estiver no ar) e abre a página.' 'exec "$(dirname "$0")/painel/painel.sh" abrir' > "$ATALHO"
  chmod +x "$ATALHO" && ok "atalho criado: $ATALHO"
  # o macOS marca o que veio de um zip baixado; sem a marca, o painel e a skill abrem sem aviso
  tem xattr && xattr -dr com.apple.quarantine "$PASTA/painel" "$SKILL" "$ATALHO" 2>/dev/null

  # referências que vêm com a skill (vídeos de exemplo autorizados): entram na aba Referências do painel
  if [ -f "$AQUI/referencias/referencias.json" ]; then
    if R="$(python3 "$SKILL/ferramentas/referencias.py" "$AQUI" "$PASTA" 2>"$LOG")"; then ok "$R"; else aviso "não consegui instalar as referências — veja $LOG"; fi
  fi
  # modelos que deixaram de vir com a skill: saem das instalações antigas (roda também na atualização, que vem sem vídeos)
  if [ -f "$SKILL/ferramentas/retirar-modelos.py" ]; then
    if MSG_RET="$(python3 "$SKILL/ferramentas/retirar-modelos.py" "$PASTA" 2>"$LOG")"; then ok "$MSG_RET"; else aviso "não consegui retirar os modelos antigos — veja $LOG"; fi
  fi

  echo "  instalando as dependências do projeto de vídeo (alguns minutos na primeira vez)…"
  if (cd "$PASTA/template" && npm install --no-audit --no-fund >"$LOG" 2>&1); then ok "dependências instaladas"; else falha "npm install — veja $LOG"; fi
else
  passo "2. Instalação (só conferindo)"
  if [ -f "$SKILL/config.json" ] && tem python3; then
    PASTA="$(python3 -c 'import json,os,sys; c=json.load(open(sys.argv[1])); print(os.path.dirname(os.path.expanduser(c["template"])))' "$SKILL/config.json" 2>/dev/null || echo "$PASTA")"
  fi
fi

# ───────── 3. conferência ─────────
passo "3. Conferência"
[ -f "$SKILL/SKILL.md" ] && ok "skill instalada ($SKILL)" || falha "skill não encontrada em $SKILL"
[ -f "$SKILL/config.json" ] && ok "config.json aponta para $PASTA" || falha "config.json não encontrado"
[ -d "$PASTA/template/node_modules/remotion" ] && ok "projeto de vídeo com dependências" || falha "projeto de vídeo sem dependências em $PASTA/template"

# O FFmpeg que vem com o Remotion 4.0.439+ foi compilado para macOS 15: no macOS 13–14 o render falha no fim
# ("built for macOS 15.0 which is newer than running OS"). O pacote 4.0.438 traz o mesmo FFmpeg 7.1 compilado
# para macOS 13; trocamos só o FFmpeg e as bibliotecas dele, o resto do Remotion continua o mesmo.
ffmpeg_para_mac_antigo() {
  local maior arq C D f
  maior="$(sw_vers -productVersion 2>/dev/null | cut -d. -f1)"
  case "$(uname -m)" in arm64) arq=arm64 ;; *) arq=x64 ;; esac
  C="$PASTA/template/node_modules/@remotion/compositor-darwin-$arq"
  [ -d "$C" ] && [ ! -f "$C/.fm-macos13" ] || return 0      # a marca some se o npm reinstalar o pacote: aí troca de novo
  D="$(mktemp -d)"
  (cd "$D" && npm pack "@remotion/compositor-darwin-$arq@4.0.438" --silent >"$LOG" 2>&1 && tar xzf ./*.tgz) || { rm -rf "$D"; return 1; }
  for f in ffmpeg ffprobe libavcodec.dylib libavdevice.dylib libavfilter.dylib libavformat.dylib libavutil.dylib libswresample.dylib libswscale.dylib; do
    cp "$D/package/$f" "$C/$f" || { rm -rf "$D"; return 1; }
  done
  rm -rf "$D"; echo "$maior" >"$C/.fm-macos13"
}
if [ "$(uname)" = "Darwin" ] && [ -d "$PASTA/template/node_modules/remotion" ]; then
  MAC_MAIOR="$(sw_vers -productVersion 2>/dev/null | cut -d. -f1)"
  if [ -n "$MAC_MAIOR" ] && [ "$MAC_MAIOR" -lt 13 ]; then
    falha "este Mac está no macOS $(sw_vers -productVersion): o Remotion precisa do macOS 13 (Ventura) ou mais novo. Atualize em Ajustes do Sistema → Atualização de Software"
  elif [ -n "$MAC_MAIOR" ] && [ "$MAC_MAIOR" -lt 15 ]; then
    if ffmpeg_para_mac_antigo; then ok "FFmpeg do Remotion ajustado para o macOS $(sw_vers -productVersion)"; else falha "não consegui ajustar o FFmpeg do Remotion para o macOS $(sw_vers -productVersion) — veja $LOG"; fi
  fi
fi
if python3 "$SKILL/cliente.py" lista >"$LOG" 2>&1; then ok "fichário de clientes responde"; else falha "fichário (cliente.py lista) — veja $LOG"; fi
[ -f "$PASTA/painel/servidor.mjs" ] && ok "painel pronto (dois cliques em Abrir Painel)" || falha "painel não encontrado em $PASTA/painel"

if [ "$TESTE" = 1 ] && [ "$ERROS" = 0 ]; then
  passo "4. Vídeo de teste (6 segundos, com som)"
  T="$PASTA/template"
  FINAL="$PASTA/entregas/Teste-da-instalacao.mp4"
  echo "  renderizando… (na primeira vez o Remotion baixa um navegador próprio, cerca de 90 MB)"
  rm -f "$T/out/teste.mp4" "$T/out/Teste-da-instalacao.mp4"       # sobra de uma instalação anterior não pode passar por vídeo novo
  LOGR="$TMPI/render.txt"; LIMITE="${FM_LIMITE_RENDER:-480}"
  # encerra um processo e tudo o que ele abriu (o render abre o Node e o navegador): nada fica rodando escondido
  matar_arvore() { local f; for f in $(pgrep -P "$1" 2>/dev/null); do matar_arvore "$f"; done; kill "$1" 2>/dev/null; sleep 0.2; kill -9 "$1" 2>/dev/null; }
  # o render roda com limite de tempo: se travar, é encerrado e o registro detalhado fica guardado.
  # Devolve 0 (saiu), 1 (falhou) ou 2 (travou).
  render_teste() {
    local pid passou=0
    rm -f "$T/out/teste.mp4"
    (cd "$T" && exec npx --no-install remotion render Demo out/teste.mp4 --color-space=bt709 --log verbose >"$LOGR" 2>&1) & pid=$!
    while kill -0 "$pid" 2>/dev/null; do
      sleep 2; passou=$((passou + 2))
      if [ "$passou" -ge "$LIMITE" ]; then matar_arvore "$pid"; return 2; fi
    done
    wait "$pid" && [ -s "$T/out/teste.mp4" ]
  }
  render_teste; RR=$?
  if [ "$RR" != 0 ]; then
    # causa mais comum: o navegador do Remotion baixado pela metade (instalação interrompida ou disco cheio). Baixa de novo.
    aviso "o vídeo de teste não saiu na primeira tentativa; baixando de novo o navegador do Remotion e tentando outra vez"
    cp "$LOGR" "$LOGR.primeira" 2>/dev/null; rm -rf "$T/node_modules/.remotion"
    render_teste; RR=$?
  fi
  if [ "$RR" = 0 ]; then ok "vídeo renderizado"
  elif [ "$RR" = 2 ]; then falha "o render do vídeo de teste travou (parado depois de $LIMITE s, nas duas tentativas). O registro detalhado está em $LOGR"; GUARDAR_TMP=1
  else falha "render do vídeo de teste — o registro detalhado está em $LOGR"; GUARDAR_TMP=1; fi
  if (cd "$T" && uv run --quiet --with numpy --with scipy python tools/make_audio_demo.py >"$LOG" 2>&1) && [ -s "$T/audio/demo-music.wav" ] && [ -s "$T/audio/demo-sfx.wav" ]; then ok "trilha e efeitos gerados"; else falha "som (tools/make_audio_demo.py) — veja $LOG"; fi
  if [ -s "$T/out/teste.mp4" ] && [ -s "$T/audio/demo-music.wav" ]; then
    if ffmpeg -v error -y -i "$T/out/teste.mp4" -i "$T/audio/demo-music.wav" -i "$T/audio/demo-sfx.wav" \
        -filter_complex "[1:a]volume=-4dB[m];[2:a]volume=-6dB[s];[m][s]amix=inputs=2:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11,alimiter=limit=0.84:level=false[a]" \
        -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 256k -shortest -movflags +faststart "$T/out/Teste-da-instalacao.mp4" >"$LOG" 2>&1 && [ -s "$T/out/Teste-da-instalacao.mp4" ]; then
      ok "vídeo e som juntos"
      python3 "$SKILL/ferramentas/conferir.py" "$T/out/Teste-da-instalacao.mp4" 2>&1 | sed 's/^/         /'
      cp -f "$T/out/Teste-da-instalacao.mp4" "$FINAL"
    else falha "mixagem com ffmpeg — veja $LOG"; fi
  fi
fi

[ "${GUARDAR_TMP:-0}" = 1 ] || rm -rf "$TMPI" 2>/dev/null
echo
if [ "$ERROS" = 0 ]; then
  echo "${V}${N}Tudo certo.${Z}"
  [ "$TESTE" = 1 ] && echo "Abra o vídeo de teste: $PASTA/entregas/Teste-da-instalacao.mp4"
  echo
  echo "Para começar:"
  [ "$REABRIR" = 1 ] && echo "  0. Feche e abra o Claude de novo (programas novos foram instalados em $LOCAL)."
  echo "  1. Abra o Claude Code na pasta $PASTA"
  echo "  2. Mande o material do primeiro cliente (logo, fotos, texto ou áudio) e diga o que ele pediu."
  echo "  3. Painel de clientes: dois cliques em \"$PASTA/Abrir Painel.command\" (ou diga ao Claude: abre o painel)"
  if [ "${FALTA_LOGIN:-0}" = 1 ]; then
    echo; echo "${A}Para o Claude responder dentro do painel (uma vez só): quem faz é a pessoa, não o Claude.${Z}"
    echo "  No painel, abra um cliente e clique em Conectar minha conta. O navegador abre a página do Claude: clique em Autorizar."
    echo "  Se o botão não abrir a página: abra o Terminal, cole a linha abaixo e aperte Enter:"
    echo "  \"$CLAUDE_BIN\" auth login"
  fi
  exit 0
else
  echo "${R}${N}$ERROS item(ns) falharam.${Z} Corrija o que está marcado acima e rode: bash instalar.sh --conferir"
  exit 1
fi
