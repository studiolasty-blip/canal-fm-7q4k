# Fábrica de Motion — instalação

Skill para o Claude Code que produz vídeos motion para clientes numa conversa só: roteiro, narração para o ElevenLabs,
animação, trilha e efeitos, conferência e entrega, com um fichário e um painel de clientes.

## O que você precisa ter

- Mac (testado em macOS com processador Apple) ou Windows 10/11. A versão para Windows é nova: se algo falhar na
  instalação, peça ao Claude para ler a mensagem e resolver. Linux não foi testado.
- O aplicativo do Claude com um plano que inclua o Claude Code.
- Internet e uns 5 GB livres (3 GB da instalação e até 2 GB do modelo de fala, baixado na primeira narração).
- Conta no ElevenLabs para as narrações (vídeo sem locução não precisa).

Node, ffmpeg, uv e Python não precisam estar instalados: o instalador confere e baixa o que faltar, das fontes
oficiais, para a sua pasta pessoal (`~/.local`), sem senha de administrador. Se você já usa o Homebrew, ele usa.

## Instalar

O jeito mais simples está no arquivo **COMECE-AQUI.html**: deixar o zip na pasta Downloads e colar uma frase no Claude.

Pelo Terminal, descompacte o zip e rode:

```bash
bash ~/Downloads/fabrica-de-motion/instalar.sh
```

No Windows, dê dois cliques em `Instalar.bat` (ou rode `powershell -ExecutionPolicy Bypass -File instalar.ps1`).

**Disco C: cheio (Windows).** Se o disco do sistema tiver menos de 6 GB livres e houver outro disco com espaço, o
instalador leva tudo para o outro disco sozinho: projeto, programas, caches e modelo de fala ficam em
`X:\FabricaDeMotion` (os programas e caches em `_sistema`). No disco do sistema fica só a skill, com menos de 1 MB.
Para escolher o disco você mesmo, acrescente `-Pasta D:\FabricaDeMotion`. O zip também pode ficar no outro disco:
basta dizer ao Claude onde ele está.

Leva uns 5 minutos na primeira vez. No fim ele renderiza um vídeo de teste de 6 segundos, com som, e mostra uma lista
de conferência. Se algo falhar, corrija o item indicado e rode `bash instalar.sh --conferir`. Quando ele instalar
programas, feche e abra o Claude de novo antes de começar.

## O que é instalado e onde

| O quê | Onde | Para quê |
|---|---|---|
| Skill | `~/.claude/skills/fabrica-de-motion` | O método que o Claude segue, o fichário e a ferramenta de conferência |
| Projeto de vídeo | `~/FabricaDeMotion/template` | Onde cada vídeo é montado (uma pasta por cliente) |
| Clientes | `~/FabricaDeMotion/clientes` | Material recebido e anotações de cada cliente |
| Entregas | `~/FabricaDeMotion/entregas/<Cliente>/` | Os vídeos prontos, uma pasta por cliente, com todas as versões |
| Painel | `~/FabricaDeMotion/painel` | Página com as empresas, o que falta em cada uma e a última entrega |
| Programas que faltavam | `~/.local/bin` e `~/.local/share/fabrica-de-motion` | Node, ffmpeg, uv e Python, só se não existiam |

Para usar outra pasta de trabalho: `bash instalar.sh --pasta /caminho/da/pasta`.

Para guardar as entregas por data (`entregas/<ano>/<mês>/Dia <dia>/<Cliente>/`) em vez de uma pasta por cliente, acrescente
`"pastas": "data"` ao `config.json` da skill. O painel continua mostrando tudo de cada cliente junto.

Rodar o instalador de novo é seguro: arquivos que já existem na pasta de trabalho não são alterados e a skill
instalada antes fica guardada numa cópia com a data.

## Começar

1. Abra o Claude Code na pasta `~/FabricaDeMotion`.
2. Mande o material do cliente (logo, fotos, texto, áudio ou link) e diga o que ele pediu.
3. O Claude devolve a leitura de tom, o roteiro e a narração. Grave a voz no ElevenLabs e mande o arquivo.
4. O vídeo sai em `entregas/`, com um relatório do que foi feito e do que falta o cliente responder.

Painel de clientes: dê dois cliques em **Abrir Painel** (arquivo `Abrir Painel.command`, na pasta `~/FabricaDeMotion`),
ou diga ao Claude "abre o painel". Ele liga em segundo plano e abre http://localhost:4310 no navegador. Não precisa
deixar nenhuma janela aberta: a que aparecer pode ser fechada. Depois de reiniciar o computador, é só abrir de novo.

Na primeira vez o macOS pode perguntar se você quer mesmo abrir o arquivo: confirme. Pelo terminal, o mesmo comando é:

```bash
~/FabricaDeMotion/painel/painel.sh abrir
```

No Windows o atalho é `Abrir Painel.bat`, e o comando é `node painel\painel.mjs abrir` dentro da pasta de trabalho.
A conversa ao vivo dentro do painel funciona nos dois sistemas (veja "Conversa ao vivo no painel", mais abaixo).

Os outros comandos são `estado`, `religar` (depois de atualizar ou trocar um ajuste) e `desligar`. Com vídeo em
produção, `religar` e `desligar` avisam e não interrompem o trabalho.

- **Novo cliente** (botão no topo): escreva o nome, e se quiser o que ele faz. O painel cria a ficha, a pasta de
  material e a pasta de entregas, e já abre a conversa desse cliente.
- Cada cliente aparece com o logo ao lado do nome. Peça ao Claude "guarde este logo como o do cliente" (ele roda
  `cliente.py logo <id> <arquivo>`). Sem logo, o painel usa a capa da última entrega.
- **Clientes** (tela inicial): um painel de controle. Em cima, quantos estão em produção agora, quantos esperam você e
  quantas entregas saíram hoje e na semana; embaixo, o gráfico das entregas dos últimos 14 dias, quem está em produção,
  quem espera você, as últimas entregas e todos os clientes.
- **Entregas** tem três telas. **Produção**: cada cliente num cartão, na coluna da fase em que está (Não começou, Em
  produção, Revisar, Concluído). Arraste o cartão para mudar de fase; o visto marca como feito. O filtro 📅 mostra só os
  clientes com movimento hoje, ontem ou nos últimos 7 ou 30 dias. **Relatório**: o resumo do dia, da semana e do mês.
  **Vídeos**: todos os vídeos entregues, do mais novo para o mais antigo, com as versões de cada um juntas.
- **Modelos**: cliente novo abre com vídeos modelo ao lado da conversa. Com a skill vêm 20 vídeos de exemplo,
  de clientes que autorizaram, marcados pelo nicho; os que você fizer entram na mesma lista. O `+` (ou arrastar o vídeo
  para a conversa) manda o modelo junto com a próxima mensagem; nos outros clientes, o botão Modelos mostra a mesma lista.
- **Visualizador**: na coluna à esquerda da conversa. Assim que o trabalho começa, ele mostra as prévias das cenas, ao
  vivo, e quando o trabalho termina troca sozinho para o vídeo pronto. O progresso do Claude fica num quadradinho que se
  atualiza sozinho; na conversa entram só as respostas.
- **Anexos**: cole (Cmd+V ou Ctrl+V) ou arraste fotos, áudios, vídeos e PDFs em qualquer lugar da tela do cliente.
- **Voz automática**: na engrenagem ⚙ (Configurações), cole a chave da API do ElevenLabs e, se quiser, o nome da voz padrão. Com a chave
  guardada, quando você manda o roteiro em texto o Claude grava a voz no ElevenLabs v3 (`voz.py`) e segue para o vídeo.
  A chave fica em `~/.config/fabrica-de-motion/`, fora das pastas de trabalho. Sem chave, ele espera o seu mp3.
- No computador, Enter envia a mensagem e Shift+Enter pula linha.

## Atualizações

Quando sai uma versão nova, o painel mostra uma faixa no topo com o que mudou e o botão **Atualizar**. Ele baixa só
o programa (menos de 1 MB), instala por cima e religa o painel. Clientes, vídeos, conversas e ajustes ficam como estão.
Também dá para pedir ao Claude: "atualize a Fábrica de Motion".

Para isso o painel consulta, de tempos em tempos, um endereço fixo na internet (está em `canal.txt`, na pasta da
skill). O pacote baixado é conferido por um código de verificação antes de instalar. Quem não quiser a consulta
pode apagar o `canal.txt`: a faixa deixa de aparecer e as atualizações voltam a ser pelo zip.

## Conversa ao vivo no painel

Se o Claude Code de terminal estiver instalado e logado neste computador, cada cliente ganha no painel uma conversa
direta com o Claude: você escreve ali, ele responde ali e o vídeo pronto aparece no balão.

O Claude trabalha sem pedir permissão: lê sites, Instagram e bancos de imagens, baixa o que precisa, grava nas pastas
de trabalho e roda o render direto, sem nenhum cartão na tela.

- Continuam recusadas, sem pergunta, só as travas fixas: `sudo` (ou poder de administrador no Windows), arquivos de
  senha ou chave, e apagar fora das pastas de trabalho. Quando uma delas aparece, o painel avisa na conversa e o
  trabalho segue sem aquilo.
- No Mac, os comandos rodam numa área isolada que só grava nas pastas de trabalho; o que precisa sair dela (baixar de
  um banco de imagens, por exemplo) sai sozinho.
- Atenção: o Claude lê material de clientes e páginas da internet, e nesse modo ninguém confere cada passo. Se
  preferir conferir, crie `painel/motor.json` com `{ "perguntar": "arriscado" }` (cartão só para o que foge do
  trabalho normal, com Permitir, Permitir sempre e Negar) ou `{ "perguntar": "tudo" }` (cartão para cada gravação e
  comando), e religue o painel.
- Dá para parar o trabalho a qualquer momento pelo botão Parar.

O Claude Code de terminal precisa estar conectado à sua conta do Claude. É uma vez só: na tela de um cliente, o botão
**Conectar minha conta** abre a página do Claude no navegador, e lá é só clicar em Autorizar. Quem autoriza é você;
o painel não vê nem guarda a senha.

Sem o Claude Code de terminal, ou antes de conectar a conta, a mesma caixa funciona como recado: o texto fica guardado e você pede ao Claude, na
conversa principal, para ler os recados.
