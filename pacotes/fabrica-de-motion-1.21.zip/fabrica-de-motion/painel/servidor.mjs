// Painel de clientes da Fábrica de Motion: uma aba por empresa, com a conversa resumida, as pendências e as entregas.
// Serve esta pasta em / e os arquivos de ../entregas em /entregas/ (com Range, para o vídeo poder avançar).
// /api/clientes junta clientes.json com os arquivos de ../entregas (pelo prefixo do nome) e as anotações de cada projeto.
// /thumb/<arquivo>.jpg devolve um quadro do vídeo (feito com ffmpeg na primeira vez e guardado em .thumbs).
// POST /api/cliente cria um cliente novo (nome e, se quiser, o que ele faz) chamando o cliente.py da skill.
// GET /api/atualizacao diz se há versão nova (consulta o endereço da skill); POST /api/atualizar baixa, instala e religa.
// GET/POST /api/voz diz se a chave do ElevenLabs está guardada e guarda a chave e a voz padrão (usadas por voz.py).
// POST /api/recado guarda em caixa.json o que foi escrito na conversa de um cliente; quem lê é o Claude (cliente.py caixa).
// POST /api/anexo guarda em anexos/<cliente>/ a foto, o áudio ou o vídeo colado na conversa (até 300 MB por arquivo).
// /api/chat liga a conversa de cada cliente a uma sessão supervisionada do Claude Code (motor.mjs): área isolada e
// pedido de permissão no painel para gravar arquivo ou sair dela. /api/aprovar recebe esses pedidos do aprovador.mjs.
// Entregas: as novas ficam numa pasta por cliente (config.json → "entregas", subpasta = campo "pasta" do cliente) e são
// servidas em /e/<pasta>/<arquivo>; as antigas, soltas numa pasta só e achadas pelo prefixo do nome, em /entregas/.
// Não altera entregas nem fichas. uso: node servidor.mjs [porta]
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";
import { execFile, spawn } from "node:child_process";
import crypto from "node:crypto";
import { iniciarMotor, motorInfo, conferirLogin, iniciarLogin, estadoLogin, codigoLogin, lerChat, enviarMensagem, parar, pedirPermissao, decidir, esquecerPermissoes, retomarInterrompidas } from "./motor.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const CONF = (() => { try { return JSON.parse(fs.readFileSync(path.join(HERE, "config.json"), "utf8")); } catch { return {}; } })();
const casa = (p) => p.replace(/^~(?=\/|$)/, os.homedir());
const ENTREGAS = CONF.entregasAntigas ? casa(CONF.entregasAntigas) : path.resolve(HERE, "..", "entregas");   // soltas, pelo prefixo
const NOVAS = CONF.entregas ? casa(CONF.entregas) : ENTREGAS;                                                  // uma subpasta por cliente
const THUMBS = path.join(HERE, ".thumbs");
const CAIXA = path.join(HERE, "caixa.json");
const ANEXOS = path.join(HERE, "anexos");
const LIMITE = 300 * 1024 * 1024;
const PORTA = Number(process.argv[2] ?? process.env.PORT ?? 4310);
const SENHA = crypto.randomBytes(18).toString("hex");   // só a página servida por este processo e o aprovador que ele abre conhecem
iniciarMotor({ porta: PORTA, senha: SENHA });
conferirLogin();
retomarInterrompidas();
// um erro inesperado numa conversa não pode derrubar o painel inteiro
process.on("uncaughtException", (e) => console.error("erro não tratado:", e?.stack ?? e));
process.on("unhandledRejection", (e) => console.error("promessa rejeitada:", e?.stack ?? e));
const anexoInfo = (a) => ({ url: a, nome: path.basename(a).replace(/^\d+-/, ""), tipo: tipoDe(a) });
const lerCorpo = (req, feito) => { let c = ""; req.on("data", (d) => { c += d; if (c.length > 60000) req.destroy(); }); req.on("end", () => { try { feito(JSON.parse(c || "{}")); } catch { feito(null); } }); };
const origemOk = (req) => { const o = req.headers.origin ?? ""; return !o || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o); };
const tipoDe = (nome) => { const t = TIPOS[path.extname(nome).toLowerCase()] ?? ""; return t.startsWith("image/") ? "imagem" : t.startsWith("audio/") ? "audio" : t.startsWith("video/") ? "video" : "arquivo"; };
const lerCaixa = () => { try { return JSON.parse(fs.readFileSync(CAIXA, "utf8")); } catch { return []; } };
// acha um programa: primeiro o que o instalador pôs na pasta pessoal (~/.local/bin), depois os lugares usuais do sistema.
// No Windows os programas terminam em .exe e o Python se chama python.
const BIN = (nome) => {
  const nomes = process.platform === "win32" ? [nome + ".exe", ...(nome === "python3" ? ["python.exe"] : [])] : [nome];
  const pastas = [path.join(os.homedir(), ".local", "bin"), ...(process.platform === "win32" ? [] : ["/opt/homebrew/bin", "/usr/local/bin", "/usr/bin"])];
  for (const d of pastas) for (const n of nomes) { const p = path.join(d, n); if (fs.existsSync(p)) return p; }
  return process.platform === "win32" && nome === "python3" ? "python" : nome;
};
const MIDIA = { ".mp4": "video", ".mov": "video", ".png": "imagem", ".jpg": "imagem", ".jpeg": "imagem", ".webp": "imagem" };
const TIPOS = { ".mp4": "video/mp4", ".mov": "video/quicktime", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".md": "text/plain; charset=utf-8", ".txt": "text/plain; charset=utf-8", ".zip": "application/zip", ".webm": "video/webm", ".gif": "image/gif", ".heic": "image/heic", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4", ".aac": "audio/aac", ".ogg": "audio/ogg", ".opus": "audio/ogg", ".pdf": "application/pdf" };

// arquivos de uma pasta; `pasta` vazio = a pasta antiga (soltos), senão o caminho da pasta do cliente dentro de NOVAS:
// "<Cliente>" ou, na organização por data, "<ano>/<mês>/<dia>/<Cliente>"
// acha o Python de verdade. Ordem: o que o instalador anotou no config.json da skill; no Windows, um python.exe nas
// pastas de programas (nunca o atalho da loja da Microsoft, em WindowsApps) ou o que está dentro do atalho .cmd criado
// pelo instalador; por fim o python3 do sistema.
function acharPython({ plataforma = process.platform, casa = os.homedir(), caminho = process.env.PATH ?? process.env.Path ?? "", aqui = HERE } = {}) {
  try { const c = JSON.parse(fs.readFileSync(path.join(casa, ".claude", "skills", "fabrica-de-motion", "config.json"), "utf8")); if (c.python && fs.existsSync(c.python)) return c.python; } catch {}
  if (plataforma !== "win32") return BIN("python3");
  const pastas = [path.join(casa, ".local", "bin"), path.join(aqui, "..", "_sistema", "bin"), ...caminho.split(";")].filter((d) => d && !/WindowsApps/i.test(d));
  for (const d of pastas) for (const n of ["python3.exe", "python.exe"]) { const p = path.join(d, n); if (fs.existsSync(p)) return p; }
  for (const d of pastas) for (const n of ["python3.cmd", "python.cmd"]) {
    try { const m = /"([^"]+\.exe)"/i.exec(fs.readFileSync(path.join(d, n), "utf8")); if (m && fs.existsSync(m[1])) return m[1]; } catch {}
  }
  return "python";
}
// atualizações: quem consulta e instala é o atualizar.py da skill; o painel só pergunta e manda fazer
const SKILL_DIR = path.join(os.homedir(), ".claude", "skills", "fabrica-de-motion");
const ESTADO_AT = path.join(HERE, ".atualizacao.json");
let cacheAt = { quando: 0, dados: { tem: false } };
function consultarAtualizacao(feito, forcar) {
  const py = path.join(SKILL_DIR, "atualizar.py");
  if (!fs.existsSync(py) || !fs.existsSync(path.join(SKILL_DIR, "canal.txt"))) return feito({ tem: false });
  if (!forcar && Date.now() - cacheAt.quando < 20 * 60 * 1000) return feito(cacheAt.dados);
  execFile(acharPython(), [py, "--ver", "--json"], { timeout: 30000, env: { ...process.env, PYTHONUTF8: "1", PYTHONIOENCODING: "utf-8" } }, (e, saida) => {
    let d = { tem: true, erro: "Não consegui consultar as atualizações." };
    try { d = JSON.parse(String(saida).trim().split("\n").pop()); } catch {}
    cacheAt = { quando: Date.now(), dados: d }; feito(d);
  });
}
function listar(dir, pasta) {
  if (!fs.existsSync(dir)) return [];
  const rel = pasta.split("/").map(encodeURIComponent).join("/");
  const base = pasta ? "/e/" + rel + "/" : "/entregas/", bt = pasta ? "/t/" + rel + "/" : "/thumb/";
  return fs.readdirSync(dir).filter((n) => !n.startsWith(".")).map((n) => {
    let st; try { st = fs.statSync(path.join(dir, n)); } catch { return null; }
    const tipo = MIDIA[path.extname(n).toLowerCase()] ?? "arquivo";
    return st.isFile() && (tipo !== "arquivo" || !pasta) ? { nome: n, url: base + encodeURIComponent(n), thumb: tipo === "video" ? bt + encodeURIComponent(n) + ".jpg" : undefined, tipo, tamanho: st.size, mtime: st.mtimeMs / 1000 } : null;
  }).filter(Boolean);
}
const arquivos = () => listar(ENTREGAS, "");
// pastas por data: <entregas>/<ano>/<mês>/Dia <dia>/<Cliente>/ — devolve, para cada cliente, os caminhos em que ele aparece
function pastasPorData() {
  const mapa = {};
  const dirs = (d) => { try { return fs.readdirSync(d, { withFileTypes: true }).filter((e) => e.isDirectory() && !e.name.startsWith(".")).map((e) => e.name); } catch { return []; } };
  for (const ano of dirs(NOVAS).filter((n) => /^\d{4}$/.test(n))) for (const mes of dirs(path.join(NOVAS, ano))) for (const dia of dirs(path.join(NOVAS, ano, mes)).filter((n) => /^(Dia )?\d{2}$/.test(n)))
    for (const cli of dirs(path.join(NOVAS, ano, mes, dia))) (mapa[cli] ??= []).push([ano, mes, dia, cli].join("/"));
  return mapa;
}
// separa "<Cliente>/<arquivo>" ou "<ano>/<mês>/<dia>/<Cliente>/<arquivo>" e confere que a pasta é mesmo de um cliente
function caminhoNovo(resto) {
  const s = resto.split("/"), arq = s.pop() ?? "";
  const formato = s.length === 1 || (s.length === 4 && /^\d{4}$/.test(s[0]) && /^\d{2} - \p{L}+$/u.test(s[1]) && /^(Dia )?\d{2}$/.test(s[2]));
  if (!formato || !arq || !pastaValida(s.at(-1))) return null;
  const dir = path.resolve(NOVAS, ...s), p = path.resolve(dir, arq);
  return path.dirname(p) === dir ? { dir, p, rel: s.join("/") } : null;
}
const pastaValida = (pasta) => { try { return JSON.parse(fs.readFileSync(path.join(HERE, "clientes.json"), "utf8")).some((c) => c.pasta === pasta); } catch { return false; } };
const VOZ = path.join(os.homedir(), ".config", "fabrica-de-motion", "elevenlabs.json");
const lerVoz = () => { try { return JSON.parse(fs.readFileSync(VOZ, "utf8")); } catch { return {}; } };
function dados() {
  const arq = path.join(HERE, "clientes.json");
  const clientes = fs.existsSync(arq) ? JSON.parse(fs.readFileSync(arq, "utf8")) : [];
  const files = arquivos();
  const usados = new Set();
  const caixa = lerCaixa().filter((r) => !r.lida);
  const porData = pastasPorData();
  // destaques.json: nomes dos vídeos escolhidos como os melhores, na ordem; aparecem primeiro na aba Referências
  let destaques = []; try { destaques = JSON.parse(fs.readFileSync(path.join(HERE, "destaques.json"), "utf8")); } catch {}
  // cada item é o nome do arquivo ou { arquivo, rotulo }: o rótulo (o nicho, por exemplo) aparece no lugar do nome do cliente
  const marcar = (f) => { const i = destaques.findIndex((d) => (d?.arquivo ?? d) === f.nome); if (i >= 0) { f.destaque = i + 1; if (destaques[i]?.rotulo) f.rotulo = String(destaques[i].rotulo).slice(0, 60); } return f; };
  for (const c of clientes) {
    c.recados = caixa.filter((r) => r.id === c.id).map((r) => ({ texto: r.texto, quando: r.quando, anexos: (r.anexos ?? []).map(anexoInfo) }));
    const antigas = files.filter((f) => (c.prefixos ?? []).some((px) => f.nome.startsWith(px)));
    antigas.forEach((f) => usados.add(f.nome));
    const novas = c.pasta ? [c.pasta, ...(porData[c.pasta] ?? [])].flatMap((rel) => listar(path.join(NOVAS, ...rel.split("/")), rel)) : [];
    c.entregas = [...novas, ...antigas].map(marcar).sort((a, b) => b.mtime - a.mtime);
    if (c.logo) { try { c.logo = "/logos/" + encodeURIComponent(c.logo) + "?v=" + Math.round(fs.statSync(path.join(HERE, "logos", c.logo)).mtimeMs); } catch { c.logo = null; } }
    c.notas_texto = "";
    for (const n of c.notas ?? []) {
      const p = n.replace(/^~/, os.homedir());
      try { c.notas_texto += fs.readFileSync(p, "utf8").trim() + "\n\n"; } catch {}
    }
  }
  const grupos = {};
  for (const f of files) {
    if (usados.has(f.nome) || f.tipo === "arquivo") continue;
    const chave = f.nome.split(/-(?:v\d|\d+s|\d+x|anuncio|motion|previa|vertical|horizontal|promo|Estilo|\d)/)[0].replace(/\.\w+$/, "").replaceAll("-", " ");
    (grupos[chave] ??= []).push(f);
  }
  const outros = Object.keys(grupos).sort().map((k) => ({ id: "o-" + k.toLowerCase().replace(/\W+/g, "-"), nome: k, grupo: "Outras entregas", status: "entregue", nicho: "", resumo: "Entregas de conversas anteriores. Sem histórico registrado neste painel.", pendencias: [], conversa: [], entregas: grupos[k].map(marcar).sort((a, b) => b.mtime - a.mtime), notas_texto: "" }));
  return [...clientes, ...outros];
}
const servidor = http.createServer((req, res) => {
  const caminho = decodeURIComponent(req.url.split("?")[0]);
  const enviar = (status, tipo, corpo) => { res.writeHead(status, { "Content-Type": tipo, "Cache-Control": "no-store" }); res.end(corpo); };
  try {
    if (caminho === "/api/cliente" && req.method === "POST") {
      // botão "Novo cliente": cria a ficha pelo mesmo cliente.py que o Claude usa (pasta de material, anotações e pasta de entregas)
      if (!origemOk(req) || req.headers["x-fm"] !== SENHA) return enviar(403, "text/plain", "origem recusada");
      return lerCorpo(req, (b) => {
        const limpar = (v, max) => String(v ?? "").replace(/[\u0000-\u001f]+/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
        const nome = limpar(b?.nome, 80), nicho = limpar(b?.nicho, 160);
        if (nome.length < 2) return enviar(400, "text/plain; charset=utf-8", "Escreva o nome do cliente.");
        const py = path.join(os.homedir(), ".claude", "skills", "fabrica-de-motion", "cliente.py");
        if (!fs.existsSync(py)) return enviar(500, "text/plain; charset=utf-8", "A skill fabrica-de-motion não está instalada neste computador.");
        execFile(acharPython(), [py, "novo", "--nicho=" + nicho, "--", nome], { timeout: 20000, env: { ...process.env, PYTHONUTF8: "1", PYTHONIOENCODING: "utf-8" } }, (e, saida, erro) => {
          if (e && (e.code === "ENOENT" || /Microsoft Store|n.o foi encontrado|not found/i.test(String(erro)))) return enviar(500, "text/plain; charset=utf-8", "O painel não achou o Python neste computador. Rode o instalador de novo (ele anota onde o Python está) ou crie o cliente pela conversa do Claude: \"Cliente novo: " + nome + "\".");
          if (e) return enviar(400, "text/plain; charset=utf-8", (String(erro || e.message).trim().split("\n").pop() || "Não deu para criar o cliente.").slice(0, 200));
          enviar(200, "application/json", JSON.stringify({ ok: true, id: /id (\S+)/.exec(String(saida))?.[1] ?? null }));
        });
      });
    }
    if (caminho === "/api/recado" && req.method === "POST") {
      // só aceita pedido vindo da própria página do painel
      if (!origemOk(req)) return enviar(403, "text/plain", "origem recusada");
      let corpo = "";
      req.on("data", (d) => { corpo += d; if (corpo.length > 20000) req.destroy(); });
      req.on("end", () => {
        try {
          const { id, texto, anexos } = JSON.parse(corpo);
          const anx = (Array.isArray(anexos) ? anexos : []).filter((a) => typeof a === "string" && a.startsWith(`/anexos/${id}/`) && !a.includes("..") && fs.existsSync(path.join(HERE, a))).slice(0, 20);
          const t = String(texto ?? "").trim().slice(0, 4000);
          const clientes = JSON.parse(fs.readFileSync(path.join(HERE, "clientes.json"), "utf8"));
          if ((!t && !anx.length) || !clientes.some((c) => c.id === id)) return enviar(400, "text/plain", "recado invalido");
          const caixa = lerCaixa();
          caixa.push({ n: (caixa.at(-1)?.n ?? 0) + 1, id, texto: t, anexos: anx, quando: new Date().toISOString(), lida: false });
          fs.writeFileSync(CAIXA + ".tmp", JSON.stringify(caixa, null, 1)); fs.renameSync(CAIXA + ".tmp", CAIXA);
          enviar(200, "application/json", JSON.stringify({ ok: true }));
        } catch (e) { enviar(400, "text/plain; charset=utf-8", "erro: " + e.message); }
      });
      return;
    }
    if (caminho === "/api/anexo" && req.method === "POST") {
      if (!origemOk(req)) return enviar(403, "text/plain", "origem recusada");
      const q = new URL(req.url, "http://x").searchParams;
      const id = q.get("id") ?? "";
      const nome = path.basename(q.get("nome") || "arquivo").replace(/[^\w.\- ]+/g, "_").slice(-120);
      const clientes = JSON.parse(fs.readFileSync(path.join(HERE, "clientes.json"), "utf8"));
      if (!clientes.some((c) => c.id === id) || !TIPOS[path.extname(nome).toLowerCase()]) return enviar(400, "text/plain; charset=utf-8", "tipo de arquivo não aceito");
      fs.mkdirSync(path.join(ANEXOS, id), { recursive: true });
      const rel = `/anexos/${id}/${Date.now()}-${nome}`;
      const final = path.join(HERE, rel);
      const out = fs.createWriteStream(final);
      let n = 0, estourou = false;
      req.on("data", (d) => { n += d.length; if (n > LIMITE && !estourou) { estourou = true; req.unpipe(out); out.destroy(); fs.rm(final, { force: true }, () => {}); enviar(413, "text/plain; charset=utf-8", "arquivo maior que 300 MB"); req.resume(); } });
      req.pipe(out);
      out.on("finish", () => { if (!estourou) enviar(200, "application/json", JSON.stringify({ url: rel, nome, tipo: tipoDe(nome), tamanho: n })); });
      out.on("error", (e) => { if (!estourou) enviar(500, "text/plain; charset=utf-8", "erro: " + e.message); });
      return;
    }
    // voz automática: a chave do ElevenLabs fica fora das pastas de trabalho e nunca volta para a página
    if (caminho === "/api/voz" && req.method === "GET") { const v = lerVoz(); return enviar(200, "application/json", JSON.stringify({ tem: !!v.chave, voz: v.voz ?? "" })); }
    if (caminho === "/api/voz" && req.method === "POST") {
      if (!origemOk(req) || req.headers["x-fm"] !== SENHA) return enviar(403, "text/plain", "origem recusada");
      return lerCorpo(req, (b) => {
        try {
          const v = lerVoz(), chave = String(b?.chave ?? "").trim(), voz = String(b?.voz ?? v.voz ?? "").replace(/\s+/g, " ").trim().slice(0, 80);
          if (chave && !/^[\w-]{20,200}$/.test(chave)) return enviar(400, "text/plain; charset=utf-8", "Essa chave não parece do ElevenLabs. Copie de novo, inteira.");
          const novo = { ...v, ...(chave ? { chave } : {}), voz };
          if (b?.apagar) delete novo.chave;
          fs.mkdirSync(path.dirname(VOZ), { recursive: true, mode: 0o700 });
          fs.writeFileSync(VOZ, JSON.stringify(novo, null, 1), { mode: 0o600 }); fs.chmodSync(VOZ, 0o600);
          enviar(200, "application/json", JSON.stringify({ tem: !!novo.chave, voz: novo.voz ?? "" }));
        } catch (e) { enviar(500, "text/plain; charset=utf-8", "erro: " + e.message); }
      });
    }
    if (caminho === "/api/atualizacao" && req.method === "GET") {
      return consultarAtualizacao((d) => {
        let andamento = null; try { andamento = JSON.parse(fs.readFileSync(ESTADO_AT, "utf8")); } catch {}
        enviar(200, "application/json; charset=utf-8", JSON.stringify({ ...d, andamento }));
      }, req.url.includes("agora=1"));
    }
    if (caminho === "/api/atualizar" && req.method === "POST") {
      if (!origemOk(req) || req.headers["x-fm"] !== SENHA) return enviar(403, "text/plain", "origem recusada");
      if (motorInfo().rodando.length) return enviar(409, "text/plain; charset=utf-8", "Há vídeo em produção. Atualize quando ele terminar.");
      const py = path.join(SKILL_DIR, "atualizar.py");
      if (!fs.existsSync(py)) return enviar(500, "text/plain; charset=utf-8", "Não achei o atualizador da skill.");
      try { fs.writeFileSync(ESTADO_AT, JSON.stringify({ estado: "rodando", msg: "Começando…" })); } catch {}
      // roda solto do painel: no fim ele religa o painel, e não pode cair junto
      const filho = spawn(acharPython(), [py, "--religar", "--estado", ESTADO_AT], { detached: true, stdio: "ignore", windowsHide: true, env: { ...process.env, PORTA: String(PORTA), PYTHONUTF8: "1", PYTHONIOENCODING: "utf-8" } });
      filho.on("error", () => {}); filho.unref();
      cacheAt.quando = 0;
      return enviar(200, "application/json", JSON.stringify({ ok: true }));
    }
    // conectar a conta do Claude de terminal: POST começa (abre o navegador na página de autorização), GET acompanha
    if (caminho === "/api/conectar" && req.method === "GET") return enviar(200, "application/json; charset=utf-8", JSON.stringify(estadoLogin()));
    if ((caminho === "/api/conectar" || caminho === "/api/conectar/codigo") && req.method === "POST") {
      if (!origemOk(req) || req.headers["x-fm"] !== SENHA) return enviar(403, "text/plain", "origem recusada");
      if (caminho === "/api/conectar") return enviar(200, "application/json; charset=utf-8", JSON.stringify(iniciarLogin()));
      let corpo = "";
      req.on("data", (d) => { corpo += d; if (corpo.length > 4000) req.destroy(); });
      req.on("end", () => { let c = ""; try { c = JSON.parse(corpo).codigo; } catch {} enviar(codigoLogin(c) ? 200 : 409, "application/json", JSON.stringify({ ok: true })); });
      return;
    }
    // POST /api/mostrar abre a pasta de um arquivo de entrega no Finder (ou no Explorador), com ele selecionado
    if (caminho === "/api/mostrar" && req.method === "POST") {
      if (!origemOk(req) || req.headers["x-fm"] !== SENHA) return enviar(403, "text/plain", "origem recusada");
      return lerCorpo(req, (d) => {
        let u = ""; try { u = decodeURIComponent(String(d?.url ?? "")); } catch {}
        const p = u.startsWith("/e/") ? caminhoNovo(u.slice(3))?.p ?? "" : u.startsWith("/entregas/") ? path.resolve(ENTREGAS, u.slice("/entregas/".length)) : "";
        const dentro = u.startsWith("/e/") ? !!p : !!p && path.dirname(p) === ENTREGAS;
        if (!dentro || !fs.existsSync(p)) return enviar(404, "text/plain; charset=utf-8", "Não achei o arquivo.");
        const [prog, args] = process.platform === "darwin" ? ["open", ["-R", p]] : process.platform === "win32" ? ["explorer.exe", ["/select," + p]] : ["xdg-open", [path.dirname(p)]];
        execFile(prog, args, () => {});   // o explorer devolve código 1 mesmo quando abre
        enviar(200, "application/json", JSON.stringify({ ok: true }));
      });
    }
    if (caminho === "/api/ping") return enviar(200, "application/json", JSON.stringify({ ok: true, pid: process.pid }));   // o painel.mjs usa para desligar
    if (caminho === "/api/motor") return void conferirLogin().then(() => enviar(200, "application/json", JSON.stringify(motorInfo())));
    if (caminho === "/api/chat" && req.method === "GET") {
      const id = new URL(req.url, "http://x").searchParams.get("id") ?? "";
      if (!/^[\w-]+$/.test(id)) return enviar(400, "text/plain", "id invalido");
      const c = lerChat(id);
      c.msgs = c.msgs.map((m) => ({ ...m, anexos: (m.anexos ?? []).map(anexoInfo) }));
      return enviar(200, "application/json; charset=utf-8", JSON.stringify(c));
    }
    // prévia do quadradinho: imagem que o Claude abriu durante o trabalho deste cliente (só imagem registrada no próprio chat)
    if (caminho === "/api/previa" && req.method === "GET") {
      const q = new URL(req.url, "http://x").searchParams, id = q.get("id") ?? "", n = Number(q.get("n")), i = q.get("i");
      if (!/^[\w-]+$/.test(id)) return enviar(400, "text/plain", "id invalido");
      const m = lerChat(id).msgs.find((x) => x.n === n && x.quem === "atividade");
      const arq = m ? (i == null ? m.previa : m.passos?.[Number(i)]?.img) : null;
      if (!arq || !/\.(png|jpe?g|webp|gif)$/i.test(arq) || !fs.existsSync(arq) || fs.statSync(arq).size > 25 * 1024 * 1024) return enviar(404, "text/plain", "sem previa");
      res.writeHead(200, { "Content-Type": TIPOS[path.extname(arq).toLowerCase()] ?? "image/jpeg", "Cache-Control": "no-store" });
      return fs.createReadStream(arq).pipe(res);
    }
    // pedido de permissão vindo do aprovador de uma sessão: fica aberto até a pessoa decidir no painel
    if (caminho === "/api/aprovar" && req.method === "POST") {
      if (req.headers["x-fm"] !== SENHA || req.headers.origin) return enviar(403, "text/plain", "recusado");
      return lerCorpo(req, async (b) => {
        if (!b || !/^[\w-]+$/.test(String(b.id ?? ""))) return enviar(200, "application/json", JSON.stringify({ behavior: "deny", message: "pedido invalido" }));
        const r = await pedirPermissao(b.id, String(b.ferramenta ?? ""), b.entrada && typeof b.entrada === "object" ? b.entrada : {});
        enviar(200, "application/json", JSON.stringify(r));
      });
    }
    if (["/api/chat", "/api/chat/parar", "/api/chat/decidir", "/api/chat/esquecer"].includes(caminho) && req.method === "POST") {
      if (!origemOk(req) || req.headers["x-fm"] !== SENHA) return enviar(403, "text/plain", "origem recusada");
      return lerCorpo(req, (b) => {
        try {
          const clientes = JSON.parse(fs.readFileSync(path.join(HERE, "clientes.json"), "utf8"));
          const cli = b && clientes.find((c) => c.id === b.id);
          if (!cli) return enviar(400, "text/plain", "cliente invalido");
          if (caminho.endsWith("/parar")) return enviar(200, "application/json", JSON.stringify({ ok: parar(cli.id) }));
          if (caminho.endsWith("/esquecer")) return enviar(200, "application/json", JSON.stringify({ ok: esquecerPermissoes(cli.id) }));
          if (caminho.endsWith("/decidir")) return enviar(200, "application/json", JSON.stringify({ ok: ["uma", "sempre", "negar"].includes(b.decisao) && decidir(cli.id, Number(b.n), b.decisao) }));
          const texto = String(b.texto ?? "").trim().slice(0, 8000);
          const anx = (Array.isArray(b.anexos) ? b.anexos : []).filter((a) => typeof a === "string" && a.startsWith(`/anexos/${cli.id}/`) && !a.includes("..") && fs.existsSync(path.join(HERE, a))).slice(0, 20);
          // referências: vídeos já entregues, escolhidos na aba Referências; viram caminho de arquivo para o Claude assistir
          const pedidas = new Set((Array.isArray(b.refs) ? b.refs : []).filter((u) => typeof u === "string").slice(0, 6));
          const refs = pedidas.size ? dados().flatMap((c) => c.entregas.filter((f) => pedidas.has(f.url)).map((f) => ({ nome: f.nome, url: f.url, thumb: f.thumb, tipo: f.tipo, cliente: f.rotulo ?? c.nome, codigo: (c.codigo ?? []).slice(0, 4),
            arquivo: f.url.startsWith("/e/") ? caminhoNovo(decodeURIComponent(f.url.slice(3)))?.p ?? path.join(NOVAS, c.pasta ?? "", f.nome) : path.join(ENTREGAS, f.nome) }))) : [];
          if (!texto && !anx.length && !refs.length) return enviar(400, "text/plain", "mensagem vazia");
          const r = enviarMensagem({ id: cli.id, nome: cli.nome, texto, anexos: anx, refs, hist: (cli.conversa ?? []).length });
          if (r.erro) return enviar(r.status ?? 500, "text/plain; charset=utf-8", r.erro);
          enviar(200, "application/json", JSON.stringify({ ok: true }));
        } catch (e) { enviar(500, "text/plain; charset=utf-8", "erro: " + e.message); }
      });
    }
    if (caminho === "/api/clientes") return enviar(200, "application/json; charset=utf-8", JSON.stringify(dados()));
    if (caminho === "/" || caminho === "/index.html") return enviar(200, "text/html; charset=utf-8", fs.readFileSync(path.join(HERE, "index.html"), "utf8").replace("</head>", `<script>window.FM_SENHA=${JSON.stringify(SENHA)}</script></head>`));
    if (caminho.startsWith("/logos/")) {
      const p = path.join(HERE, "logos", path.basename(caminho));
      if (!fs.existsSync(p) || !TIPOS[path.extname(p).toLowerCase()]) return enviar(404, "text/plain", "nao encontrado");
      res.writeHead(200, { "Content-Type": TIPOS[path.extname(p).toLowerCase()], "Cache-Control": "max-age=3600" }); return fs.createReadStream(p).pipe(res);
    }
    if (caminho === "/logo-fabrica.png") return enviar(200, "image/png", fs.readFileSync(path.join(HERE, "logo-fabrica.png")));
    if (caminho.startsWith("/thumb/") || caminho.startsWith("/t/")) {
      const nt = caminho.startsWith("/t/") ? caminhoNovo(caminho.slice(3).replace(/\.jpg$/, "")) : null;
      const src = nt ? nt.p : path.resolve(ENTREGAS, caminho.slice("/thumb/".length).replace(/\.jpg$/, ""));
      if ((caminho.startsWith("/t/") && !nt) || (!nt && path.dirname(src) !== path.resolve(ENTREGAS)) || !fs.existsSync(src)) return enviar(404, "text/plain", "nao encontrado");
      const out = path.join(THUMBS, (nt ? nt.rel.replace(/[^\w.-]+/g, "_") + "--" : "") + path.basename(src) + "-" + Math.round(fs.statSync(src).mtimeMs) + ".jpg");
      const mandar = () => { res.writeHead(200, { "Content-Type": "image/jpeg", "Cache-Control": "max-age=86400" }); fs.createReadStream(out).pipe(res); };
      if (fs.existsSync(out)) return mandar();
      fs.mkdirSync(THUMBS, { recursive: true });
      // um quadro a 40% do vídeo: a abertura costuma ser fundo liso
      return execFile(BIN("ffprobe"), ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", src], (e1, dur) => {
        const t = Math.max(0, (Number(dur) || 0) * 0.4).toFixed(2);
        execFile(BIN("ffmpeg"), ["-v", "error", "-y", "-ss", t, "-i", src, "-frames:v", "1", "-vf", "scale=480:-2", "-q:v", "4", out], (e2) => (e2 || !fs.existsSync(out) ? enviar(404, "text/plain", "sem miniatura") : mandar()));
      });
    }
    if (caminho.startsWith("/entregas/") || caminho.startsWith("/anexos/") || caminho.startsWith("/e/")) {
      const anexo = caminho.startsWith("/anexos/"), nova = caminho.startsWith("/e/");
      const cn = nova ? caminhoNovo(caminho.slice(3)) : null;
      const p = anexo ? path.resolve(HERE, "." + caminho) : nova ? cn?.p ?? "" : path.resolve(ENTREGAS, caminho.slice("/entregas/".length));
      const dentro = anexo ? path.dirname(path.dirname(p)) === ANEXOS : nova ? !!cn : path.dirname(p) === ENTREGAS;
      if (!dentro || !fs.existsSync(p)) return enviar(404, "text/plain", "nao encontrado");
      const tam = fs.statSync(p).size;
      const tipo = TIPOS[path.extname(p).toLowerCase()] ?? "application/octet-stream";
      const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range ?? "");
      if (m && (m[1] || m[2])) {
        const ini = m[1] ? Number(m[1]) : Math.max(0, tam - Number(m[2]));
        const fim = m[1] && m[2] ? Math.min(Number(m[2]), tam - 1) : tam - 1;
        res.writeHead(206, { "Content-Type": tipo, "Accept-Ranges": "bytes", "Content-Range": `bytes ${ini}-${fim}/${tam}`, "Content-Length": fim - ini + 1 });
        return fs.createReadStream(p, { start: ini, end: fim }).pipe(res);
      }
      res.writeHead(200, { "Content-Type": tipo, "Accept-Ranges": "bytes", "Content-Length": tam });
      return fs.createReadStream(p).pipe(res);
    }
    enviar(404, "text/plain", "nao encontrado");
  } catch (e) { enviar(500, "text/plain; charset=utf-8", "erro: " + e.message); }
});
servidor.listen(PORTA, "127.0.0.1");
servidor.requestTimeout = 0; servidor.headersTimeout = 0; servidor.timeout = 0;
