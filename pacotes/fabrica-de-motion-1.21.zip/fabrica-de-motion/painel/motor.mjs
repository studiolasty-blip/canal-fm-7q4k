// Motor do FM: a conversa de cada cliente é uma sessão do Claude Code em segundo plano (claude -p), SEMPRE supervisionada.
//
// Três travas, nesta ordem:
//  1. Área isolada: os comandos rodam no sandbox do Claude Code (isolado.json) e só gravam nas pastas de trabalho.
//     No Windows ela não existe: lá todo comando passa pela trava 2, e só leitura e o render seguem sem pergunta.
//  2. Permissão: a sessão roda no modo "default". Gravar arquivo, sair da área isolada (o render precisa) ou acessar a
//     internet gera um pedido que aparece no painel; quem decide é a pessoa, pelos botões Permitir / Negar.
//  3. "Permitir sempre" vale só para aquele cliente, só para aquela pasta ou aquele programa, e nunca é oferecido para
//     ações arriscadas (apagar, rede, git, fora das pastas de trabalho).
// Sem resposta, a ação é negada. Conversas ficam em chats/<id>.json. Ajustes opcionais em motor.json.
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { spawn, execFile } from "node:child_process";
import { fileURLToPath } from "node:url";
import { criarRegras } from "./regras.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const CHATS = path.join(HERE, "chats");
const lerJson = (p, padrao) => { try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return padrao; } };
const casa = (p) => (typeof p === "string" ? p.replace(/^~(?=\/|$)/, os.homedir()) : p);
const CFG = lerJson(path.join(HERE, "motor.json"), {});
const SKILL = path.join(os.homedir(), ".claude", "skills", "fabrica-de-motion");
const SKILL_CFG = lerJson(path.join(SKILL, "config.json"), {});

const WIN = process.platform === "win32";
// Onde o Claude Code de terminal costuma estar. No Windows o npm deixa um atalho .cmd, que o Node não abre direto:
// vale o programa de verdade, que fica dentro do pacote (bin/claude.exe).
function acharClaude() {
  const casaLocal = path.join(os.homedir(), ".local");
  if (!WIN) return [casa(CFG.bin), path.join(casaLocal, "bin", "claude"), "/opt/homebrew/bin/claude", "/usr/local/bin/claude"].find((p) => p && fs.existsSync(p));
  const noPacote = (prefixo) => path.join(prefixo, "node_modules", "@anthropic-ai", "claude-code", "bin", "claude.exe");
  const sistema = path.resolve(HERE, "..", "_sistema");
  const doCaminho = (process.env.PATH ?? process.env.Path ?? "").split(path.delimiter).filter(Boolean).flatMap((d) => [path.join(d, "claude.exe"), noPacote(d)]);
  return [casa(CFG.bin), path.join(casaLocal, "bin", "claude.exe"), noPacote(path.join(sistema, "apoio", "claude")), noPacote(path.join(casaLocal, "share", "fabrica-de-motion", "claude")),
    noPacote(casaLocal), noPacote(path.join(process.env.APPDATA ?? "", "npm")), ...doCaminho].find((p) => p && /\.exe$/i.test(p) && fs.existsSync(p));
}
const BIN = acharClaude();
const MODELO = CFG.modelo ?? "opus";
const RAIZ = casa(CFG.raiz) ?? path.resolve(HERE, "..");
// pastas de trabalho: onde a sessão pode ler e, com permissão, gravar
const PASTAS = [...new Set([RAIZ, ...(CFG.pastas ?? []), SKILL_CFG.template, SKILL_CFG.projetos, SKILL_CFG.entregas, SKILL_CFG.entregas_antigas, SKILL_CFG.painel].map(casa).filter((p) => p && fs.existsSync(p)).map((p) => fs.realpathSync(p)))];
const SOLEITURA = [SKILL, ...(CFG.leitura ?? []).map(casa)].filter((p) => p && fs.existsSync(p));
const SIMULTANEOS = CFG.simultaneos ?? 3;
// "perguntar" em motor.json: "nada" (padrão desde a 1.21, decisão do dono do produto) dá autonomia: nenhum cartão
// aparece, nem para ler sites, Instagram ou bancos de imagens, e só o que está em bloqueio() é recusado, sem pergunta
// (sudo, arquivos de senha ou chave, apagar fora das pastas de trabalho); "arriscado" só mostra o cartão para o que foge
// do trabalho normal; "tudo" pergunta cada gravação e cada comando fora da área isolada.
const PERGUNTAR = ["tudo", "arriscado", "nada"].includes(CFG.perguntar) ? CFG.perguntar : "nada";
const TEMP = [...new Set(["/private/tmp", "/tmp", "/private/var/folders", os.tmpdir()].map((p) => { try { return fs.realpathSync(p); } catch { return p; } }))];
const LEITURA = [...SOLEITURA, path.join(os.homedir(), "Downloads"), path.join(os.homedir(), ".claude", "skills"), path.join(os.homedir(), ".claude", "projects")];
// as regras (regras.mjs) dizem o que roda sem pergunta, o que vira cartão e o que é recusado mesmo com autonomia.
// "foraLivre" em motor.json: o que o trabalho de vídeo precisa rodar fora da área isolada sem pergunta.
const { analisar, bloqueio, curto, caixa } = criarRegras({ win: WIN, casa: os.homedir(), pastas: PASTAS, temp: TEMP, leitura: LEITURA, foraLivre: CFG.foraLivre, ferramentas: [SKILL], cwd: RAIZ });

let PORTA = 4310, SENHA = "";
export const iniciarMotor = ({ porta, senha }) => { PORTA = porta; SENHA = senha; };

const vivos = new Map();      // id → { proc, status, desde, parado }
const pedidos = new Map();    // id → [{ n, ferramenta, entrada, info, responder }]
let contador = 0;
const arq = (id) => path.join(CHATS, `${id}.json`);
const ler = (id) => memoria.get(id) ?? lerJson(arq(id), { sessao: null, sempre: [], msgs: [] });
// gravar nunca derruba o painel: se o disco encher, a conversa segue na memória e o aviso aparece na tela
const memoria = new Map();
let erroDisco = "";
const gravar = (id, c) => {
  memoria.set(id, c);
  try { fs.mkdirSync(CHATS, { recursive: true }); fs.writeFileSync(arq(id) + ".tmp", JSON.stringify(c, null, 1)); fs.renameSync(arq(id) + ".tmp", arq(id)); memoria.delete(id); erroDisco = ""; }
  catch (e) { erroDisco = e.code === "ENOSPC" ? "O disco do computador está cheio: libere espaço. A conversa continua, mas não está sendo salva." : "Não consegui salvar a conversa: " + e.message; }
};
// atividade: o "quadradinho" de cada trabalho, com os passos e as prévias; é atualizado no lugar, não vira mensagem nova
const mexerAtividade = (id, n, f) => { const c = ler(id), m = c.msgs.find((x) => x.n === n); if (!m) return; f(m); gravar(id, c); };
const IMAGEM = /\.(png|jpe?g|webp|gif)$/i;
const juntar = (id, msg) => { const c = ler(id); c.msgs.push({ n: (c.msgs.at(-1)?.n ?? 0) + 1, quando: new Date().toISOString(), ...msg }); gravar(id, c); return c; };

// chamado pelo servidor quando o aprovador (aprovador.mjs) traz um pedido do Claude; resolve quando a pessoa decide
export function pedirPermissao(id, ferramenta, entrada) {
  const info = analisar(ferramenta, entrada);
  const viva = vivos.get(id); if (viva) viva.pedidos = (viva.pedidos ?? 0) + 1;
  if (PERGUNTAR === "nada") {
    const motivo = bloqueio(ferramenta, entrada);
    if (!motivo) return Promise.resolve({ behavior: "allow" });
    juntar(id, { quem: "sistema", texto: "Bloqueei sem perguntar: " + motivo + ". O resto do trabalho segue." });
    return Promise.resolve({ behavior: "deny", message: "Bloqueado por regra fixa do painel: " + motivo + ". Não tente por outro caminho. Siga o trabalho sem isso e, se for mesmo necessário, explique à pessoa o que precisava." });
  }
  const c = ler(id);
  if (PERGUNTAR !== "tudo" && info.auto) return Promise.resolve({ behavior: "allow" });   // trabalho normal, dentro das pastas: segue sem cartão
  const guardadas = (c.sempre ?? []).map(caixa);
  if (info.chaves && info.chaves.map(caixa).every((k) => guardadas.some((s) => s === k || ((k.startsWith("pasta:") || k.startsWith("leitura:")) && s.split(":")[0] === k.split(":")[0] && (k + path.sep).startsWith(s + path.sep))))) return Promise.resolve({ behavior: "allow" });
  if (!vivos.has(id)) return Promise.resolve({ behavior: "deny", message: "A conversa deste cliente não está ativa no painel." });
  return new Promise((responder) => {
    const fila = pedidos.get(id) ?? []; pedidos.set(id, fila);
    fila.push({ n: ++contador, ferramenta, entrada, info, responder });
  });
}
// decisão da pessoa no painel: "uma" (só esta vez), "sempre" (guarda a chave para este cliente) ou "negar"
export function decidir(id, n, decisao) {
  const fila = pedidos.get(id) ?? [], i = fila.findIndex((p) => p.n === n);
  if (i < 0) return false;
  const [p] = fila.splice(i, 1);
  if (decisao === "sempre" && p.info.chaves) { const c = ler(id); c.sempre = [...new Set([...(c.sempre ?? []), ...p.info.chaves])]; gravar(id, c); }
  if (decisao === "negar") juntar(id, { quem: "sistema", texto: "Você negou: " + p.info.titulo + "." });
  p.responder(decisao === "negar" ? { behavior: "deny", message: "A pessoa negou esta ação no painel. Não tente fazer a mesma coisa por outro caminho; explique o que precisava e pergunte como seguir." } : { behavior: "allow" });
  return true;
}
const negarTudo = (id, motivo) => { for (const p of pedidos.get(id) ?? []) p.responder({ behavior: "deny", message: motivo }); pedidos.delete(id); };

// A conversa ao vivo precisa do Claude Code de terminal instalado e conectado à conta da pessoa. Sem um dos dois o painel
// fica no modo recado e diz o que falta. O login é conferido ao ligar e de novo enquanto estiver faltando.
let LOGADO = null, conferidoEm = 0, conferindo = null;
export function conferirLogin() {
  if (!BIN || LOGADO === true || Date.now() - conferidoEm < 15000) return Promise.resolve(LOGADO);
  conferindo ??= new Promise((ok) => {
    const fim = (v) => { conferindo = null; conferidoEm = Date.now(); if (v !== null) LOGADO = v; ok(LOGADO); };
    try {
      const env = { ...process.env }; if (!CFG.usarChaveApi) delete env.ANTHROPIC_API_KEY;
      execFile(BIN, ["auth", "status"], { timeout: 20000, windowsHide: true, env }, (e) => fim(!e ? true : e.code === 1 ? false : null));   // só a resposta clara "sem login" desliga a conversa
    } catch { fim(null); }
  });
  return conferindo;
}
// Login sem janela de terminal: o próprio Claude de terminal ("claude auth login") abre o navegador na página de
// autorização da conta e termina sozinho quando a pessoa autoriza. Se a página mostrar um código em vez de voltar
// sozinha, a pessoa cola no painel e ele é repassado ao programa. O painel não vê senha e não guarda o código.
let login = null;                                               // { proc, estado: "esperando" | "ok" | "falhou", url, msg }
export const estadoLogin = () => (login ? { estado: login.estado, url: login.url, msg: login.msg } : { estado: "parado", url: "", msg: "" });
export function iniciarLogin() {
  if (!BIN) return { estado: "falhou", url: "", msg: "O Claude Code de terminal não foi encontrado neste computador." };
  if (login?.estado === "esperando") { login.estado = "trocado"; matar(login.proc, "SIGTERM"); }
  const env = { ...process.env }; if (!CFG.usarChaveApi) delete env.ANTHROPIC_API_KEY;
  let proc;
  try { proc = spawn(BIN, ["auth", "login", "--claudeai"], { cwd: RAIZ, env, stdio: ["pipe", "pipe", "pipe"], windowsHide: true }); }
  catch (e) { return { estado: "falhou", url: "", msg: "Não consegui abrir o login: " + e.message }; }
  const l = (login = { proc, estado: "esperando", url: "", msg: "", saida: "" });
  const ler = (b) => { l.saida = (l.saida + b).slice(-1500); const u = /https:\/\/\S*oauth\S*/.exec(l.saida); if (u) l.url = u[0]; };
  proc.stdout.setEncoding("utf8"); proc.stderr.setEncoding("utf8");
  proc.stdout.on("data", ler); proc.stderr.on("data", ler);
  proc.stdin.on("error", () => {});
  proc.on("error", (e) => { if (l.estado === "esperando") { l.estado = "falhou"; l.msg = "Não consegui abrir o login: " + e.message; } });
  proc.on("close", (cod) => {
    if (l.estado !== "esperando") return;
    if (cod !== 0) { l.estado = "falhou"; l.msg = "O login não foi concluído. Clique em Conectar minha conta de novo."; return; }
    LOGADO = null; conferidoEm = 0;                             // quem diz que deu certo é a conferência de sempre, não o código de saída
    conferirLogin().then((ok) => { l.estado = ok === false ? "falhou" : "ok"; if (ok === false) l.msg = "A conta não ficou conectada. Clique em Conectar minha conta de novo."; });
  });
  setTimeout(() => { if (l.estado === "esperando") { l.estado = "falhou"; l.msg = "O tempo para autorizar acabou. Clique em Conectar minha conta de novo."; matar(proc, "SIGTERM"); } }, 10 * 60 * 1000).unref();
  return estadoLogin();
}
export function codigoLogin(codigo) {
  const c = String(codigo ?? "").trim();
  if (login?.estado !== "esperando" || !c || c.length > 600 || /[\r\n]/.test(c)) return false;
  try { login.proc.stdin.write(c + "\n"); return true; } catch { return false; }
}
export const motorInfo = () => ({ ok: !!BIN && LOGADO !== false, comando: BIN ? (WIN ? `& "${BIN}" auth login` : `"${BIN}" auth login`) : "", falta: !BIN ? "claude" : LOGADO === false ? "login" : "", windows: WIN, modelo: MODELO, perguntar: PERGUNTAR, rodando: [...vivos.keys()], pastas: PASTAS.map(curto), aviso: erroDisco,
  ativos: [...vivos.entries()].map(([id, v]) => ({ id, status: v.status, desde: v.desde, pedido: (pedidos.get(id)?.length ?? 0) > 0 })) });
// ao ligar o painel: conversa que estava no meio de um trabalho quando ele caiu ganha um aviso para ser retomada
export function retomarInterrompidas() {
  let n = 0;
  try {
    for (const f of fs.readdirSync(CHATS).filter((x) => /^\.mcp-.+\.json$/.test(x))) {
      const id = f.slice(5, -5);
      try { fs.rmSync(path.join(CHATS, f), { force: true }); } catch {}
      juntar(id, { quem: "sistema", texto: "O painel saiu do ar no meio deste trabalho e foi religado. O que já estava salvo continua; escreva \"continue\" para o Claude retomar de onde parou." }); n++;
    }
  } catch {}
  return n;
}
export function lerChat(id) {
  const c = ler(id), v = vivos.get(id), p = (pedidos.get(id) ?? [])[0];
  const msgs = c.msgs.map((m) => (m.quem === "atividade" && m.rodando && !v ? { ...m, rodando: false } : m));
  return { msgs, hist: c.hist ?? null, aviso: erroDisco, rodando: !!v, status: v?.status ?? "", desde: v?.desde ?? null, diag: v ? { ...v.diag, pedidos: v.pedidos ?? 0 } : null, sempre: (c.sempre ?? []).map((s) => curto(s.replace(/^\w+:/, (m) => ({ "pasta:": "pasta ", "leitura:": "ler ", "cmd:": "comando ", "fora:": "fora da área isolada: " }[m] ?? m)))),
    pedido: p ? { n: p.n, titulo: p.info.titulo, detalhe: p.info.detalhe, aviso: p.info.aviso, perigo: !!p.info.perigo, sempre: p.info.rotuloSempre, outros: (pedidos.get(id)?.length ?? 1) - 1 } : null };
}
export const esquecerPermissoes = (id) => { const c = ler(id); c.sempre = []; gravar(id, c); return true; };
// no Windows, encerrar o pai não encerra os programas que ele abriu (o render continuaria rodando): cai a árvore inteira
const matar = (proc, sinal) => {
  if (WIN && proc.pid) { try { spawn("taskkill", ["/pid", String(proc.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true }).on("error", () => {}); return; } catch {} }
  try { proc.kill(sinal); } catch {}
};
export const parar = (id) => { const v = vivos.get(id); if (!v) return false; v.parado = true; negarTudo(id, "A conversa foi parada."); matar(v.proc, "SIGTERM"); if (!WIN) setTimeout(() => { try { v.proc.kill("SIGKILL"); } catch {} }, 4000); return true; };

const resumoFerramenta = (b) => {
  const i = b.input ?? {};
  if (b.name === "Bash") return i.description || "rodando um comando";
  if (b.name === "Edit" || b.name === "Write") return "escrevendo " + path.basename(i.file_path ?? "arquivo");
  if (b.name === "Read") return "lendo " + path.basename(i.file_path ?? "arquivo");
  if (b.name === "Skill") return "abrindo o método";
  return b.name.replace(/^mcp__fm__/, "");
};

// limite de uso do plano do Claude: vira um aviso em português, com a hora em que volta e o que fazer
const LIMITE = /hit your (session|usage|weekly|\w+ )?limit|usage limit reached/i;
const avisoDeLimite = (t) => {
  if (!LIMITE.test(t)) return null;
  const volta = /resets?\s+(?:at\s+)?([^·(\n]+?)(?:\s*\(|$)/i.exec(t)?.[1]?.trim();
  return "O limite de uso do seu plano do Claude foi atingido" + (volta ? " e volta às " + volta : "") + ". Nada se perdeu: o que já estava pronto continua salvo. Quando o limite voltar, escreva \"continue\" aqui. O limite é o da conta em que o Claude de terminal está logado neste computador.";
};
// sem login no Claude de terminal: o erro em inglês vira o passo a passo
const SEM_LOGIN = /not logged in|please run \/login|failed to authenticate|authentication_failed|oauth session expired|invalid api key/i;
const avisoDeLogin = (t) => (SEM_LOGIN.test(t) ? "O Claude de terminal deste computador não está conectado à sua conta. Recarregue esta página e clique em Conectar minha conta." : null);
export function enviarMensagem({ id, nome, texto, anexos = [], refs = [], hist = 0 }) {
  if (!BIN) return { erro: "O Claude Code de terminal não foi encontrado neste computador.", status: 503 };
  if (LOGADO === false) return { erro: avisoDeLogin("not logged in"), status: 503 };
  if (vivos.has(id)) return { erro: "O Claude ainda está trabalhando neste cliente. Espere terminar ou aperte Parar.", status: 409 };
  if (vivos.size >= SIMULTANEOS) return { erro: `Já há ${vivos.size} clientes em andamento. Espere um terminar.`, status: 429 };
  const conv = juntar(id, { quem: "voce", texto, anexos, ...(refs.length ? { refs: refs.map(({ nome: n, url, thumb, tipo, cliente }) => ({ nome: n, url, thumb, tipo, cliente })) } : {}) });
  if (conv.hist == null) { conv.hist = hist; gravar(id, conv); }      // quantas linhas do fichário já existiam antes da primeira mensagem pelo painel
  const caminhos = anexos.map((a) => path.join(HERE, a));
  const corpo = texto + (caminhos.length ? "\n\nArquivos enviados agora (material deste cliente; copie para a pasta src do cliente antes de usar):\n" + caminhos.map((p) => "- " + p).join("\n") : "")
    + (refs.length ? "\n\nReferências escolhidas no painel (vídeos que já fizemos: use o estilo, o ritmo e as soluções deles como base, adaptando à identidade deste cliente, sem copiar):\n" + refs.map((r) => `- ${r.arquivo} (feito para ${r.cliente}${r.codigo?.length ? "; código: " + r.codigo.join(", ") : ""})`).join("\n") : "");
  const prompt = conv.sessao ? corpo : [
    `Você está atendendo pelo painel do FM (Fábrica de Motion). Esta conversa é só do cliente "${nome}" (id ${id}).`,
    `Siga a skill fabrica-de-motion. Antes de qualquer coisa, rode: ${WIN ? `python3 "${path.join(SKILL, "cliente.py").replace(/\\/g, "/")}" abrir ${id}` : `python3 ~/.claude/skills/fabrica-de-motion/cliente.py abrir ${id}`}`,
    ...(CFG.preferencias ? [`Leia também as preferências do dono em ${casa(CFG.preferencias)} antes de criar qualquer vídeo.`] : []),
    "Regras desta conversa:",
    "- Material novo: leia TUDO antes de responder (abra cada arquivo, transcreva áudio e vídeo). Link de Instagram: abra SEMPRE o perfil e os posts para ver identidade, cores, fotos e vídeos. Link de site: abra SEMPRE o site e navegue pelas páginas principais (início, sobre, serviços ou produtos, contato), seguindo os links. Use o WebFetch; quando não abrir ou não mostrar o visual, tire print com o Chrome sem janela: " + (WIN ? "\"C:/Program Files/Google/Chrome/Application/chrome.exe\"" : "\"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome\"") + " --headless=new --hide-scrollbars --window-size=1080,1920 --screenshot=<pasta do cliente>/print-<nome>.png <url>" + (WIN ? "" : ", fora da área isolada") + ", e abra o print com Read.",
    "- Depois de ler tudo, a primeira resposta é SEMPRE o roteiro com a narração pronta para colar no ElevenLabs v3: o texto da narração num bloco de código, com as marcações ([warm], [short pause]…), sem nada além do que vai ser falado. Nunca monte o vídeo sem narração: espere a voz gravada (ou gere com o voz.py se a chave do ElevenLabs estiver guardada).",
    "- O painel mostra ao lado da conversa toda imagem que você abrir com Read, como prévia ao vivo. Na montagem, a cada cena pronta, gere um quadro dela (npx remotion still <composição> <pasta do cliente>/previas/cena-N.jpg --frame=<quadro> --scale=0.5) e abra com Read, para o dono acompanhar como está ficando.",
    "- Fale só quando tiver algo para o dono ler: o progresso aparece sozinho no painel; não narre cada passo.",
    "- Não mexa em arquivos de outros clientes. Outras conversas podem estar trabalhando ao mesmo tempo no mesmo projeto de vídeo: edite só a pasta deste cliente e, no arquivo de registro das composições, acrescente apenas as linhas dele.",
    PERGUNTAR === "nada"
      ? "- Você tem autonomia: nada vira pedido de permissão, então não pare para pedir licença; decida e siga. Só três coisas são recusadas na hora, sem pergunta: sudo, arquivos de senha ou chave, e apagar fora das pastas de trabalho. Versão antiga de entrega nunca se apaga."
      : "- Trabalho normal dentro das pastas do projeto, do cliente e das entregas segue direto. O que foge disso (apagar, rede, git, arquivos fora dessas pastas) vira um pedido de permissão no painel; se a pessoa negar, não tente por outro caminho: explique o que precisava e pergunte como seguir.",
    ...(WIN ? [
      "- Este computador é Windows. Nos comandos, escreva o caminho completo dos arquivos (com / no lugar de \\ funciona nos dois terminais); não use ~ para a pasta pessoal.",
      ...(PERGUNTAR === "nada" ? [] : ["- Aqui não existe área isolada. Seguem sem pergunta: leitura, o render, as ferramentas da skill (cliente.py, voz.py, conferir.py) rodadas pelo caminho da skill, ffmpeg, criar pasta, copiar e mover, sempre que todo caminho do comando ficar nas pastas de trabalho. O resto vira pedido de permissão no painel. Grave tudo dentro das pastas de trabalho e não junte num mesmo comando um programa de fora dessa rotina."]),
    ] : ["- Seus comandos rodam numa área isolada. O render do Remotion não abre o navegador dentro dela: quando falhar por isso, repita o mesmo comando fora dela."]),
    "- Responda em português do Brasil, curto e direto, sem tabelas largas (a tela é estreita).",
    "- Entrega nova vai para a pasta do cliente dentro da pasta de entregas (a ficha mostra o caminho exato em \"Onde está cada coisa\"). Ao entregar, escreva o nome exato do arquivo: o painel mostra o vídeo sozinho.",
    "- Você não ouve áudio: diga isso quando entregar vídeo com som.",
    "", "Mensagem do usuário:", corpo,
  ].join("\n");

  const mcp = path.join(CHATS, `.mcp-${id}.json`);
  try { fs.mkdirSync(CHATS, { recursive: true }); fs.writeFileSync(mcp, JSON.stringify({ mcpServers: { fm: { command: process.execPath, args: [path.join(HERE, "aprovador.mjs")], env: { FM_PORTA: String(PORTA), FM_ID: id, FM_SENHA: SENHA } } } }), { mode: 0o600 }); }
  catch (e) { juntar(id, { quem: "sistema", texto: "Não consegui começar: " + (e.code === "ENOSPC" ? "o disco do computador está cheio." : e.message) }); return { ok: true }; }
  // a área isolada (isolado.json) não existe no Windows, e pedi-la lá faz a sessão nem abrir
  const args = ["-p", "--model", MODELO, "--permission-mode", "default", ...(WIN ? [] : ["--settings", path.join(HERE, "isolado.json")]), "--mcp-config", mcp, "--strict-mcp-config", "--permission-prompt-tool", "mcp__fm__aprovar",
    "--output-format", "stream-json", "--verbose", ...(conv.sessao ? ["--resume", conv.sessao] : []), ...[...PASTAS.filter((d) => d !== RAIZ), ...SOLEITURA].flatMap((d) => ["--add-dir", d])];
  const env = { ...process.env, MCP_TOOL_TIMEOUT: "3600000" };
  if (WIN) {
    // os programas que o instalador baixou vão na frente: no Windows existe um "python3" de mentira que só abre a loja
    const chave = Object.keys(env).find((k) => k.toUpperCase() === "PATH") ?? "Path";
    const nossos = [path.join(os.homedir(), ".local", "bin"), path.join(RAIZ, "_sistema", "bin"), path.join(RAIZ, "_sistema", "apoio", "node")].filter((d) => fs.existsSync(d));
    env[chave] = [...nossos, env[chave]].filter(Boolean).join(path.delimiter);
    Object.assign(env, { PYTHONUTF8: "1", PYTHONIOENCODING: "utf-8" });
  } else env.PATH = [process.env.PATH, "/opt/homebrew/bin", "/usr/local/bin", path.join(os.homedir(), ".local/bin")].filter(Boolean).join(":");
  if (!CFG.usarChaveApi) delete env.ANTHROPIC_API_KEY;                // por padrão usa o login do Claude Code, não uma chave paga por uso
  const proc = spawn(BIN, args, { cwd: RAIZ, env, stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
  const v = { proc, status: "começando", desde: Date.now(), parado: false };
  vivos.set(id, v);
  const act = juntar(id, { quem: "atividade", rodando: true, passos: [] }).msgs.at(-1).n;
  const passo = (p) => mexerAtividade(id, act, (m) => { m.passos.push(p); if (m.passos.length > 300) m.passos.splice(0, m.passos.length - 300); if (p.img) m.previa = p.img; });
  let ultimoTexto = "";
  proc.stdin.end(prompt);

  let resto = "", terminou = false, erros = "";
  const linha = (l) => {
    let d; try { d = JSON.parse(l); } catch { return; }
    if (d.session_id) { const c = ler(id); if (c.sessao !== d.session_id) { c.sessao = d.session_id; gravar(id, c); } }
    if (d.type === "system" && d.subtype === "init") {
      // trava de segurança: se a sessão não subiu no modo supervisionado, com o aprovador ligado, ela é encerrada na hora
      const aprovador = (d.mcp_servers ?? []).find((m) => m.name === "fm")?.status;
      v.diag = { modo: d.permissionMode, aprovador };
      if (d.permissionMode !== "default" || aprovador !== "connected") {
        v.abortada = `modo "${d.permissionMode}", aprovador "${aprovador ?? "ausente"}"`;
        negarTudo(id, "Sessão sem supervisão."); matar(proc, "SIGKILL");
      }
    } else if (d.type === "assistant") {
      for (const b of d.message?.content ?? []) {
        // texto no meio do trabalho vai para o quadradinho; só a resposta final vira mensagem (no "result")
        if (b.type === "text" && b.text.trim() && !LIMITE.test(b.text) && !(b.text.length < 200 && SEM_LOGIN.test(b.text))) { ultimoTexto = b.text.trim(); passo({ t: "texto", texto: ultimoTexto }); v.status = "escrevendo"; }
        if (b.type === "tool_use") {
          v.status = resumoFerramenta(b);
          const f = b.input?.file_path;
          if (b.name === "Read" && f && IMAGEM.test(f)) passo({ t: "previa", texto: "olhando " + path.basename(f), img: path.resolve(RAIZ, f) });
          else passo({ t: "acao", texto: v.status });
        }
      }
    } else if (d.type === "system" && d.subtype === "task_summary" && d.detail && d.detail !== "None") {
      v.status = String(d.detail).slice(0, 90);
    } else if (d.type === "result") {
      terminou = true;
      const final = String(d.result ?? "").trim() || ultimoTexto;
      if (!d.is_error && final && !LIMITE.test(final)) {
        mexerAtividade(id, act, (m) => { const u = m.passos.at(-1); if (u?.t === "texto" && u.texto === final) m.passos.pop(); });
        juntar(id, { quem: "claude", texto: final });
      }
      if (d.is_error && /not logged in|please run \/login|oauth session expired/i.test(String(d.result ?? ""))) { LOGADO = false; conferidoEm = Date.now(); }   // a tela passa a mostrar o botão de conectar
      if (d.is_error) juntar(id, { quem: "sistema", texto: avisoDeLimite(String(d.result ?? "")) ?? avisoDeLogin(String(d.result ?? "")) ?? "Não consegui concluir: " + String(d.result ?? d.subtype ?? "erro").slice(0, 600) });
    }
  };
  proc.stdout.setEncoding("utf8"); proc.stderr.setEncoding("utf8");       // sem isto, um acento partido entre dois pedaços vira lixo
  proc.stdout.on("data", (buf) => { resto += buf; const ls = resto.split("\n"); resto = ls.pop(); ls.forEach(linha); });
  proc.stderr.on("data", (buf) => { erros = (erros + buf).slice(-800); });
  proc.on("error", (e) => { erros += e.message; });
  proc.on("close", (cod) => {
    if (resto.trim()) linha(resto);
    vivos.delete(id); negarTudo(id, "A conversa terminou.");
    mexerAtividade(id, act, (m) => { m.rodando = false; m.fim = new Date().toISOString(); });
    try { fs.rmSync(mcp, { force: true }); } catch {}
    if (v.abortada) juntar(id, { quem: "sistema", texto: "Interrompi a sessão antes de ela fazer qualquer coisa: a supervisão não ficou ativa (" + v.abortada + "). Nada foi executado." });
    else if (v.parado) juntar(id, { quem: "sistema", texto: "Parado por você. O que já estava pronto continua salvo; é só mandar a próxima mensagem." });
    else if (!terminou) juntar(id, { quem: "sistema", texto: "A sessão terminou sem resposta" + (cod ? ` (código ${cod})` : "") + (erros.trim() ? ": " + erros.trim().split("\n").at(-1).slice(0, 300) : ".") });
  });
  return { ok: true };
}
