#!/bin/bash
# Liga e desliga o painel da Fábrica de Motion em segundo plano: não precisa deixar nenhum terminal aberto.
#
#   painel.sh ligar | abrir | estado | religar | desligar        (porta padrão 4310; outra: PORTA=4400 painel.sh ligar)
#
# Quem faz o trabalho é o painel.mjs (o mesmo no Mac, no Windows e no Linux); este arquivo só acha o Node e chama.
AQUI="$(cd "$(dirname "$0")" && pwd)"
NODE="$(command -v node 2>/dev/null)"
if [ -z "$NODE" ]; then
  for p in "$HOME/.local/bin/node" /opt/homebrew/bin/node /usr/local/bin/node; do [ -x "$p" ] && NODE="$p" && break; done
fi
[ -z "$NODE" ] && NODE="$(ls "$HOME"/.nvm/versions/node/*/bin/node 2>/dev/null | tail -1)"
if [ -z "$NODE" ]; then echo "Falta o Node.js neste computador. Rode o instalador de novo (bash instalar.sh)."; exit 1; fi
exec "$NODE" "$AQUI/painel.mjs" "$@"
