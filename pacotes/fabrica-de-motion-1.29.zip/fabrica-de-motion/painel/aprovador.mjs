// Aprovador do FM: a ponte entre o Claude Code em segundo plano e a pessoa na frente do painel.
// O Claude chama esta ferramenta (protocolo MCP, pelo stdin/stdout) sempre que quer fazer algo que precisa de
// permissão: gravar um arquivo, rodar um comando fora da área isolada, acessar a internet. Este processo NÃO decide
// nada: repassa o pedido ao servidor do painel e fica esperando a pessoa apertar Permitir ou Negar.
// Sem resposta do painel (servidor fora do ar, tempo esgotado), a resposta é sempre "negar".
//   FM_PORTA, FM_ID e FM_SENHA chegam pelo ambiente, definidos pelo motor que abriu a sessão.
import http from "node:http";
import readline from "node:readline";
import fs from "node:fs";

const { FM_PORTA = "4310", FM_ID = "", FM_SENHA = "", FM_DIARIO = "" } = process.env;
const negar = (motivo) => ({ behavior: "deny", message: motivo });
const diario = (o) => { if (FM_DIARIO) try { fs.appendFileSync(FM_DIARIO, JSON.stringify(o) + "\n"); } catch {} };

function perguntarAoPainel(pedido) {
  return new Promise((ok) => {
    const corpo = JSON.stringify({ id: FM_ID, ...pedido });
    const req = http.request({ host: "127.0.0.1", port: Number(FM_PORTA), path: "/api/aprovar", method: "POST", headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(corpo), "x-fm": FM_SENHA } }, (res) => {
      let t = ""; res.on("data", (d) => { t += d; });
      res.on("end", () => { try { const r = JSON.parse(t); ok(r && (r.behavior === "allow" || r.behavior === "deny") ? r : negar("O painel não respondeu ao pedido de permissão.")); } catch { ok(negar("O painel não respondeu ao pedido de permissão.")); } });
    });
    req.on("error", () => ok(negar("O painel do FM está fora do ar; nada foi permitido.")));
    req.setTimeout(55 * 60 * 1000, () => { req.destroy(); ok(negar("Ninguém respondeu ao pedido de permissão a tempo.")); });
    req.end(corpo);
  });
}

const responder = (id, result) => process.stdout.write(JSON.stringify({ jsonrpc: "2.0", id, result }) + "\n");
readline.createInterface({ input: process.stdin }).on("line", async (l) => {
  let m; try { m = JSON.parse(l); } catch { return; }
  if (m.id === undefined) return;                                   // notificações não têm resposta
  if (m.method === "initialize") return responder(m.id, { protocolVersion: m.params?.protocolVersion ?? "2024-11-05", capabilities: { tools: {} }, serverInfo: { name: "fm", version: "0.1.0" } });
  if (m.method === "ping") return responder(m.id, {});
  if (m.method === "tools/list") return responder(m.id, { tools: [{ name: "aprovar", description: "Pede à pessoa no painel do FM permissão para uma ação.", inputSchema: { type: "object", properties: { tool_name: { type: "string" }, input: { type: "object" }, tool_use_id: { type: "string" } }, required: ["tool_name", "input"] } }] });
  if (m.method === "tools/call") {
    const a = m.params?.arguments ?? {};
    diario({ pedido: a });
    const r = await perguntarAoPainel({ ferramenta: String(a.tool_name ?? ""), entrada: a.input ?? {} });
    // quando permite, a entrada volta igual: este aprovador nunca altera o que o Claude pediu
    const saida = r.behavior === "allow" ? { behavior: "allow", updatedInput: a.input ?? {} } : { behavior: "deny", message: r.message || "Negado no painel do FM." };
    diario({ resposta: saida.behavior });
    return responder(m.id, { content: [{ type: "text", text: JSON.stringify(saida) }] });
  }
  process.stdout.write(JSON.stringify({ jsonrpc: "2.0", id: m.id, error: { code: -32601, message: "método não suportado" } }) + "\n");
});
