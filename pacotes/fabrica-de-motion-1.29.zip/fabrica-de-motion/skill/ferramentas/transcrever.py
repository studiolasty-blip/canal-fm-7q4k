#!/usr/bin/env python3
# /// script
# requires-python = ">=3.9"
# dependencies = ["faster-whisper>=1.1", "numpy"]
# ///
"""Transcreve uma narração com o tempo de cada palavra, para sincronizar o vídeo com a voz.

  uv run transcrever.py voz_limpa.wav [--idioma pt] [--modelo large-v3-turbo]

Roda neste computador, sem chave e sem enviar o áudio a ninguém. Na primeira vez baixa o modelo de fala (cerca de
1,6 GB no padrão; --modelo small tem uns 500 MB e erra mais palavras, mas os tempos servem).
Saída: <arquivo>.palavras.json (cada palavra com início e fim, em segundos) e, na tela, as frases com os tempos e as
pausas medidas no áudio. O texto ajuda a achar cada palavra; números e nomes próprios a transcrição costuma errar,
então quem manda é o roteiro, e o tempo se confere pelas pausas.
"""
import argparse, json, re, subprocess, sys
from pathlib import Path

for _saida in (sys.stdout, sys.stderr):
    try:
        _saida.reconfigure(encoding="utf-8")
    except Exception:
        pass

ap = argparse.ArgumentParser(description="Transcreve uma narração com o tempo de cada palavra.")
ap.add_argument("audio")
ap.add_argument("--idioma", default="pt")
ap.add_argument("--modelo", default="large-v3-turbo")
ap.add_argument("--pausa", type=float, default=0.3, help="silêncio que separa uma frase da outra na tela (s)")
a = ap.parse_args()

src = Path(a.audio).expanduser()
if not src.is_file():
    sys.exit(f"Não achei o arquivo: {src}")
from faster_whisper import WhisperModel

print(f"carregando o modelo {a.modelo} (na primeira vez ele é baixado)…", file=sys.stderr)
modelo = WhisperModel(a.modelo, device="cpu", compute_type="int8")
# o áudio é lido pelo ffmpeg (16 kHz, mono): assim qualquer formato entra e não depende do leitor da biblioteca
import numpy as np
bruto = subprocess.run(["ffmpeg", "-v", "error", "-i", str(src), "-f", "f32le", "-ac", "1", "-ar", "16000", "-"], capture_output=True).stdout
if not bruto:
    sys.exit("O ffmpeg não conseguiu ler este áudio.")
segmentos, info = modelo.transcribe(np.frombuffer(bruto, np.float32), language=a.idioma, word_timestamps=True, vad_filter=False, beam_size=5, condition_on_previous_text=False)
palavras = []
for s in segmentos:
    for w in s.words or []:
        t = w.word.strip()
        if t:
            palavras.append({"p": t, "i": round(float(w.start), 2), "f": round(float(w.end), 2)})
if not palavras:
    sys.exit("Não reconheci nenhuma palavra neste áudio.")
saida = src.with_name(src.name + ".palavras.json")
saida.write_text(json.dumps(palavras, ensure_ascii=False), encoding="utf-8")

# pausas medidas no próprio áudio: é por elas que se confere o tempo e se separam as frases
log = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(src), "-af", "silencedetect=noise=-35dB:d=0.18", "-f", "null", "-"], capture_output=True, text=True).stderr
ini = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", log)]; fim = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", log)]
meios = [(s + e) / 2 for s, e in zip(ini, fim)]
# cada pausa abre uma frase nova uma vez só: na primeira palavra que começa perto do fim dela
cortes = set()
for m in meios:
    k = next((i for i, w in enumerate(palavras) if w["i"] >= m - 0.12), None)
    if k:
        cortes.add(k)
frases, atual = [], [palavras[0]]
for k, (ant, w) in enumerate(zip(palavras, palavras[1:]), 1):
    if k in cortes or w["i"] - ant["f"] >= a.pausa:
        frases.append(atual); atual = []
    atual.append(w)
frases.append(atual)
print(f"{src.name}  ·  {info.duration:.2f} s  ·  {len(palavras)} palavras  ·  {len(frases)} frases  ·  palavras em {saida.name}\n")
for f in frases:
    print(f"{f[0]['i']:6.2f}–{f[-1]['f']:6.2f}  " + " ".join(f"{w['p']}({w['i']:.2f})" for w in f))
if ini:
    print("\nPausas no áudio (início–fim): " + "  ".join(f"{s:.2f}–{e:.2f}" for s, e in zip(ini, fim)))
