#!/usr/bin/env python3
"""Conferência de um vídeo antes da entrega: folha de quadros, movimento por segundo e volume.

uso:
  conferir.py <video.mp4>                    um quadro a cada ~2 s
  conferir.py <video.mp4> --tempos 1.5 4 9   quadros nos segundos pedidos (o fim de cada cena)

Grava <video>-quadros.jpg ao lado do vídeo e imprime duração, tamanho, movimento médio de cada segundo
(valores abaixo de ~0,5 são trechos quase parados) e o volume final (alvo: perto de -14 LUFS, pico até -1,5 dB).
Só precisa de ffmpeg e ffprobe.
"""
import argparse, math, re, subprocess, sys, tempfile
for _saida in (sys.stdout, sys.stderr):                     # no Windows a saída padrão não é UTF-8: sem isto os acentos quebram
    try:
        _saida.reconfigure(encoding="utf-8")
    except Exception:
        pass
from pathlib import Path


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--tempos", type=float, nargs="*")
    ap.add_argument("--calmo", type=float, default=0.5, help="abaixo disso o segundo conta como calmo")
    a = ap.parse_args()
    v = Path(a.video).expanduser()
    if not v.is_file():
        sys.exit(f"Não achei o arquivo: {v}")

    info = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate:format=duration,size", "-of", "default=nw=1", str(v)]).stdout
    get = lambda key: re.search(rf"{key}=(.+)", info).group(1)
    dur = float(get("duration")); w, h = int(get("width")), int(get("height"))
    print(f"Arquivo: {v.name} · {w}x{h} · {dur:.1f} s · {int(get('size')) / 1e6:.1f} MB")

    tempos = a.tempos or [round(x, 2) for x in [dur * (i + 0.5) / max(1, round(dur / 2)) for i in range(max(1, round(dur / 2)))]]
    cols = min(7, len(tempos)); rows = math.ceil(len(tempos) / cols)
    alt = 640 if h >= w else 360
    with tempfile.TemporaryDirectory() as tmp:
        for i, tt in enumerate(tempos):
            run(["ffmpeg", "-v", "error", "-y", "-ss", str(tt), "-i", str(v), "-frames:v", "1", "-vf", f"scale=-2:{alt}", f"{tmp}/{i:03d}.png"])
        folha = v.with_name(v.stem + "-quadros.jpg")
        r = run(["ffmpeg", "-v", "error", "-y", "-framerate", "1", "-i", f"{tmp}/%03d.png", "-vf", f"tile={cols}x{rows}", "-frames:v", "1", str(folha)])
        print(f"Quadros ({', '.join(f'{x:g}s' for x in tempos)}): {folha}" if folha.exists() else f"Não consegui montar a folha de quadros: {r.stderr.strip()[-200:]}")

    fps = eval(get("r_frame_rate")) or 30
    m = run(["ffmpeg", "-v", "error", "-i", str(v), "-vf", "scale=270:-2,tblend=all_mode=difference,signalstats,metadata=print:key=lavfi.signalstats.YAVG:file=-", "-an", "-f", "null", "-"]).stdout
    vals = [float(x) for x in re.findall(r"YAVG=([\d.]+)", m)]
    n = max(1, round(fps))
    seg = [sum(vals[i:i + n]) / len(vals[i:i + n]) for i in range(0, len(vals), n) if vals[i:i + n]]
    print("Movimento por segundo: " + " ".join(f"{i + 1}:{x:.2f}" for i, x in enumerate(seg)))
    calmos = [str(i + 1) for i, x in enumerate(seg) if x < a.calmo]
    print(f"Segundos calmos (< {a.calmo}): " + (", ".join(calmos) if calmos else "nenhum"))

    lo = run(["ffmpeg", "-i", str(v), "-vn", "-af", "loudnorm=print_format=summary", "-f", "null", "-"]).stderr
    i = re.search(r"Input Integrated:\s+(-?[\d.]+|-inf)", lo); tp = re.search(r"Input True Peak:\s+([-+]?[\d.]+|-inf)", lo)
    print(f"Volume: {i.group(1)} LUFS · pico {tp.group(1)} dB" if i and tp else "Volume: o arquivo não tem áudio")


if __name__ == "__main__":
    main()
