#!/usr/bin/env python3
"""Instala as referências que vêm com a skill: vídeos de exemplo, autorizados pelos clientes, que já aparecem na aba
Referências do painel no primeiro uso.

  referencias.py <pasta do pacote> <pasta de trabalho>

Copia os vídeos de <pacote>/referencias para <trabalho>/entregas/Referências, cria o cliente "Referências" no painel
e a lista de destaques (com o nicho de cada um). Não sobrescreve nada: o que já existe fica como está.
"""
import json, pathlib, shutil, sys

pacote, trabalho = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
origem = pacote / "referencias"
lista = origem / "referencias.json"
if not lista.is_file():
    print("sem referências neste pacote"); sys.exit(0)
itens = json.loads(lista.read_text(encoding="utf-8"))
destino = trabalho / "entregas" / "Referências"
destino.mkdir(parents=True, exist_ok=True)
copiados = 0
for it in itens:
    o = origem / it["arquivo"]
    if o.is_file() and not (destino / o.name).exists():
        shutil.copy2(o, destino / o.name); copiados += 1
painel = trabalho / "painel"
arq = painel / "clientes.json"
clientes = json.loads(arq.read_text(encoding="utf-8")) if arq.is_file() else []
if not any(c.get("id") == "referencias" for c in clientes):
    clientes.append({"id": "referencias", "nome": "Referências", "pasta": "Referências", "nosso": True, "nicho": "Vídeos de exemplo que vêm com a skill",
                     "status": "entregue", "prefixos": [], "notas": [], "pendencias": [], "conversa": [], "codigo": [],
                     "resumo": "Vídeos de exemplo, autorizados pelos clientes. Servem de referência de estilo e ritmo para os seus."})
    arq.write_text(json.dumps(clientes, ensure_ascii=False, indent=1), encoding="utf-8")
dest = painel / "destaques.json"
if not dest.exists():
    dest.write_text(json.dumps([{"arquivo": it["arquivo"], "rotulo": it.get("rotulo", "")} for it in itens], ensure_ascii=False, indent=1), encoding="utf-8")
print(f"{len(itens)} referências ({copiados} copiadas agora) em {destino}")
