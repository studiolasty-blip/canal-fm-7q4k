#!/usr/bin/env python3
"""Mantém os ajustes da pessoa quando a skill é reinstalada ou atualizada.

  juntar_config.py <config novo> <config antigo> [--manter-caminhos]

O instalador escreve um config.json novo; este script traz do antigo o que a pessoa tinha ajustado (por exemplo
"pastas": "data"). Com --manter-caminhos, os caminhos antigos (painel, entregas, projetos, template) também valem:
é o caso de uma atualização, em que a pasta de trabalho não mudou. "python" e "temp" são sempre os da instalação nova.
"""
import json, pathlib, sys

novo_p, antigo_p = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
manter = "--manter-caminhos" in sys.argv[3:]
try:
    novo, antigo = json.loads(novo_p.read_text(encoding="utf-8")), json.loads(antigo_p.read_text(encoding="utf-8"))
except (OSError, ValueError):
    sys.exit(0)
for k, v in antigo.items():
    if k in ("python", "temp"):
        continue
    if k not in novo or (manter and k in ("painel", "entregas", "projetos", "template")):
        novo[k] = v
novo_p.write_text(json.dumps(novo, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
