#!/usr/bin/env python3
"""Tira o silêncio morto de uma narração, sem acelerar a voz: voz.mp3 -> voz_limpa.wav + voz_limpa_mapa.json.

  limpar_voz.py voz.mp3 [--curta 0.07] [--longa 0.34] [--nome _limpa] [--tempo 1.0]

Toda pausa achada pelo ffmpeg (silencedetect) é encurtada, nunca apagada inteira: assim o fim e o começo de cada
palavra guardam alguns milissegundos de ar. Pausa de menos de 0,3 s (dentro da frase) fica com --curta segundos; a
maior (entre frases) fica com --longa. Cada trecho ganha 6 ms de fade nas pontas para a emenda não estalar.
--tempo acelera sem mudar o tom; o padrão é 1.0, porque a regra da casa é não acelerar a voz.
O mapa lista [início na original, fim na original, início no arquivo limpo] de cada trecho mantido.
"""
import argparse, json, re, subprocess, sys
from pathlib import Path

for _saida in (sys.stdout, sys.stderr):                     # no Windows a saída padrão não é UTF-8: sem isto os acentos quebram
    try:
        _saida.reconfigure(encoding="utf-8")
    except Exception:
        pass

ap = argparse.ArgumentParser(description="Tira o silêncio morto de uma narração.")
ap.add_argument("voz")
ap.add_argument("--curta", type=float, default=0.07, help="quanto sobra de uma pausa dentro da frase (s)")
ap.add_argument("--longa", type=float, default=0.34, help="quanto sobra de uma pausa entre frases (s)")
ap.add_argument("--tempo", type=float, default=1.0, help="1.0 = sem acelerar")
ap.add_argument("--ruido", default="-38dB", help="abaixo disto conta como silêncio")
ap.add_argument("--minima", type=float, default=0.12, help="menor silêncio que conta como pausa (s)")
ap.add_argument("--nome", default="_limpa", help="sufixo dos arquivos de saída")
a = ap.parse_args()

src = Path(a.voz).expanduser()
if not src.is_file():
    sys.exit(f"Não achei o arquivo: {src}")
out = src.with_name(src.stem + a.nome + ".wav")
dur = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(src)]))
log = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(src), "-af", f"silencedetect=noise={a.ruido}:d={a.minima}", "-f", "null", "-"], capture_output=True, text=True).stderr
inicios = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", log)]
fins = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", log)]
if len(fins) < len(inicios):
    fins.append(dur)

# silêncios colados (o silencedetect quebra num estalo ou numa respiração) contam como uma pausa só
pausas = []
for s, e in zip(inicios, fins):
    if pausas and s - pausas[-1][1] < 0.03:
        pausas[-1][1] = e
    else:
        pausas.append([s, e])

manter, cur = [], 0.0
for s, e in pausas:
    sobra = a.curta if e - s < 0.3 else a.longa
    if s <= 0.01:                                           # silêncio do começo: entra logo antes da primeira palavra
        cur = max(0.0, e - 0.03)
        continue
    if e >= dur - 0.01:                                     # silêncio do fim: deixa uma cauda curta
        manter.append([cur, min(dur, s + 0.15)])
        cur = None
        break
    if e - s <= sobra:
        continue
    manter.append([cur, s + sobra / 2])
    cur = e - sobra / 2
if cur is not None:
    manter.append([cur, dur])

FADE = 0.006
partes, rotulos, trechos, pos = [], [], [], 0.0
for i, (s, e) in enumerate(manter):
    d = e - s
    partes.append(f"[0:a]atrim={s:.4f}:{e:.4f},asetpts=PTS-STARTPTS,afade=t=in:d={FADE},afade=t=out:st={d - FADE:.4f}:d={FADE}[p{i}]")
    rotulos.append(f"[p{i}]")
    trechos.append([round(s, 4), round(e, 4), round(pos / a.tempo, 4)])
    pos += d
grafo = ";".join(partes) + f";{''.join(rotulos)}concat=n={len(manter)}:v=0:a=1,atempo={a.tempo}[o]"
subprocess.check_call(["ffmpeg", "-v", "error", "-y", "-i", str(src), "-filter_complex", grafo, "-map", "[o]", "-ar", "48000", str(out)])
novo = pos / a.tempo
mapa = src.with_name(src.stem + a.nome + "_mapa.json")
mapa.write_text(json.dumps({"trechos": trechos, "antes": round(dur, 3), "depois": round(novo, 3), "tempo": a.tempo}), encoding="utf-8")
maior = max((e - s for s, e in pausas), default=0)
print(f"{out}  ·  {dur:.2f} s -> {novo:.2f} s  ·  {len(pausas)} pausas encurtadas (a maior tinha {maior:.2f} s)  ·  mapa em {mapa.name}")
