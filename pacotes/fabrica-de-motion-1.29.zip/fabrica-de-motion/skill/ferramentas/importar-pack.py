#!/usr/bin/env python3
"""Importa o Pack 50 Estilos de Motion para o painel: os vídeos viram modelos (com filtro por nicho) e cada estilo
leva junto a pasta com o código e a ficha ESTILO.md, que o Claude usa quando o modelo é escolhido.

  importar-pack.py                 procura o zip (ou a pasta descompactada) em Downloads, Mesa e Documentos
  importar-pack.py <zip ou pasta>  usa esse
  importar-pack.py --achar         só diz onde achou (ou "nada"), sem importar

Copia para <entregas>/Pack 50 Estilos/: um NN-estilo.mp4 por estilo e estilos/NN-estilo/ (código, ESTILO.md, quadros).
Cria o cliente "Pack 50 Estilos" no painel e a lista painel/pack-estilos.json (nome, nicho e pasta de cada estilo).
Não sobrescreve nada: o que já existe fica como está, então dá para rodar de novo sem perder trabalho.
"""
import json, pathlib, re, shutil, sys, tempfile, zipfile

AQUI = pathlib.Path(__file__).resolve().parent.parent
CFG = json.loads((AQUI / "config.json").read_text(encoding="utf-8"))
casa = lambda p: pathlib.Path(str(p).replace("~", str(pathlib.Path.home()), 1)) if str(p).startswith("~") else pathlib.Path(p)
PAINEL, ENTREGAS = casa(CFG["painel"]), casa(CFG["entregas"])
DESTINO = ENTREGAS / "Pack 50 Estilos"


def eh_pack(p):
    """zip ou pasta que tem INDICE.md e estilos/NN-*/exemplo.mp4"""
    try:
        if p.is_file() and p.suffix.lower() == ".zip":
            with zipfile.ZipFile(p) as z:
                nomes = z.namelist()
            return any(n.endswith("INDICE.md") for n in nomes) and any(re.search(r"estilos/\d\d-[^/]+/exemplo\.mp4$", n) for n in nomes)
        if p.is_dir():
            return (p / "INDICE.md").is_file() and any(p.glob("estilos/[0-9][0-9]-*/exemplo.mp4"))
    except (OSError, zipfile.BadZipFile):
        return False
    return False


def achar():
    h = pathlib.Path.home()
    lugares = [h / "Downloads", h / "Desktop", h / "Mesa", h / "Documents", h / "Documentos"]
    candidatos = []
    for d in lugares:
        if not d.is_dir():
            continue
        candidatos += sorted(d.glob("Pack-50-Estilos*.zip")) + sorted(d.glob("Pack-50-Estilos*/")) + sorted(d.glob("Pack 50 Estilos*/"))
        candidatos += [x.parent for x in d.glob("*/INDICE.md")]
    for c in sorted(set(candidatos), key=lambda x: -x.stat().st_mtime):
        if eh_pack(c):
            return c
    return None


def indice(raiz):
    """lê a tabela do INDICE.md: número → (estilo, categoria)"""
    tab = {}
    for linha in (raiz / "INDICE.md").read_text(encoding="utf-8").splitlines():
        m = re.match(r"\|\s*(\d\d)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|", linha)
        if m:
            tab[m.group(1)] = (m.group(2), m.group(3))
    return tab


def importar(origem):
    with tempfile.TemporaryDirectory() as tmp:
        raiz = origem
        if origem.is_file():
            with zipfile.ZipFile(origem) as z:
                for n in z.namelist():   # nada de caminho absoluto ou ".." saindo da pasta temporária
                    if n.startswith("/") or ".." in pathlib.PurePosixPath(n).parts:
                        sys.exit(f"zip com caminho estranho: {n}")
                z.extractall(tmp)
            achados = [p.parent for p in pathlib.Path(tmp).rglob("INDICE.md")]
            if not achados:
                sys.exit("não achei o INDICE.md dentro do zip")
            raiz = achados[0]
        tab = indice(raiz)
        (DESTINO / "estilos").mkdir(parents=True, exist_ok=True)
        lista, novos = [], 0
        for pasta in sorted((raiz / "estilos").glob("[0-9][0-9]-*")):
            num = pasta.name[:2]
            video = pasta / "exemplo.mp4"
            if not video.is_file():
                continue
            estilo, categoria = tab.get(num, (pasta.name[3:].replace("-", " ").capitalize(), "Outros"))
            mp4 = DESTINO / (pasta.name + ".mp4")
            if not mp4.exists():
                shutil.copy2(video, mp4); novos += 1
            dest = DESTINO / "estilos" / pasta.name
            if not dest.exists():
                shutil.copytree(pasta, dest, ignore=shutil.ignore_patterns("exemplo.mp4"))
            lista.append({"arquivo": mp4.name, "rotulo": f"{num} · {estilo}", "categoria": categoria, "pasta": str(dest)})
        for extra in ("LEIA-ME.md", "INDICE.md"):
            if (raiz / extra).is_file() and not (DESTINO / extra).exists():
                shutil.copy2(raiz / extra, DESTINO / extra)
    if not lista:
        sys.exit("nenhum estilo encontrado")
    (PAINEL / "pack-estilos.json").write_text(json.dumps(lista, ensure_ascii=False, indent=1), encoding="utf-8")
    arq = PAINEL / "clientes.json"
    clientes = json.loads(arq.read_text(encoding="utf-8")) if arq.is_file() else []
    if not any(c.get("id") == "pack-estilos" for c in clientes):
        clientes.append({"id": "pack-estilos", "nome": "Pack 50 Estilos", "pasta": "Pack 50 Estilos", "nosso": True, "nicho": "Estilos prontos com código editável",
                         "status": "entregue", "prefixos": [], "notas": [], "pendencias": [], "conversa": [], "codigo": [],
                         "resumo": "Os 50 estilos do Pack. Cada vídeo tem a pasta do estilo com o código e a ficha ESTILO.md."})
        arq.write_text(json.dumps(clientes, ensure_ascii=False, indent=1), encoding="utf-8")
    return len(lista), novos


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    origem = casa(args[0]) if args else achar()
    if "--achar" in sys.argv:
        print(origem if origem else "nada"); sys.exit(0)
    if not origem or not eh_pack(origem):
        sys.exit("Não achei o Pack 50 Estilos. Baixe o Pack-50-Estilos-COMPLETO.zip da área de membros e rode de novo (ou passe o caminho do zip).")
    total, novos = importar(origem)
    print(f"Pack 50 Estilos importado: {total} estilos ({novos} novos) em {DESTINO}")
