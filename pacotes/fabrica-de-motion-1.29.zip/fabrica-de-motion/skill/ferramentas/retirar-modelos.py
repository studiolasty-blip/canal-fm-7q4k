#!/usr/bin/env python3
"""Tira das instalações antigas os modelos que deixaram de vir com a skill.

  retirar-modelos.py <pasta de trabalho>

Roda em toda instalação e atualização (instalar.sh e instalar.ps1). Na 1.22 saíram os três vídeos da própria Fábrica
de Motion e do Creative Radar; quem instalou antes ainda tem as cópias em <trabalho>/entregas/Referências. Só apaga um
arquivo quando o nome E o tamanho são exatamente os da cópia que a skill instalou, para nunca levar um vídeo da pessoa,
e tira esses nomes da lista de destaques do painel. Rodar de novo não faz nada.
"""
import json, pathlib, sys

# nome do arquivo instalado → tamanho em bytes da cópia que veio no pacote (1.11 a 1.21)
RETIRADOS = {
    "05-servico-de-video.mp4": 1117373,
    "06-oferta-com-preco.mp4": 2396290,
    "07-ferramenta-de-anuncios.mp4": 1370357,
}

trabalho = pathlib.Path(sys.argv[1]).expanduser()
pasta = trabalho / "entregas" / "Referências"
tirados = []
for nome, tamanho in RETIRADOS.items():
    f = pasta / nome
    try:
        if f.is_file() and f.stat().st_size == tamanho:
            f.unlink(); tirados.append(nome)
    except OSError:
        pass
# a lista de destaques só perde os nomes cujo arquivo já não existe
dest = trabalho / "painel" / "destaques.json"
try:
    lista = json.loads(dest.read_text(encoding="utf-8"))
    nova = [d for d in lista if not (d.get("arquivo") in RETIRADOS and not (pasta / d["arquivo"]).exists())]
    if len(nova) != len(lista):
        dest.write_text(json.dumps(nova, ensure_ascii=False, indent=1), encoding="utf-8")
except (OSError, ValueError, AttributeError, TypeError):
    pass
print(f"modelos antigos retirados: {len(tirados)}" if tirados else "nenhum modelo antigo para retirar")
