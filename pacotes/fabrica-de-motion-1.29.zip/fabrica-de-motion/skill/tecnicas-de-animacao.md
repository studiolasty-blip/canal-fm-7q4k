# Técnicas de animação (padrão da Fábrica de Motion)

Este é o padrão de animação aplicado em todo vídeo, sem perguntar a ninguém e sem aparecer no roteiro. As regras de
acabamento do SKILL.md continuam valendo por cima destas.

## As 4 ideias de base

1. **Uma tomada só, cada cena nasce da anterior.** Nada de corte seco ou fade genérico: o objeto da cena atual vira a
   próxima cena (o botão cresce e vira a página, a cor de um objeto inunda a tela e encolhe no próximo).
2. **Um elemento-fio que atravessa o vídeo.** Um ponto, uma bola ou uma forma que liga todas as cenas: começa na
   interface, vira o pingo do "i", desenha um gráfico, cresce em forma e volta no final.
3. **Tudo no tempo da música.** 120 BPM ≈ 0,5 s por batida, cena nova a cada compasso (2 s). Alguma coisa acontece em toda
   batida; sem tempo morto.
4. **O que nunca usar:** brilho neon, explosão de partículas, anel de onda,
   tremida de câmera, RGB split, lens flare, chão quadriculado, fundo piscando, easing que quica demais.

## Catálogo

| # | Técnica | O que é | Quando usar | Como fazer no Remotion |
|---|---|---|---|---|
| 1 | **Texto que sobe da linha (máscara)** | A palavra nasce de baixo de uma linha invisível, cortada pela máscara | Títulos e chamadas em qualquer vídeo; respeita a regra do texto parado (entra e para) | `overflow: hidden` no contêiner + `translateY(100%→0)` com `spring({damping: 200})`; palavra por palavra com atraso de 3–4 quadros |
| 2 | **Palavra por palavra na batida** | O gancho entra uma palavra por batida | Abertura de anúncio (os 2 primeiros segundos) | Dividir a frase em palavras; cada uma entra no quadro `beat * k` |
| 3 | **Forma que se transforma (morph)** | Um mesmo retângulo muda tamanho, raio e cor e vira botão → loader → check → card | App, SaaS, produto digital | Um só `<div>`; `interpolate` em width/height/borderRadius/background a partir de springs; conteúdo troca com blur curto (4–6 px) |
| 4 | **Cursor de verdade** | Um cursor clica, arrasta e segura; cada clique dispara a mudança | Mostrar app ou site funcionando | SVG do cursor andando com spring até o alvo; no clique, `scale(0.9)` por 4 quadros + anel discreto |
| 5 | **Câmera estilo Screen Studio** | A câmera dá zoom para que cada interação ocupe o quadro | Telas de app e site (print do cliente) | Um contêiner "mundo" com `transform: scale() translate()` animado; uma câmera só, nunca dois movimentos ao mesmo tempo, nunca zoom in e out seguidos |
| 6 | **Inundação de cor** | Uma forma (círculo saindo do botão) cresce até cobrir a tela e vira o fundo da próxima cena | Transição entre blocos; virada de claro para escuro no "drop" | Círculo com `clip-path: circle(r at x y)` animando r de 0 a 150% |
| 7 | **Spring com pouco overshoot** | Movimento com mola, passando só um pouquinho do ponto | Em tudo; substitui o easing que quica | `spring({fps, frame, config: {damping: 18, stiffness: 120}})`; overshoot de no máximo 3–5% |
| 8 | **Bordas em molas diferentes** | Num indicador de aba ou num toggle, a borda da frente anda antes da de trás, então ele estica | Abas, sliders, barras de progresso | Calcular `left` e `right` com springs de rigidez diferente |
| 9 | **Barra e gráfico que se desenham** | Linha ou barra crescendo do zero; o número conta junto | Resultado, preço, comparação | `strokeDashoffset` no SVG; contador com `Math.round(interpolate(...))` em fonte tabular |
| 10 | **Ícone que pula do zero** | Ícone entra de `scale(0)` com spring | Listas de benefícios | Atraso de 3 quadros entre ícones (stagger) |
| 11 | **Desfoque de movimento** | O borrão acompanha a velocidade e a direção | Movimentos rápidos de câmera e entrada de cartões | `filter: blur()` proporcional à velocidade do spring; ou render com subquadros |
| 12 | **Toda cena entra já em movimento** | Nenhuma cena começa parada: entra desacelerando e sai acelerando | Anúncios rápidos | Começar o spring de câmera antes do corte; terminar a cena acelerando (`Easing.in`) |
| 13 | **Final igual ao começo (loop)** | O último quadro é o primeiro | Reels e stories que repetem | Última cena volta ao estado da primeira |
| 14 | **Página 3D sobrevoada** | O site do cliente deitado num "chão" de estúdio, com a câmera planando por cima | Lançamento de site e landing page | Print longo da página; `perspective` + `rotateX(55deg)`; câmera desliza; foco raso com blur nas pontas |
| 15 | **Vidro líquido sobre foto** | Painéis translúcidos (estilo iOS) por cima das fotos do cliente | Vitrine com muitas fotos (imóvel, moda, comida) | `backdrop-filter: blur(20px)` + borda branca 1 px a 30% |
| 16 | **Notas de marcador** | Rabiscos e setas desenhados à mão por cima, na cor de destaque | Explicar um ponto, uma pegadinha, um detalhe | Path SVG com `strokeDashoffset`; traço irregular |
| 17 | **Virada claro/escuro no drop** | Fundo claro na primeira metade e escuro a partir da batida forte | Anúncio com música que tem drop | Inundação de cor (#6) cronometrada no drop |
| 18 | **Som em cada entrada** | Um efeito curto e suave por elemento que aparece, silêncio no resto | Em todo vídeo | Efeitos no mesmo quadro de cada entrada (veja a seção Som do SKILL.md) |

## Receita de prompt (quando pedirem um vídeo "estilo Apple")

O formato que os melhores prompts usam, em 4 blocos:

- **inputs:** o que pedir ao cliente (marca, 3 a 5 momentos do produto, cor de destaque, fotos, música).
- **direção:** o look em 3 linhas (fundo, cor de destaque, fonte) + o jeito da câmera + a lista de proibidos.
- **estrutura:** compasso por compasso ("compasso 1: o gancho entra palavra por palavra; compasso 2: uma palavra vira a tela
  do produto; no drop: um círculo sai do botão e vira a cena escura…").
- **construção:** como renderizar e conferir (um quadro por batida antes do render final).
