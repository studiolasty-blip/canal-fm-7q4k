#!/usr/bin/env python3
"""Fichário de clientes da Fábrica de Motion: uma conversa só, com o contexto de cada cliente guardado em arquivo.

uso:
  cliente.py lista                                   quem está esperando o quê
  cliente.py abrir <nome ou id>                      mostra a ficha, as anotações e as últimas entregas
  cliente.py novo "<Nome>" --nicho "..." [--id x]    cria ficha, anotações e a entrada no painel
  cliente.py pasta <id>                              cria e mostra a pasta onde entra a entrega de hoje
  cliente.py registrar <id> <Cliente|Eu|Entrega> "<texto>"   acrescenta uma linha ao histórico
  cliente.py pendencia <id> --add "<texto>" --de voce|cliente | --feita <número>   põe ou tira uma pendência (e diz de quem é a vez)
  cliente.py resumo <id> "<texto>"                   troca o "onde paramos"
  cliente.py caixa [--lida <n|todas>] [--vigiar]     recados escritos no painel que ainda não foram tratados
  cliente.py logo <id> <arquivo de imagem>           guarda o logo do cliente para o painel mostrar ao lado do nome
  cliente.py etapa <id> <etapa>                      levantamento|roteiro|voz|montagem|som|conferencia|entrega (aparece no painel)

Os caminhos vêm de config.json ao lado deste arquivo (painel, entregas, pasta dos projetos).
"""
import argparse, datetime, json, re, sys, unicodedata
import glob
for _saida in (sys.stdout, sys.stderr):                     # no Windows a saída padrão não é UTF-8: sem isto os acentos quebram
    try:
        _saida.reconfigure(encoding="utf-8")
    except Exception:
        pass
from pathlib import Path

AQUI = Path(__file__).resolve().parent
CFG = json.loads((AQUI / "config.json").read_text(encoding="utf-8"))
PAINEL = Path(CFG["painel"]).expanduser()
ENTREGAS = Path(CFG["entregas"]).expanduser()                              # uma subpasta por cliente
ANTIGAS = Path(CFG.get("entregas_antigas", CFG["entregas"])).expanduser()   # arquivos soltos, achados pelo prefixo
PROJETOS = Path(CFG["projetos"]).expanduser()
DADOS = PAINEL / "clientes.json"


def slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def ler():
    return json.loads(DADOS.read_text(encoding="utf-8")) if DADOS.exists() else []


def gravar(c):
    PAINEL.mkdir(parents=True, exist_ok=True)
    DADOS.write_text(json.dumps(c, ensure_ascii=False, indent=1), encoding="utf-8")


def achar(clientes, quem):
    q = slug(quem)
    for c in clientes:
        if c["id"] == quem or slug(c["nome"]) == q:
            return c
    cand = [c for c in clientes if q in slug(c["nome"]) or q in c["id"]]
    if len(cand) == 1:
        return cand[0]
    sys.exit(f"Não achei um cliente único para '{quem}'. Opções: " + ", ".join(c["id"] for c in (cand or clientes)))


MIDIA = {".mp4", ".mov", ".png", ".jpg", ".jpeg", ".webp"}


# "pastas" em config.json: "cliente" (padrão) = <entregas>/<Cliente>/ · "data" = <entregas>/<ano>/<mês>/Dia <dia>/<Cliente>/
POR_DATA = CFG.get("pastas", "cliente") == "data"
MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]


def pasta_do_dia(nome, dia):
    return ENTREGAS / f"{dia.year}" / f"{dia.month:02d} - {MESES[dia.month - 1]}" / f"Dia {dia.day:02d}" / nome


def pasta(c, criar=True):
    """Onde entram as entregas novas deste cliente. Por data, é a pasta de hoje: só é criada na hora de entregar."""
    nome = c.get("pasta") or c["nome"]
    p = pasta_do_dia(nome, datetime.date.today()) if POR_DATA else ENTREGAS / nome
    if criar:
        p.mkdir(parents=True, exist_ok=True)
    return p


def pastas(c):
    """Todas as pastas em que este cliente tem entregas: a dele (organização por cliente) e as de cada dia."""
    nome = c.get("pasta") or c["nome"]
    return [d for d in [ENTREGAS / nome] + sorted(d for padrao in ("Dia [0-9][0-9]", "[0-9][0-9]") for d in ENTREGAS.glob("[0-9][0-9][0-9][0-9]/*/" + padrao + "/" + glob.escape(nome))) if d.is_dir()]


def entregas(c):
    fs = [p for d in pastas(c) for p in d.iterdir() if p.is_file() and p.suffix.lower() in MIDIA]
    if ANTIGAS.is_dir():
        fs += [p for p in ANTIGAS.iterdir() if p.is_file() and any(p.name.startswith(px) for px in c.get("prefixos", []))]
    return sorted(fs, key=lambda p: -p.stat().st_mtime)


def ficha(c):
    L = [f"# {c['nome']}", "", f"Nicho: {c.get('nicho', '')}", "", "## Onde paramos", c.get("resumo", ""), "", "## Falta resolver"]
    L += [f"- {p}" for p in c.get("pendencias", [])] or ["- Nada pendente."]
    L += ["", "## O que já aconteceu"] + [f"- {l['data']} · {l['quem']}: {l['texto']}" for l in c.get("conversa", [])]
    if c.get("roteiro"):
        L += ["", "## Roteiro enviado", c["roteiro"]]
    L += ["", "## Onde está cada coisa", (f"- Entregas de hoje vão para: {pasta(c, criar=False)}/ (a pasta muda a cada dia: na hora de entregar rode `cliente.py pasta {c['id']}`, que cria e mostra a pasta do dia; nome do arquivo começa com: {', '.join(c.get('prefixos', []))})" if POR_DATA else f"- Entregas vão para: {pasta(c)}/ (nome do arquivo começa com: {', '.join(c.get('prefixos', []))})")]
    L += [f"- Anotações de produção: {n}" for n in c.get("notas", [])]
    L += [f"- {x}" for x in c.get("codigo", [])]
    (PAINEL / "fichas").mkdir(parents=True, exist_ok=True)
    (PAINEL / "fichas" / f"{c['id']}.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("lista")
    a = sub.add_parser("abrir"); a.add_argument("quem")
    sub.add_parser("pasta").add_argument("quem")
    n = sub.add_parser("novo"); n.add_argument("nome"); n.add_argument("--nicho", default=""); n.add_argument("--prefixo"); n.add_argument("--id")
    r = sub.add_parser("registrar"); r.add_argument("quem"); r.add_argument("autor", choices=["Cliente", "Eu", "Entrega"]); r.add_argument("texto")
    p = sub.add_parser("pendencia"); p.add_argument("quem"); p.add_argument("--add"); p.add_argument("--feita", type=int); p.add_argument("--de", choices=["voce", "cliente"])
    s = sub.add_parser("resumo"); s.add_argument("quem"); s.add_argument("texto")
    cx = sub.add_parser("caixa"); cx.add_argument("--lida"); cx.add_argument("--vigiar", action="store_true")
    lg = sub.add_parser("logo"); lg.add_argument("quem"); lg.add_argument("arquivo")
    e = sub.add_parser("etapa"); e.add_argument("quem"); e.add_argument("etapa", choices=["levantamento", "roteiro", "voz", "montagem", "som", "conferencia", "entrega"])
    args = ap.parse_args()
    clientes = ler()
    hoje = datetime.date.today().strftime("%d/%m")

    if args.cmd == "caixa":
        arq = PAINEL / "caixa.json"
        if args.vigiar:                                         # fica rodando e avisa de cada recado novo
            import time
            nomes = {c["id"]: c["nome"] for c in clientes}
            visto = max([r["n"] for r in (json.loads(arq.read_text(encoding="utf-8")) if arq.exists() else [])] or [0])
            while True:
                time.sleep(1.5)
                try:
                    novos = [r for r in json.loads(arq.read_text(encoding="utf-8")) if r["n"] > visto and not r.get("lida")] if arq.exists() else []
                except (ValueError, OSError):
                    continue
                for r in novos:
                    visto = r["n"]
                    extra = f" [+{len(r['anexos'])} anexo(s)]" if r.get("anexos") else ""
                    print(f"recado #{r['n']} no painel · {nomes.get(r['id'], r['id'])} ({r['id']}): {r['texto']}{extra}".replace("\n", " "), flush=True)
        caixa = json.loads(arq.read_text(encoding="utf-8")) if arq.exists() else []
        if args.lida:
            for r in caixa:
                if args.lida == "todas" or str(r["n"]) == args.lida:
                    r["lida"] = True
            arq.write_text(json.dumps(caixa, ensure_ascii=False, indent=1), encoding="utf-8")
        abertos = [r for r in caixa if not r.get("lida")]
        nomes = {c["id"]: c["nome"] for c in clientes}
        for r in abertos:
            print(f"#{r['n']} · {nomes.get(r['id'], r['id'])} ({r['id']}) · {r['quando'][:16].replace('T', ' ')}\n   {r['texto']}")
            for x in r.get("anexos", []):
                print(f"   anexo: {PAINEL / x.lstrip('/')}")
        if not abertos:
            print("Nenhum recado pendente.")
        return
    if args.cmd == "lista":
        if not clientes:
            print("Nenhum cliente ainda. Crie o primeiro com: cliente.py novo \"<Nome>\" --nicho \"...\"")
        for c in clientes:
            fs = entregas(c)
            ult = datetime.datetime.fromtimestamp(fs[0].stat().st_mtime).strftime("%d/%m %H:%M") if fs else "sem entrega"
            print(f"{c['id']:10s} {c['nome'][:34]:34s} pendências: {len(c.get('pendencias', []))}  entregas: {len(fs):2d}  última: {ult}")
        return
    if args.cmd == "novo":
        cid = slug(args.id) if args.id else slug(args.nome).split("-")[0] if len(slug(args.nome)) > 12 else slug(args.nome)
        usados = {c["id"] for c in clientes}
        mesmo = next((c for c in clientes if slug(c["nome"]) == slug(args.nome)), None)
        if mesmo:
            sys.exit(f"Já existe o cliente '{mesmo['id']}'.")
        if cid in usados:                                       # outro cliente com o mesmo começo de nome (ex.: dois "Gabriel")
            for cand in [slug(args.nome)[:40].rstrip("-")] + [f"{cid}-{n}" for n in range(2, 100)]:
                if cand not in usados:
                    cid = cand; break
        pasta_proj = PROJETOS / cid
        (pasta_proj / "src").mkdir(parents=True, exist_ok=True)
        notas = pasta_proj / "notas.md"
        if not notas.exists():
            notas.write_text(f"# {args.nome}\n\nPedido ({datetime.date.today().isoformat()}):\n\n## Identidade\n\n## Material (src/)\n\n## Estado\n", encoding="utf-8")
        prefixo = args.prefixo or "-".join(w.capitalize() for w in slug(args.nome).split("-"))
        limpo = re.sub(r'[\\/:*?"<>|·()]+', " ", args.nome); limpo = re.sub(r"\s+", " ", limpo).strip()
        c = {"id": cid, "nome": args.nome, "pasta": limpo, "nicho": args.nicho, "status": "em andamento", "prefixos": [prefixo], "notas": [str(notas)], "resumo": "Cliente novo: material recebido, roteiro ainda não enviado.", "pendencias": [], "conversa": [], "codigo": []}
        clientes.insert(0, c); gravar(clientes); ficha(c)
        print(f"Criado: id {cid} · material em {pasta_proj} · entregas em {pasta(c, criar=not POR_DATA)}/ com prefixo '{prefixo}-'")
        return

    c = achar(clientes, args.quem)

    if args.cmd == "pasta":                                    # cria e mostra onde entra a entrega de hoje

        print(pasta(c))

        return
    if args.cmd == "abrir":
        ficha(c)
        print((PAINEL / "fichas" / f"{c['id']}.md").read_text(encoding="utf-8"))
        fs = entregas(c)
        print("## Últimas entregas")
        for f in fs[:5]:
            print(f"- {f.name}  ({datetime.datetime.fromtimestamp(f.stat().st_mtime).strftime('%d/%m %H:%M')})")
        if not fs:
            print("- nenhuma")
        return
    if args.cmd == "registrar":
        c.setdefault("conversa", []).append({"data": hoje, "quem": args.autor, "texto": args.texto})
    elif args.cmd == "pendencia":
        if args.add:
            c.setdefault("pendencias", []).append(({"voce": "Você: ", "cliente": "Cliente: "}.get(args.de, "")) + args.add)
        if args.feita:
            c["pendencias"].pop(args.feita - 1)
    elif args.cmd == "resumo":
        c["resumo"] = args.texto
    elif args.cmd == "etapa":
        c["etapa"] = args.etapa
    elif args.cmd == "logo":
        import shutil
        src = Path(args.arquivo).expanduser()
        if not src.is_file() or src.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
            sys.exit(f"Preciso de uma imagem PNG, JPG ou WebP: {src}")
        (PAINEL / "logos").mkdir(parents=True, exist_ok=True)
        for velho in (PAINEL / "logos").glob(c["id"] + ".*"):
            velho.unlink()
        shutil.copyfile(src, PAINEL / "logos" / (c["id"] + src.suffix.lower()))
        try:                                                    # no Mac, reduz para 256 px: o painel só mostra o logo pequeno
            import subprocess
            subprocess.run(["sips", "-Z", "256", str(PAINEL / "logos" / (c["id"] + src.suffix.lower()))], capture_output=True)
        except OSError:
            pass
        c["logo"] = c["id"] + src.suffix.lower()
    c["status"] = "aguardando cliente" if c.get("pendencias") else c.get("status", "entregue")
    gravar(clientes); ficha(c)
    print(f"ok · {c['nome']}: {len(c.get('conversa', []))} linhas no histórico, {len(c.get('pendencias', []))} pendências")


if __name__ == "__main__":
    main()
