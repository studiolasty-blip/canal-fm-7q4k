#!/usr/bin/env python3
"""Grava a narração no ElevenLabs (modelo v3) a partir do roteiro em texto.

  voz.py "texto da narração" --voz "Roberta" --saida ~/Movies/<cliente>/src/voz.mp3
  voz.py --arquivo narracao.txt --voz "Marcos Alves" --saida voz.mp3
  voz.py --vozes          lista as vozes da conta (nome e código)
  voz.py --pronto         diz se a chave está guardada (código de saída 0 = sim)

O texto vai com as marcações do v3 ([warm], [short pause]…) do jeito que está no roteiro.
A chave e a voz padrão ficam em ~/.config/fabrica-de-motion/elevenlabs.json; quem grava esse arquivo é o painel
(aba Ajustes, "Voz automática"). Cada gravação gasta créditos da conta: o mesmo texto com a mesma voz não é gravado
duas vezes, a não ser com --de-novo.
"""
import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, sys, unicodedata, urllib.error, urllib.request
for _saida in (sys.stdout, sys.stderr):                     # no Windows a saída padrão não é UTF-8: sem isto os acentos quebram
    try:
        _saida.reconfigure(encoding="utf-8")
    except Exception:
        pass

CFG = pathlib.Path.home() / ".config" / "fabrica-de-motion" / "elevenlabs.json"
API = "https://api.elevenlabs.io"


def config():
    try:
        c = json.loads(CFG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        c = {}
    if not c.get("chave") and os.environ.get("ELEVENLABS_API_KEY"):
        c["chave"] = os.environ["ELEVENLABS_API_KEY"]
    return c


def chamar(caminho, chave, corpo=None, espera=180):
    req = urllib.request.Request(API + caminho, data=json.dumps(corpo).encode() if corpo is not None else None,
                                 headers={"xi-api-key": chave, "Content-Type": "application/json", "Accept": "*/*"})
    try:
        with urllib.request.urlopen(req, timeout=espera) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        bruto = e.read().decode("utf-8", "replace")
        try:
            d = json.loads(bruto).get("detail")
            msg = d.get("message") or d.get("status") if isinstance(d, dict) else str(d)
        except ValueError:
            msg = bruto[:300]
        dica = {401: " A chave não foi aceita: confira a chave na aba Ajustes do painel.", 402: " Faltam créditos na conta.", 429: " Muitas gravações ao mesmo tempo ou limite da conta: espere um pouco."}.get(e.code, "")
        sys.exit(f"ElevenLabs recusou ({e.code}): {msg}.{dica}")
    except urllib.error.URLError as e:
        sys.exit(f"Não consegui falar com o ElevenLabs: {e.reason}. Se o comando roda numa área isolada, repita fora dela.")


def simples(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def vozes(chave):
    return [(v["name"], v["voice_id"], (v.get("labels") or {}).get("gender", "")) for v in json.loads(chamar("/v1/voices", chave, espera=40)).get("voices", [])]


def achar_voz(chave, pedido):
    if re.fullmatch(r"[A-Za-z0-9]{18,28}", pedido):          # já é o código da voz
        return pedido, pedido
    todas, alvo = vozes(chave), simples(pedido)
    for teste in (lambda n: simples(n) == alvo, lambda n: simples(n).startswith(alvo), lambda n: alvo in simples(n)):
        achadas = [v for v in todas if teste(v[0])]
        if len(achadas) == 1:
            return achadas[0][0], achadas[0][1]
        if len(achadas) > 1:
            sys.exit("Mais de uma voz com esse nome: " + "; ".join(n for n, _, _ in achadas) + ". Escreva o nome inteiro.")
    sys.exit(f"Não achei a voz '{pedido}' na conta. Vozes disponíveis: " + "; ".join(n for n, _, _ in todas))


def main():
    ap = argparse.ArgumentParser(description="Grava a narração no ElevenLabs v3.")
    ap.add_argument("texto", nargs="?")
    ap.add_argument("--arquivo", help="arquivo de texto com a narração")
    ap.add_argument("--voz", help="nome ou código da voz (padrão: a voz guardada no painel)")
    ap.add_argument("--saida", help="arquivo mp3 de saída")
    ap.add_argument("--modelo", default="eleven_v3")
    ap.add_argument("--estabilidade", type=float, default=0.5, choices=[0.0, 0.5, 1.0], help="0 = mais expressiva, 0.5 = natural, 1 = mais firme")
    ap.add_argument("--de-novo", action="store_true", help="grava de novo mesmo que esse texto já tenha sido gravado com essa voz")
    ap.add_argument("--vozes", action="store_true")
    ap.add_argument("--pronto", action="store_true")
    a = ap.parse_args()

    c = config()
    if a.pronto:
        print("Chave do ElevenLabs guardada." + (f" Voz padrão: {c['voz']}." if c.get("voz") else " Sem voz padrão.") if c.get("chave") else "Sem chave do ElevenLabs: peça à pessoa para colar a chave na aba Ajustes do painel, ou para mandar o mp3 gravado.")
        sys.exit(0 if c.get("chave") else 1)
    if not c.get("chave"):
        sys.exit("Sem chave do ElevenLabs. A pessoa cola a chave na aba Ajustes do painel (Voz automática). Enquanto isso, peça o mp3 gravado.")
    if a.vozes:
        for nome, cod, genero in sorted(vozes(c["chave"])):
            print(f"{nome}  ·  {cod}" + (f"  ·  {genero}" if genero else ""))
        return

    texto = pathlib.Path(a.arquivo).expanduser().read_text(encoding="utf-8") if a.arquivo else (a.texto or "")
    texto = re.sub(r"[ \t]+", " ", texto).strip()
    if not texto:
        sys.exit("Faltou o texto da narração (entre aspas, ou --arquivo).")
    pedido = a.voz or c.get("voz")
    if not pedido:
        sys.exit("Faltou a voz: use --voz \"Nome\" (veja os nomes com --vozes) ou guarde uma voz padrão na aba Ajustes do painel.")
    nome, cod = achar_voz(c["chave"], pedido)

    marca = hashlib.sha1(f"{cod}|{a.modelo}|{a.estabilidade}|{texto}".encode()).hexdigest()[:8]
    saida = pathlib.Path(a.saida).expanduser() if a.saida else pathlib.Path(f"voz-{simples(nome).replace(' ', '-')[:24]}-{marca}.mp3")
    registro = saida.with_suffix(".voz.json")
    if saida.exists() and not a.de_novo:
        try:
            igual = json.loads(registro.read_text(encoding="utf-8")).get("marca") == marca
        except (OSError, ValueError):
            igual = not a.saida
        if igual:
            print(f"Já gravado com esse texto e essa voz ({nome}): {saida}  (use --de-novo para gastar outra gravação)")
            return
        if a.saida:                                             # nunca apaga a gravação anterior: a nova ganha outro nome
            saida = saida.with_name(f"{saida.stem}-{marca}.mp3"); registro = saida.with_suffix(".voz.json")

    corpo = {"text": texto, "model_id": a.modelo, "voice_settings": {"stability": a.estabilidade}}
    audio = chamar(f"/v1/text-to-speech/{cod}?output_format=mp3_44100_128", c["chave"], corpo)
    if len(audio) < 2000:
        sys.exit("O ElevenLabs devolveu um áudio vazio. Tente de novo.")
    saida.parent.mkdir(parents=True, exist_ok=True)
    saida.write_bytes(audio)
    registro.write_text(json.dumps({"marca": marca, "voz": nome, "codigo": cod, "modelo": a.modelo, "estabilidade": a.estabilidade, "texto": texto}, ensure_ascii=False, indent=1), encoding="utf-8")
    dur = ""
    if shutil.which("ffprobe"):
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(saida)], capture_output=True, text=True)
        dur = f" · {float(r.stdout.strip()):.1f} s" if r.stdout.strip() else ""
    print(f"Gravado: {saida}  ·  voz {nome}  ·  {a.modelo}  ·  {len(texto)} caracteres{dur}")


if __name__ == "__main__":
    main()
