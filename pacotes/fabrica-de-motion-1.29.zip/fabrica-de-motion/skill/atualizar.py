#!/usr/bin/env python3
"""Atualiza a Fábrica de Motion: baixa a versão nova e instala por cima, sem tocar em clientes, vídeos e ajustes.

  atualizar.py --ver          diz se há versão nova e o que mudou
  atualizar.py                baixa e instala a versão nova
  atualizar.py --religar      o mesmo, e religa o painel no fim (é o que o botão Atualizar do painel usa)

A versão instalada está em versao.txt e o endereço das atualizações em canal.txt, os dois ao lado deste arquivo.
O pacote baixado é conferido pelo código de verificação (sha256) publicado junto antes de ser instalado.
"""
import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, sys, tempfile, time, urllib.parse, urllib.request, zipfile

for _saida in (sys.stdout, sys.stderr):                     # no Windows a saída padrão não é UTF-8: sem isto os acentos quebram
    try:
        _saida.reconfigure(encoding="utf-8")
    except Exception:
        pass

AQUI = pathlib.Path(__file__).resolve().parent
WIN = os.name == "nt"


def ler(nome):
    try:
        return (AQUI / nome).read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def num(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0")) or (0,)


def baixar(url, espera=60):
    if url.startswith("http"):                              # o GitHub guarda cópia por alguns minutos: o sufixo pede a atual
        url += ("&" if "?" in url else "?") + "t=" + str(int(time.time()))
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "fabrica-de-motion"}), timeout=espera) as r:
        return r.read()


def manifesto(canal):
    m = json.loads(baixar(canal, 20).decode("utf-8"))
    if not m.get("versao") or not m.get("arquivo"):
        raise ValueError("o endereço das atualizações respondeu algo que não é a lista de versões")
    return m


def marcar(arquivo, estado, msg=""):
    if arquivo:
        try:
            pathlib.Path(arquivo).write_text(json.dumps({"estado": estado, "msg": msg, "quando": time.strftime("%Y-%m-%d %H:%M:%S")}, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass


def main():
    ap = argparse.ArgumentParser(description="Atualiza a Fábrica de Motion.")
    ap.add_argument("--ver", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--religar", action="store_true")
    ap.add_argument("--estado", help="arquivo onde o painel acompanha o andamento")
    a = ap.parse_args()

    atual, canal = ler("versao.txt") or "0", ler("canal.txt")
    if not canal:
        msg = "Esta instalação não tem endereço de atualizações (canal.txt)."
        print(json.dumps({"tem": False, "atual": atual, "msg": msg}, ensure_ascii=False) if a.json else msg)
        sys.exit(0 if a.ver else 1)
    try:
        m = manifesto(canal)
    except Exception as e:
        msg = f"Não consegui consultar as atualizações: {e}"
        marcar(a.estado, "falhou", msg)
        print(json.dumps({"tem": True, "atual": atual, "erro": msg}, ensure_ascii=False) if a.json else msg)
        sys.exit(0 if a.ver else 1)
    nova, notas = str(m["versao"]), [str(n) for n in m.get("notas", [])]
    disponivel = num(nova) > num(atual)

    if a.ver:
        if a.json:
            print(json.dumps({"tem": True, "atual": atual, "nova": nova, "disponivel": disponivel, "notas": notas}, ensure_ascii=False))
        elif disponivel:
            print(f"Há uma versão nova: {nova} (instalada: {atual}).\nO que mudou:\n" + "\n".join("- " + n for n in notas))
        else:
            print(f"A Fábrica de Motion já está na versão mais nova ({atual}).")
        return
    if not disponivel:
        marcar(a.estado, "ok", f"Já está na versão mais nova ({atual}).")
        print(f"A Fábrica de Motion já está na versão mais nova ({atual}).")
        return

    marcar(a.estado, "rodando", f"Baixando a versão {nova}…")
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="fabrica-atualizar-"))
    try:
        dados = baixar(urllib.parse.urljoin(canal, m["arquivo"]), 300)
        if m.get("sha256") and hashlib.sha256(dados).hexdigest() != m["sha256"]:
            raise RuntimeError("o arquivo baixado não confere com o código de verificação; nada foi instalado")
        (tmp / "pacote.zip").write_bytes(dados)
        with zipfile.ZipFile(tmp / "pacote.zip") as z:
            for nome in z.namelist():                           # nenhum arquivo do pacote pode sair da pasta temporária
                if os.path.isabs(nome) or ".." in pathlib.PurePosixPath(nome).parts:
                    raise RuntimeError("o pacote baixado tem um caminho inválido; nada foi instalado")
            z.extractall(tmp)
        raiz = tmp / "fabrica-de-motion"
        if not (raiz / "skill" / "SKILL.md").is_file():
            raise RuntimeError("o pacote baixado não é a Fábrica de Motion; nada foi instalado")
        marcar(a.estado, "rodando", f"Instalando a versão {nova}…")
        cmd = (["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(raiz / "instalar.ps1"), "-Sim", "-SemTeste"] if WIN
               else ["bash", str(raiz / "instalar.sh"), "--sim", "--sem-teste", "--sem-claude"])
        r = subprocess.run(cmd, cwd=str(raiz), capture_output=True, text=True, encoding="utf-8", errors="replace")
        fim = "\n".join((r.stdout + r.stderr).strip().splitlines()[-14:])
        if r.returncode != 0:
            raise RuntimeError("o instalador da versão nova terminou com erro:\n" + fim)
    except Exception as e:
        marcar(a.estado, "falhou", str(e))
        sys.exit(f"A atualização não foi feita: {e}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print(f"Atualizada: {atual} -> {nova}. Clientes, vídeos e ajustes continuam como estavam.")
    for n in notas:
        print("- " + n)
    marcar(a.estado, "ok", f"Versão {nova} instalada.")
    if a.religar:                                               # o painel volta já na versão nova
        try:
            painel = pathlib.Path(json.loads((AQUI / "config.json").read_text(encoding="utf-8"))["painel"]).expanduser()
            node = shutil.which("node") or next((str(p) for p in (pathlib.Path.home() / ".local/bin/node", painel.parent / "_sistema/apoio/node/node.exe", painel.parent / "_sistema/apoio/node/bin/node") if p.exists()), None)
            if node and (painel / "painel.mjs").is_file():
                time.sleep(1.5)                                 # dá tempo de o painel responder a quem pediu a atualização
                r = subprocess.run([node, str(painel / "painel.mjs"), "religar"], capture_output=True, text=True, encoding="utf-8", errors="replace")
                print((r.stdout or "").strip())
        except Exception as e:
            print(f"Atualizada, mas não consegui religar o painel sozinho ({e}). Abra o painel de novo.")


if __name__ == "__main__":
    main()
