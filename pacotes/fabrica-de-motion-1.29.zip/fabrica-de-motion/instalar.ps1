﻿# Instalador da Fábrica de Motion para Windows (skill para o Claude Code).
#
#   powershell -ExecutionPolicy Bypass -File instalar.ps1               instala tudo e roda o teste
#   powershell -ExecutionPolicy Bypass -File instalar.ps1 -Sim          o mesmo, sem perguntar nada (é assim que o Claude roda)
#   powershell -ExecutionPolicy Bypass -File instalar.ps1 -Conferir     não instala nada: só confere a instalação
#   ... -Pasta DIR     pasta de trabalho (padrão: %USERPROFILE%\FabricaDeMotion)
#   ... -Skills DIR    pasta de skills do Claude (padrão: %USERPROFILE%\.claude\skills)
#   ... -SemTeste      pula o vídeo de teste
#
# Programas que faltarem (Node, ffmpeg, uv, Python) são baixados das fontes oficiais para a sua pasta pessoal
# (%USERPROFILE%\.local), sem senha de administrador. Nada é instalado no sistema.
# Nunca apaga nem sobrescreve trabalho seu: arquivos que já existem na pasta de trabalho ficam como estão,
# e uma skill instalada antes é guardada numa cópia com a data.
param([string]$Pasta = "", [string]$Skills = "", [switch]$Sim, [switch]$SemTeste, [switch]$Conferir)

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

$Windows = ($env:OS -eq "Windows_NT")
if (-not $Windows -and -not $env:FM_TESTE_PS1) { Write-Host "Este instalador é para o Windows. No Mac, use: bash instalar.sh"; exit 1 }
$Casa = if ($Windows) { $env:USERPROFILE } else { $env:HOME }
function Junta { $r = $args[0]; for ($i = 1; $i -lt $args.Count; $i++) { $r = [IO.Path]::Combine($r, $args[$i]) }; return $r }
$Aqui = $PSScriptRoot
if (-not $Pasta) { $Pasta = Junta $Casa "FabricaDeMotion"; $PastaDada = $false } else { $PastaDada = $true }
if (-not $Skills) { $Skills = Junta $Casa ".claude" "skills" }
$Skill = Junta $Skills "fabrica-de-motion"
function LivreGB($caminho) { try { return [math]::Floor(([IO.DriveInfo]::new([IO.Path]::GetPathRoot($caminho))).AvailableFreeSpace / 1GB * 10) / 10 } catch { return 9999 } }
function LerPastaDaConfig {
  try { $c = Get-Content (Junta $Skill "config.json") -Raw | ConvertFrom-Json; return (Split-Path ($c.template -replace "^~", $Casa) -Parent) } catch { return $null }
}
# se já existe uma instalação e você não escolheu pasta, a pasta de trabalho dela é mantida
$ManteveAnterior = $false; $MudouDeDisco = $false
if (-not $PastaDada -and (Test-Path (Junta $Skill "config.json"))) {
  $ant = LerPastaDaConfig
  if ($ant -and (Test-Path $ant)) { $Pasta = $ant; $ManteveAnterior = $true }
}
# disco do sistema cheio e outro disco com espaço: a instalação inteira vai para o outro
$RaizCasa = [IO.Path]::GetPathRoot($Casa)
if (-not $PastaDada -and -not $ManteveAnterior -and (LivreGB $Casa) -lt 6) {
  $outro = [IO.DriveInfo]::GetDrives() | Where-Object { $_.DriveType -eq "Fixed" -and $_.IsReady -and $_.Name -ne $RaizCasa -and ($_.AvailableFreeSpace / 1GB) -ge 10 } | Sort-Object AvailableFreeSpace -Descending | Select-Object -First 1
  if ($outro) { $Pasta = Junta $outro.Name "FabricaDeMotion"; $MudouDeDisco = $true }
}
# "outro disco": a pasta de trabalho não está no disco da pasta pessoal. Aí programas, caches, modelo de fala e
# arquivos temporários ficam todos dentro dela (em _sistema), e no disco do sistema sobra só a skill (menos de 1 MB).
$OutroDisco = ([IO.Path]::GetPathRoot($Pasta) -ne $RaizCasa) -or [bool]$env:FM_TESTE_OUTRO_DISCO
$Sis = Junta $Pasta "_sistema"
if ($OutroDisco) { $Local = Junta $Sis "bin"; $Apoio = Junta $Sis "apoio"; $TmpBase = Junta $Sis "tmp" }
else { $Local = Junta $Casa ".local" "bin"; $Apoio = Junta $Casa ".local" "share" "fabrica-de-motion"; $TmpBase = [IO.Path]::GetTempPath() }
$Ambiente = @{}
if ($OutroDisco) {
  $Ambiente = @{ "UV_CACHE_DIR" = (Junta $Sis "cache" "uv"); "UV_PYTHON_INSTALL_DIR" = (Junta $Sis "python"); "UV_PYTHON_BIN_DIR" = $Local; "npm_config_cache" = (Junta $Sis "cache" "npm"); "HF_HOME" = (Junta $Sis "cache" "huggingface") }
  foreach ($d in @($Local, $Apoio, $TmpBase) + @($Ambiente.Values)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
  foreach ($k in $Ambiente.Keys) { [Environment]::SetEnvironmentVariable($k, $Ambiente[$k], "Process") }
  $env:TEMP = $TmpBase; $env:TMP = $TmpBase; $env:TMPDIR = $TmpBase       # só durante a instalação
}
$Sep = [IO.Path]::PathSeparator
$Tmp = Junta $TmpBase ("fabrica-instalar-" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
New-Item -ItemType Directory -Force -Path $Tmp | Out-Null
$Log = Junta $Tmp "registro.txt"
$SemBom = New-Object Text.UTF8Encoding $false
function Escrever($arquivo, $texto) { [IO.File]::WriteAllText($arquivo, $texto, $SemBom) }

# o que muda de um sistema para o outro (fora do Windows só serve para testar este instalador)
if ($Windows) { $Exe = ".exe"; $SoNode = "win-x64"; $ExtNode = "zip"; $AlvoUv = "x86_64-pc-windows-msvc"; $ExtUv = "zip" }
else {
  $Exe = ""; $maq = (& uname -m); $so = (& uname)
  $arq = if ($maq -eq "arm64" -or $maq -eq "aarch64") { "arm64" } else { "x64" }
  $uvArq = if ($arq -eq "arm64") { "aarch64" } else { "x86_64" }
  if ($so -eq "Darwin") { $SoNode = "darwin-$arq"; $AlvoUv = "$uvArq-apple-darwin" } else { $SoNode = "linux-$arq"; $AlvoUv = "$uvArq-unknown-linux-gnu" }
  $ExtNode = "tar.gz"; $ExtUv = "tar.gz"
}

$Erros = 0; $Reabrir = $false
function Ok($t)    { Write-Host "  ok     $t" -ForegroundColor Green }
function Falha($t) { Write-Host "  FALHOU $t" -ForegroundColor Red; $script:Erros++ }
function Aviso($t) { Write-Host "  aviso  $t" -ForegroundColor Yellow }
function Passo($t) { Write-Host ""; Write-Host $t }
function Tem($nome) { return [bool](Get-Command $nome -ErrorAction SilentlyContinue) }
function Perguntar($t) {
  if ($Sim) { return $true }
  try { $r = Read-Host "$t [S/n]" } catch { return $false }
  return ($r -notmatch '^\s*[nN]')
}
function NoCaminho($dir) { if (-not (($env:PATH -split [regex]::Escape($Sep)) -contains $dir)) { $env:PATH = $dir + $Sep + $env:PATH } }
if (Test-Path $Local) { NoCaminho $Local }

# ───────── 1. programas necessários ─────────
Passo "1. Programas necessários"
# no Windows, python3 pode ser só um atalho que abre a loja da Microsoft
function PythonDeVerdade {
  $c = Get-Command python3 -ErrorAction SilentlyContinue
  if (-not $c) { return $false }
  if ($c.Source -like "*WindowsApps*") { return $false }
  if ($env:FM_TESTE_SEM_PYTHON -and $c.Source -eq "/usr/bin/python3") { return $false }      # só para testar o instalador
  return $true
}
function ConferirProgramas {
  $script:Faltam = @()
  if (Tem node) {
    $maior = 0; try { $maior = [int](& node -p "process.versions.node.split('.')[0]") } catch {}
    if ($maior -ge 18) { Ok ("Node " + (& node -v)) } else { Aviso "Node antigo (precisa do 18 ou mais novo)"; $script:Faltam += "node" }
  } else { Aviso "Node não encontrado (roda o projeto de vídeo)"; $script:Faltam += "node" }
  if ((Tem ffmpeg) -and (Tem ffprobe)) { Ok ("ffmpeg " + ((& ffmpeg -version | Select-Object -First 1) -split " ")[2]) } else { Aviso "ffmpeg não encontrado (mixagem e conferência)"; $script:Faltam += "ffmpeg" }
  if (Tem uv) { Ok ("uv " + ((& uv --version) -split " ")[1]) } else { Aviso "uv não encontrado (roda os scripts de som)"; $script:Faltam += "uv" }
  if (PythonDeVerdade) { Ok ((& python3 --version) -join "") } else { Aviso "python3 não encontrado (fichário de clientes)"; $script:Faltam += "python" }
}

function Baixar($url, $destino) { try { Invoke-WebRequest -Uri $url -OutFile $destino -UseBasicParsing -ErrorAction Stop; return $true } catch { return $false } }
function ShaOk($arquivo, $esperado) { if (-not $esperado) { return $false }; return ((Get-FileHash $arquivo -Algorithm SHA256).Hash.ToLower() -eq $esperado.ToLower()) }
function Extrair($arquivo, $destino) { New-Item -ItemType Directory -Force -Path $destino | Out-Null; & tar -xf $arquivo -C $destino; return ($LASTEXITCODE -eq 0) }
# no Windows o atalho é um .cmd (para o Windows) e um arquivo sem extensão (para o Git Bash, que é onde o Claude roda)
function Atalho($nome, $linhaCmd, $linhaSh) {
  if ($Windows) {
    [IO.File]::WriteAllText((Junta $Local "$nome.cmd"), "@echo off`r`n$linhaCmd %*`r`n", [Text.Encoding]::ASCII)
    Escrever (Junta $Local $nome) ("#!/bin/sh`nexec $linhaSh " + '"$@"' + "`n")
  }
}

function InstalarUv {
  $url = "https://github.com/astral-sh/uv/releases/latest/download/uv-$AlvoUv.$ExtUv"
  $arq = Junta $Tmp "uv.$ExtUv"; $sha = Junta $Tmp "uv.sha256"
  if (-not (Baixar $url $arq) -or -not (Baixar "$url.sha256" $sha)) { return $false }
  if (-not (ShaOk $arq (((Get-Content $sha -Raw).Trim() -split "\s+")[0]))) { return $false }
  $d = Junta $Tmp "uv"; if (-not (Extrair $arq $d)) { return $false }
  $uv = Get-ChildItem $d -Recurse -File | Where-Object { $_.Name -eq "uv$Exe" } | Select-Object -First 1
  if (-not $uv) { return $false }
  Copy-Item $uv.FullName (Junta $Local "uv$Exe") -Force
  $uvx = Junta $uv.DirectoryName "uvx$Exe"; if (Test-Path $uvx) { Copy-Item $uvx (Junta $Local "uvx$Exe") -Force }
  return (Test-Path (Junta $Local "uv$Exe"))
}
function InstalarNode {
  $base = "https://nodejs.org/dist/latest-v22.x"; $somas = Junta $Tmp "node-somas.txt"
  if (-not (Baixar "$base/SHASUMS256.txt" $somas)) { return $false }
  $fim = [regex]::Escape("-$SoNode.$ExtNode") + '$'
  $linha = Get-Content $somas | Where-Object { $_ -match $fim } | Select-Object -First 1
  if (-not $linha) { return $false }
  $partes = $linha.Trim() -split "\s+"; $nome = $partes[1]; $arq = Junta $Tmp $nome
  if (-not (Baixar "$base/$nome" $arq) -or -not (ShaOk $arq $partes[0])) { return $false }
  $pasta = $nome.Substring(0, $nome.Length - $ExtNode.Length - 1)
  $final = Junta $Apoio "node"
  if (Test-Path $final) { Remove-Item $final -Recurse -Force }
  if (Test-Path (Junta $Apoio $pasta)) { Remove-Item (Junta $Apoio $pasta) -Recurse -Force }
  if (-not (Extrair $arq $Apoio)) { return $false }
  Rename-Item (Junta $Apoio $pasta) "node"
  if ($Windows) {
    $n = ($final -replace "\\", "/")
    Atalho "node" "`"$final\node.exe`"" "`"$n/node.exe`""
    Atalho "npm" "`"$final\npm.cmd`"" "`"$n/node.exe`" `"$n/node_modules/npm/bin/npm-cli.js`""
    Atalho "npx" "`"$final\npx.cmd`"" "`"$n/node.exe`" `"$n/node_modules/npm/bin/npx-cli.js`""
    NoCaminho $final
    return (Test-Path (Junta $final "node.exe"))
  }
  foreach ($b in "node", "npm", "npx") { & ln -sf (Junta $final "bin" $b) (Junta $Local $b) }
  return (Test-Path (Junta $final "bin" "node"))
}
function InstalarFfmpeg {     # precisa do Node: os pacotes ffmpeg-static e ffprobe-static trazem os programas prontos
  if (-not (Tem npm)) { return $false }
  $d = Junta $Apoio "ffmpeg"; New-Item -ItemType Directory -Force -Path $d | Out-Null
  if (-not (Test-Path (Junta $d "package.json"))) { Escrever (Junta $d "package.json") '{"name":"ffmpeg-local","private":true}' }
  Push-Location $d
  & npm install --no-audit --no-fund ffmpeg-static ffprobe-static *> $Log
  $f = (& node -p "require('ffmpeg-static')"); $p = (& node -p "require('ffprobe-static').path")
  Pop-Location
  if (-not $f -or -not $p -or -not (Test-Path $f) -or -not (Test-Path $p)) { return $false }
  # o ffprobe-static traz o programa de todos os sistemas: fica só o deste computador
  $arqDir = Split-Path $p -Parent; $soDir = Split-Path $arqDir -Parent; $raiz = Split-Path $soDir -Parent
  if ((Split-Path $raiz -Leaf) -eq "bin") {
    Get-ChildItem $raiz -Directory | Where-Object { $_.FullName -ne $soDir } | Remove-Item -Recurse -Force
    Get-ChildItem $soDir -Directory | Where-Object { $_.FullName -ne $arqDir } | Remove-Item -Recurse -Force
  }
  if ($Windows) { Copy-Item $f (Junta $Local "ffmpeg.exe") -Force; Copy-Item $p (Junta $Local "ffprobe.exe") -Force }
  else { & ln -sf $f (Junta $Local "ffmpeg"); & ln -sf $p (Junta $Local "ffprobe") }
  return ((Test-Path (Junta $Local "ffmpeg$Exe")) -and (Test-Path (Junta $Local "ffprobe$Exe")))
}
function InstalarPython {     # precisa do uv
  if (-not (Tem uv)) { return $false }
  & uv python install 3.12 --default *> $Log
  if (Test-Path (Junta $Local "python3$Exe")) { return $true }
  # versões do uv que não criam o python3 sozinhas: o atalho é feito aqui
  & uv python install 3.12 *> $Log
  $py = (& uv python find 3.12); if (-not $py -or -not (Test-Path $py)) { return $false }
  if ($Windows) { $u = ($py -replace "\\", "/"); Atalho "python3" "`"$py`"" "`"$u`""; return (Test-Path (Junta $Local "python3.cmd")) }
  & ln -sf $py (Junta $Local "python3"); return (Test-Path (Junta $Local "python3"))
}
function InstalarSemSenha {
  New-Item -ItemType Directory -Force -Path $Local | Out-Null; New-Item -ItemType Directory -Force -Path $Apoio | Out-Null
  NoCaminho $Local
  # a ordem importa: o ffmpeg vem pelo Node e o Python vem pelo uv
  foreach ($prog in "uv", "node", "ffmpeg", "python") {
    if ($script:Faltam -notcontains $prog) { continue }
    Write-Host "  baixando $prog..."
    $feito = $false
    try { $feito = switch ($prog) { "uv" { InstalarUv } "node" { InstalarNode } "ffmpeg" { InstalarFfmpeg } "python" { InstalarPython } } } catch { $feito = $false }
    if ($feito) { Ok "$prog instalado em $Local" } else { Aviso "não consegui instalar $prog sozinho" }
  }
}
# quem instalou algo na pasta pessoal precisa dela no caminho das próximas janelas e do Claude
function GarantirCaminho {
  if (-not $Windows) { return }
  $atual = [Environment]::GetEnvironmentVariable("Path", "User"); if (-not $atual) { $atual = "" }
  $novos = @($Local, (Junta $Apoio "node")) | Where-Object { (Test-Path $_) -and (($atual -split ";") -notcontains $_) }
  if ($novos) { [Environment]::SetEnvironmentVariable("Path", (($novos -join ";") + ";" + $atual).TrimEnd(";"), "User"); $script:Reabrir = $true }
  # no outro disco, os caches dos programas também passam a morar lá (para o Claude usar depois da instalação)
  foreach ($k in $Ambiente.Keys) {
    if ([Environment]::GetEnvironmentVariable($k, "User") -ne $Ambiente[$k]) { [Environment]::SetEnvironmentVariable($k, $Ambiente[$k], "User"); $script:Reabrir = $true }
  }
}

# espaço em disco: com o disco cheio os downloads saem corrompidos e o erro aparece longe da causa
if (-not $Conferir -and -not $env:FM_IGNORAR_ESPACO) {
  $livreCasa = LivreGB $Casa; $livrePasta = LivreGB $Pasta
  if ($OutroDisco) {
    if ($MudouDeDisco) { Aviso "o disco $RaizCasa está com só $livreCasa GB livres: a instalação inteira vai para $Pasta (programas, caches e projeto)" }
    else { Ok "instalação inteira em $Pasta (programas e caches em _sistema)" }
    if ($livrePasta -lt 6) { Write-Host "Há só $livrePasta GB livres no disco de $Pasta. A instalação usa uns 5 GB. Libere espaço ou escolha outro disco com -Pasta." -ForegroundColor Red; exit 1 }
    if ($livreCasa -lt 1) { Aviso "o disco $RaizCasa tem só $livreCasa GB livres. A Fábrica de Motion não vai usar esse disco, mas o próprio sistema precisa de espaço livre para funcionar bem." }
  } else {
    if ($livreCasa -lt 1) { Write-Host "Há só $livreCasa GB livres no disco $RaizCasa e não achei outro disco com espaço. A instalação usa uns 5 GB. Libere espaço, ou escolha outro disco com -Pasta, e rode de novo." -ForegroundColor Red; exit 1 }
    elseif ($livreCasa -lt 5) { Aviso "há só $livreCasa GB livres no disco $RaizCasa; a instalação usa uns 5 GB e pode faltar espaço" }
  }
}

ConferirProgramas
if ($Faltam.Count -gt 0) {
  if ($Conferir) { Falha ("faltam programas: " + ($Faltam -join " ")) }
  else {
    Write-Host ""; Write-Host ("  Faltam: " + ($Faltam -join " "))
    if (Perguntar "  Baixar das fontes oficiais para a sua pasta pessoal ($Local), sem senha de administrador?") {
      InstalarSemSenha; GarantirCaminho
      Write-Host ""; ConferirProgramas
    }
    if ($Faltam.Count -gt 0) {
      Write-Host ""; Write-Host ("Ainda faltam: " + ($Faltam -join " ") + ". Instale e rode este instalador de novo.") -ForegroundColor Red
      Write-Host "Node: https://nodejs.org   ffmpeg: https://ffmpeg.org   uv: https://docs.astral.sh/uv   Python: https://python.org"
      exit 1
    }
  }
}
if ($OutroDisco -and -not $Conferir) { GarantirCaminho }
# Claude Code de terminal: é ele que responde dentro do painel. Vai para a mesma pasta dos outros programas (sem senha de administrador).
function AcharClaude {
  $pacote = @("node_modules", "@anthropic-ai", "claude-code", "bin", "claude.exe")
  foreach ($c in @((Junta (Junta $Apoio "claude") @pacote), (Junta (Junta $Apoio "claude" "lib") @pacote), (Junta $Casa ".local" "bin" "claude$Exe"))) { if (Test-Path $c) { return $c } }
  $c = Get-Command claude -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  return $null
}
$Claude = AcharClaude; $FaltaLogin = $false
if (-not $Claude -and -not $Conferir -and (Tem npm)) {
  Write-Host "  instalando o Claude Code de terminal (é ele que responde dentro do painel)..."
  $d = Junta $Apoio "claude"; New-Item -ItemType Directory -Force -Path $d | Out-Null
  & npm install -g --prefix $d --no-audit --no-fund "@anthropic-ai/claude-code" *> $Log
  $Claude = AcharClaude
  if (-not $Claude) { Aviso "não consegui instalar o Claude Code de terminal - veja $Log" }
}
if ($Claude) {
  & $Claude auth status *> $null
  if ($LASTEXITCODE -eq 0) { Ok "Claude Code de terminal instalado e conectado: a conversa ao vivo no painel vai funcionar" }
  else { $FaltaLogin = $true; Aviso "Claude Code de terminal instalado, mas ainda sem a sua conta: no painel, abra um cliente e clique em Conectar minha conta" }
} else { Aviso "Claude Code de terminal não encontrado: o painel funciona no modo recado (o que você escreve fica guardado e o Claude lê quando você pedir)" }

# ───────── 2. instalação ─────────
function CopiarSemSobrescrever($origem, $destino, $pular) {
  $base = (Resolve-Path $origem).Path.TrimEnd("\", "/")
  foreach ($f in Get-ChildItem $base -Recurse -File -Force) {
    $rel = $f.FullName.Substring($base.Length + 1)
    $partes = $rel -split '[\\/]'
    if ($pular | Where-Object { $partes -contains $_ }) { continue }
    $alvo = Junta $destino $rel
    if (Test-Path $alvo) { continue }
    New-Item -ItemType Directory -Force -Path (Split-Path $alvo -Parent) | Out-Null
    Copy-Item $f.FullName $alvo
  }
}
if (-not $Conferir) {
  Passo "2. Instalação"
  if ($ManteveAnterior) { Aviso "já existe uma instalação; mantendo a pasta de trabalho $Pasta" }
  foreach ($d in (Junta $Pasta "entregas"), (Junta $Pasta "clientes"), (Junta $Pasta "painel" "fichas"), (Junta $Pasta "template"), $Skills) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
  if (-not (Test-Path $Pasta)) { Falha "não consegui criar $Pasta"; exit 1 }

  $copia = ""
  if (Test-Path $Skill) {
    $copia = Junta $Skills ("fabrica-de-motion.antes-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    Copy-Item $Skill $copia -Recurse; Aviso "skill anterior guardada em $copia"
  }
  New-Item -ItemType Directory -Force -Path $Skill | Out-Null
  Copy-Item (Junta $Aqui "skill" "*") $Skill -Recurse -Force
  if (Test-Path (Junta $Skill "SKILL.md")) { Ok "skill em $Skill" } else { Falha "não consegui copiar a skill para $Skill" }
  $p = ($Pasta -replace "\\", "/")
  # "temp" só existe quando tudo foi para outro disco: é onde os renders guardam os arquivos temporários
  $extra = if ($OutroDisco) { ",`n  `"temp`": `"$p/_sistema/tmp`"" } else { "" }
  # onde está o Python de verdade (o painel usa no botão Novo cliente). Se python3 for o atalho .cmd, o caminho está dentro dele.
  $pyExe = (Get-Command python3 -ErrorAction SilentlyContinue).Source
  if ($pyExe -and $pyExe -match "\.cmd$") { $mm = [regex]::Match((Get-Content $pyExe -Raw), '"([^"]+\.exe)"'); $pyExe = if ($mm.Success) { $mm.Groups[1].Value } else { "" } }
  if ($pyExe -and (Test-Path $pyExe)) { $extra += ",`n  `"python`": `"" + ($pyExe -replace "\\", "/") + "`"" }
  Escrever (Junta $Skill "config.json") "{`n  `"painel`": `"$p/painel`",`n  `"entregas`": `"$p/entregas`",`n  `"projetos`": `"$p/clientes`",`n  `"template`": `"$p/template`"$extra`n}`n"
  # reinstalação ou atualização: os ajustes que a pessoa fez no config antigo continuam valendo
  if ($copia -and (Test-Path (Junta $copia "config.json"))) {
    if ($PastaDada) { & python3 (Junta $Skill "ferramentas" "juntar_config.py") (Junta $Skill "config.json") (Junta $copia "config.json") *> $null }
    else { & python3 (Junta $Skill "ferramentas" "juntar_config.py") (Junta $Skill "config.json") (Junta $copia "config.json") --manter-caminhos *> $null }
  }
  # das cópias antigas da skill ficam só as duas mais recentes
  Get-ChildItem $Skills -Directory -Filter "fabrica-de-motion.antes-*" -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -Skip 2 | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

  # projeto de vídeo e painel: só entram os arquivos que ainda não existem
  CopiarSemSobrescrever (Junta $Aqui "template") (Junta $Pasta "template") @("node_modules", "out")
  CopiarSemSobrescrever (Junta $Aqui "painel") (Junta $Pasta "painel") @()
  Ok "projeto de vídeo e painel em $Pasta"
  foreach ($d in "out", "audio", "public") { New-Item -ItemType Directory -Force -Path (Junta $Pasta "template" $d) | Out-Null }
  if (-not (Test-Path (Junta $Pasta "painel" "clientes.json"))) { Escrever (Junta $Pasta "painel" "clientes.json") "[]`n" }
  # o programa do painel é sempre atualizado; os dados (clientes, conversas, anexos, ajustes) nunca são tocados
  foreach ($f in "servidor.mjs", "motor.mjs", "regras.mjs", "aprovador.mjs", "index.html", "isolado.json", "painel.mjs", "painel.sh", "logo-fabrica.png") {
    $o = Junta $Aqui "painel" $f; if (Test-Path $o) { Copy-Item $o (Junta $Pasta "painel" $f) -Force }
  }
  # atalho de dois cliques: liga o painel em segundo plano e abre a página
  $nodeExe = (Get-Command node -ErrorAction SilentlyContinue).Source
  if ($Windows) {
    if ($nodeExe -like "*.cmd") { $nodeExe = Junta $Apoio "node" "node.exe" }
    $bat = Junta $Pasta "Abrir Painel.bat"
    [IO.File]::WriteAllText($bat, "@echo off`r`nrem Dois cliques: liga o painel da Fabrica de Motion (se ainda nao estiver no ar) e abre a pagina.`r`n`"$nodeExe`" `"%~dp0painel\painel.mjs`" abrir`r`nif errorlevel 1 pause`r`n", [Text.Encoding]::ASCII)
    Ok "atalho criado: $bat"
    # tira a marca de 'baixado da internet' do que foi instalado
    Get-ChildItem $Skill, (Junta $Pasta "painel") -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
  }

  # referências que vêm com a skill (vídeos de exemplo autorizados): entram na aba Referências do painel
  if (Test-Path (Junta $Aqui "referencias" "referencias.json")) {
    $r = (& python3 (Junta $Skill "ferramentas" "referencias.py") $Aqui $Pasta 2> $Log)
    if ($LASTEXITCODE -eq 0) { Ok "$r" } else { Aviso "não consegui instalar as referências - veja $Log" }
  }
  # modelos que deixaram de vir com a skill: saem das instalações antigas (roda também na atualização, que vem sem vídeos)
  if (Test-Path (Junta $Skill "ferramentas" "retirar-modelos.py")) {
    $r = (& python3 (Junta $Skill "ferramentas" "retirar-modelos.py") $Pasta 2> $Log)
    if ($LASTEXITCODE -eq 0) { Ok "$r" } else { Aviso "não consegui retirar os modelos antigos - veja $Log" }
  }

  Write-Host "  instalando as dependências do projeto de vídeo (alguns minutos na primeira vez)..."
  Push-Location (Junta $Pasta "template"); & npm install --no-audit --no-fund *> $Log; $cod = $LASTEXITCODE; Pop-Location
  if ($cod -eq 0) { Ok "dependências instaladas" } else { Falha "npm install - veja $Log" }
} else {
  Passo "2. Instalação (só conferindo)"
  # (a pasta de trabalho já veio da instalação existente, lá em cima)
}

# ───────── 3. conferência ─────────
# roda um comando com limite de tempo; passou do limite, encerra o comando e tudo o que ele abriu. Devolve o código de saída ou "tempo".
function RodarComLimite($comando, $segundos, $log) {
  if ($Windows) { $p = Start-Process -FilePath "cmd.exe" -ArgumentList "/c", "$comando > `"$log`" 2>&1" -NoNewWindow -PassThru }
  else { $p = Start-Process -FilePath "/bin/sh" -ArgumentList "-c", "`"$comando > '$log' 2>&1`"" -PassThru }
  $null = $p.Handle                                          # sem isto o código de saída vem vazio
  if (-not $p.WaitForExit($segundos * 1000)) {
    if ($Windows) { & taskkill /PID $p.Id /T /F *> $null } else { & pkill -P $p.Id *> $null; Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
    return "tempo"
  }
  return $p.ExitCode
}
$RenderTravou = $false
Passo "3. Conferência"
if (Test-Path (Junta $Skill "SKILL.md")) { Ok "skill instalada ($Skill)" } else { Falha "skill não encontrada em $Skill" }
if (Test-Path (Junta $Skill "config.json")) { Ok "config.json aponta para $Pasta" } else { Falha "config.json não encontrado" }
if (Test-Path (Junta $Pasta "template" "node_modules" "remotion")) { Ok "projeto de vídeo com dependências" } else { Falha ("projeto de vídeo sem dependências em " + (Junta $Pasta "template")) }
& python3 (Junta $Skill "cliente.py") lista *> $Log
if ($LASTEXITCODE -eq 0) { Ok "fichário de clientes responde" } else { Falha "fichário (cliente.py lista) - veja $Log" }
if (Test-Path (Junta $Pasta "painel" "painel.mjs")) { Ok "painel pronto (dois cliques em Abrir Painel)" } else { Falha ("painel não encontrado em " + (Junta $Pasta "painel")) }

if (-not $SemTeste -and $Erros -eq 0) {
  Passo "4. Vídeo de teste (6 segundos, com som)"
  $T = Junta $Pasta "template"; $Final = Junta $Pasta "entregas" "Teste-da-instalacao.mp4"; $Mix = Junta $T "out" "Teste-da-instalacao.mp4"
  Write-Host "  renderizando... (na primeira vez o Remotion baixa um navegador próprio, cerca de 90 MB)"
  Push-Location $T
  # sobra de uma instalação anterior não pode passar por vídeo novo
  Remove-Item (Junta $T "out" "teste.mp4"), $Mix -Force -ErrorAction SilentlyContinue
  $LogRender = Junta $Tmp "render.txt"
  $Limite = if ($env:FM_LIMITE_RENDER) { [int]$env:FM_LIMITE_RENDER } else { 480 }
  $Render = "npx --no-install remotion render Demo out/teste.mp4 --color-space=bt709 --log verbose"
  function SaiuVideo($codigo) { return (($codigo -eq 0) -and (Test-Path (Junta $T "out" "teste.mp4"))) }
  $r = RodarComLimite $Render $Limite $LogRender
  if (-not (SaiuVideo $r)) {
    # causa mais comum: o navegador do Remotion baixado pela metade (instalação interrompida ou disco cheio). Baixa de novo.
    Aviso "o vídeo de teste não saiu na primeira tentativa; baixando de novo o navegador do Remotion e tentando outra vez"
    Copy-Item $LogRender "$LogRender.primeira" -Force -ErrorAction SilentlyContinue
    Remove-Item (Junta $T "node_modules" ".remotion") -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item (Junta $T "out" "teste.mp4") -Force -ErrorAction SilentlyContinue
    $r = RodarComLimite $Render $Limite $LogRender
  }
  if (-not (SaiuVideo $r) -and $Windows) {
    Aviso "ainda não saiu; última tentativa com o desenho por software (--gl=swangle)"
    Remove-Item (Junta $T "out" "teste.mp4") -Force -ErrorAction SilentlyContinue
    $r = RodarComLimite "$Render --gl=swangle" $Limite $LogRender
    if (SaiuVideo $r) { Aviso "neste computador o render só funcionou com --gl=swangle: diga isso ao Claude no primeiro vídeo (a placa de vídeo não aceitou o modo normal)" }
  }
  if (SaiuVideo $r) { Ok "vídeo renderizado" }
  elseif ($r -eq "tempo") { Falha "o render do vídeo de teste travou (parado depois de $Limite s em todas as tentativas). O registro detalhado está em $LogRender"; $RenderTravou = $true }
  else { Falha "render do vídeo de teste (código $r). O registro detalhado está em $LogRender" }
  & uv run --quiet --with numpy --with scipy python tools/make_audio_demo.py *> $Log
  if ((Test-Path (Junta $T "audio" "demo-music.wav")) -and (Test-Path (Junta $T "audio" "demo-sfx.wav"))) { Ok "trilha e efeitos gerados" } else { Falha "som (tools/make_audio_demo.py) - veja $Log" }
  if ((Test-Path "out/teste.mp4") -and (Test-Path "audio/demo-music.wav")) {
    & ffmpeg -v error -y -i out/teste.mp4 -i audio/demo-music.wav -i audio/demo-sfx.wav -filter_complex "[1:a]volume=-4dB[m];[2:a]volume=-6dB[s];[m][s]amix=inputs=2:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11,alimiter=limit=0.84:level=false[a]" -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 256k -shortest -movflags +faststart $Mix *> $Log
    if (($LASTEXITCODE -eq 0) -and (Test-Path $Mix)) {
      Ok "vídeo e som juntos"
      & python3 (Junta $Skill "ferramentas" "conferir.py") $Mix 2>&1 | ForEach-Object { Write-Host "         $_" }
      Copy-Item $Mix $Final -Force
    } else { Falha "mixagem com ffmpeg - veja $Log" }
  }
  Pop-Location
}

Write-Host ""
if ($Erros -eq 0) {
  Remove-Item $Tmp -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "Tudo certo." -ForegroundColor Green
  if (-not $SemTeste) { Write-Host ("Abra o vídeo de teste: " + (Junta $Pasta "entregas" "Teste-da-instalacao.mp4")) }
  Write-Host ""; Write-Host "Para começar:"
  if ($Reabrir) { Write-Host "  0. Feche e abra o Claude de novo (programas novos foram instalados em $Local)." }
  Write-Host "  1. Abra o Claude Code na pasta $Pasta"
  Write-Host "  2. Mande o material do primeiro cliente (logo, fotos, texto ou áudio) e diga o que ele pediu."
  Write-Host ("  3. Painel de clientes: dois cliques em `"" + (Junta $Pasta "Abrir Painel.bat") + "`" (ou diga ao Claude: abre o painel)")
  if ($FaltaLogin) {
    Write-Host ""; Write-Host "Para o Claude responder dentro do painel (uma vez só): quem faz é a pessoa, não o Claude." -ForegroundColor Yellow
    Write-Host "  No painel, abra um cliente e clique em Conectar minha conta. O navegador abre a página do Claude: clique em Autorizar."
    Write-Host ("  Se o botão não abrir a página: abra o PowerShell, cole a linha abaixo e aperte Enter:")
    Write-Host ("  & `"" + $Claude + "`" auth login")
  }
  exit 0
} else {
  Write-Host "$Erros item(ns) falharam. Corrija o que está marcado acima e rode de novo com -Conferir. O registro está em $Log" -ForegroundColor Red
  if ($RenderTravou) {
    Write-Host "A instalação em si está feita; o que não saiu foi o vídeo de teste. Causas comuns de render travado no Windows:"
    Write-Host "  - o antivírus ou o firewall segurando o navegador do Remotion (chrome-headless-shell) ou o servidor local dele;"
    Write-Host "  - um render anterior ainda aberto: feche os processos node e chrome-headless-shell no Gerenciador de Tarefas;"
    Write-Host "  - driver de vídeo: o instalador já tentou de novo com --gl=swangle;"
    Write-Host "  - pouco espaço em disco (o navegador sai corrompido): libere espaço e rode de novo com -Conferir."
  }
  exit 1
}
