@echo off
rem Dois cliques: instala a Fabrica de Motion neste computador.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
echo.
pause
