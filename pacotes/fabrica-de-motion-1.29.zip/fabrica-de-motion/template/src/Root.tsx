import React from "react";
import { Composition } from "remotion";
import { DEMO_FPS, DEMO_FRAMES, Demo } from "./Demo/Demo";

// Uma composição por vídeo. Cada cliente tem a sua pasta em src/<Cliente>/ e entra aqui com uma linha.
export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition id="Demo" component={Demo} durationInFrames={DEMO_FRAMES} fps={DEMO_FPS} width={1080} height={1920} />
    </>
  );
};
