import { loadFont } from "@remotion/google-fonts/Inter";
import React from "react";
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from "remotion";

// Vídeo de teste da instalação (6 s, vertical). Serve de modelo do padrão da casa: fundo liso, o texto entra
// desfocado e fica parado, o movimento contínuo fica nos objetos, um destaque de cor por cena e trocas de cena
// diferentes entre si. Apague esta pasta quando fizer o primeiro vídeo de cliente.

const { fontFamily: F } = loadFont("normal", { weights: ["500", "600", "700"], subsets: ["latin", "latin-ext"] });

export const DEMO_FPS = 30;
export const DEMO_FRAMES = 6 * DEMO_FPS;
const cl = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const OUT = Easing.bezier(0.16, 1, 0.3, 1);
const BACK = Easing.out(Easing.back(1.4));
const k = (t: number, a: number, d = 0.45) => interpolate(t, [a, a + d], [0, 1], { ...cl, easing: OUT });
const pop = (t: number, a: number, d = 0.45) => interpolate(t, [a, a + d], [0, 1], { ...cl, easing: BACK });

const INK = "#1D1D1F";
const PAPER = "#F5F5F7";
const ACCENT = "#6D5EF6";

const blurIn = (t: number, at: number): React.CSSProperties => {
  const e = k(t, at, 0.5);
  return { opacity: Math.min(1, e * 1.6), filter: `blur(${((1 - e) * 22).toFixed(1)}px)`, transform: `translateY(${((1 - e) * 34).toFixed(1)}px)` };
};
const Line: React.FC<{ t: number; at: number; color: string; size?: number; children: string }> = ({ t, at, color, size = 110, children }) => (
  <div style={{ fontFamily: F, fontWeight: 600, fontSize: size, lineHeight: 1.1, letterSpacing: "-0.035em", whiteSpace: "nowrap", color, ...blurIn(t, at) }}>{children}</div>
);

export const Demo: React.FC = () => {
  const t = useCurrentFrame() / DEMO_FPS;
  const sheet = interpolate(t, [2.6, 3.1], [0, 1], { ...cl, easing: OUT });
  const press = interpolate(t, [4.5, 4.6, 4.85], [0, 1, 0], cl);
  const done = t >= 4.62;
  return (
    <AbsoluteFill style={{ background: "#000000" }}>
      {/* cena 1 · preto */}
      <AbsoluteFill style={{ transform: `scale(${(1 - 0.06 * sheet).toFixed(4)})`, opacity: 1 - 0.5 * sheet, alignItems: "center", justifyContent: "center" }}>
        <div style={{ position: "absolute", top: 520 + Math.sin(t * 2.2) * 8, width: 300, height: 300, borderRadius: 72, background: ACCENT, transform: `scale(${pop(t, 0.1, 0.6).toFixed(3)}) rotate(${((1 - k(t, 0.1, 0.8)) * -40).toFixed(1)}deg)` }} />
        <div style={{ position: "absolute", top: 940, display: "flex", flexDirection: "column", alignItems: "center" }}>
          <Line t={t} at={0.5} color="#FFFFFF">Instalação</Line>
          <Line t={t} at={1.1} color={ACCENT}>funcionando.</Line>
        </div>
      </AbsoluteFill>
      {/* cena 2 · claro, sobe como folha */}
      {t >= 2.55 ? (
        <AbsoluteFill style={{ background: PAPER, transform: `translateY(${((1 - sheet) * 1920).toFixed(1)}px)`, borderRadius: `${((1 - sheet) * 90).toFixed(0)}px ${((1 - sheet) * 90).toFixed(0)}px 0 0`, overflow: "hidden" }}>
          <div style={{ position: "absolute", left: 0, right: 0, top: 480, display: "flex", flexDirection: "column", alignItems: "center" }}>
            <Line t={t} at={3.1} color={INK} size={96}>Agora é só mandar</Line>
            <Line t={t} at={3.6} color={ACCENT} size={96}>o primeiro cliente.</Line>
          </div>
          <div style={{ position: "absolute", left: 190, top: 1040, width: 700, height: 150, borderRadius: 75, background: done ? ACCENT : INK, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: F, fontWeight: 600, fontSize: 54, letterSpacing: "-0.03em", color: "#FFFFFF", opacity: k(t, 4.0, 0.25), transform: `scale(${((0.7 + 0.3 * pop(t, 4.0, 0.5)) * (1 - 0.07 * press) * (1 + 0.02 * Math.sin(t * 6))).toFixed(3)})` }}>
            {done ? "Pronto" : "Começar"}
          </div>
        </AbsoluteFill>
      ) : null}
    </AbsoluteFill>
  );
};
