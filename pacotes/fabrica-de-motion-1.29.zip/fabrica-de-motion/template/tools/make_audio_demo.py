"""Trilha + efeitos do vídeo de teste (6 s, 120 BPM, Fá maior). Modelo para os scripts de som de cada cliente.

Rodar: uv run --with numpy --with scipy python tools/make_audio_demo.py
"""
from som import *

DUR = 6.0
PF = [(29, [60, 65, 69]), (24, [60, 64, 67]), (26, [62, 65, 69]), (22, [62, 65, 70])]     # F – C – Dm – Bb
build("demo", DUR, 120, lambda x: PF, lambda x: 1 if x < 2.6 else 3, [2.6], [], 5.0)

# efeitos: um som diferente por entrada
sfx = np.zeros((int(DUR * SR), 2))
put(sfx, thump(60, 0.4, 12), 0.1, 0.5)                      # o quadrado entra
put(sfx, whoosh(0.3, 500, 1700), 0.35, 0.2)                 # primeira linha
put(sfx, ping(79, 0.6, 7), 1.1, 0.22)                       # destaque
put(sfx, whoosh(0.5, 300, 1500), 2.4, 0.26)                 # a folha sobe
put(sfx, pop(360, 720, 0.09), 4.0, 0.3)                     # botão aparece
put(sfx, tick(1250, 0.014), 4.52, 0.4)                      # clique
put(sfx, ping(76, 0.35, 11), 4.64, 0.26); put(sfx, ping(83, 0.8, 6), 4.77, 0.26)
save("demo-sfx.wav", reverb(sfx, 0.5, 0.06), 0.9)
print("ok", OUT)
