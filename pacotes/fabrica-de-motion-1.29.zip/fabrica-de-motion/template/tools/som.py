"""Biblioteca de som da Fábrica de Motion: trilha e efeitos sintetizados, livres de licença.

Cada vídeo tem o seu script em tools/make_audio_<cliente>.py, que importa daqui:

    from som import *
    build("cliente", DUR, 110, prog_of, level_of, hits, [], end)   # grava audio/cliente-music.wav
    sfx = np.zeros((int(DUR * SR), 2)); put(sfx, pop(300, 600), 1.2, 0.3); save("cliente-sfx.wav", sfx, 0.9)

Instrumentos da trilha: kick, clap, hat, bass, pluck, bell, pad, rim, sub, keys.
Efeitos: whoosh, thump, ping, glass, pop, tick, flick, glide. `put` coloca um som num tempo; `reverb` dá sala.
build(...): level_of(t) devolve 0 pausa · 1 só pad e pulso · 2 + bumbo leve e teclas · 3 batida cheia.

Rodar um script: uv run --with numpy --with scipy python tools/make_audio_<cliente>.py
"""
import pathlib, wave
import numpy as np
from scipy import signal

SR = 48000
OUT = pathlib.Path(__file__).resolve().parent.parent / "audio"     # troque com som.OUT = ... se precisar
rng = np.random.default_rng(1507)
t = lambda d: np.arange(int(d * SR)) / SR
midi = lambda n: 440.0 * 2 ** ((n - 69) / 12)
lp = lambda x, f: signal.sosfilt(signal.butter(2, f, btype="low", fs=SR, output="sos"), x)
hp = lambda x, f: signal.sosfilt(signal.butter(2, f, btype="high", fs=SR, output="sos"), x)
bp = lambda x, lo, hi: signal.sosfilt(signal.butter(2, [lo, min(hi, 22000)], btype="band", fs=SR, output="sos"), x)
noise = lambda d: rng.standard_normal(int(d * SR))


def put(buf, x, at, gain=1.0, pan=0.0):
    i = int(at * SR)
    if i < 0 or i >= buf.shape[0]:
        return
    x = x[: buf.shape[0] - i]
    buf[i : i + len(x), 0] += x * gain * (1 - max(0, pan))
    buf[i : i + len(x), 1] += x * gain * (1 + min(0, pan))


def save(name, buf, peak):
    buf = buf / max(1e-9, np.abs(buf).max()) * peak
    with wave.open(str(OUT / name), "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((buf * 32767).astype(np.int16).tobytes())


def reverb(buf, secs, wet):
    n = int(secs * SR)
    out = buf.copy()
    for ch in range(2):
        ir = rng.standard_normal(n) * np.exp(-np.arange(n) / SR * (6.2 / secs)); ir = lp(ir, 5200); ir[: int(0.012 * SR)] = 0
        out[:, ch] += signal.fftconvolve(buf[:, ch], ir / np.sqrt((ir ** 2).sum()), mode="full")[: buf.shape[0]] * wet
    return out


# ───────── trilha ─────────
def kick(g=1.0):
    x = t(0.26); return np.sin(2 * np.pi * np.cumsum(46 + 88 * np.exp(-x * 40)) / SR) * np.exp(-x * 15) * g
def clap():
    x = t(0.1); return bp(noise(0.1), 1400, 4800) * (np.exp(-x * 75) + 0.5 * np.exp(-((x - 0.015) / 0.005) ** 2))
def hat(d=0.03):
    return hp(noise(d), 8500) * np.exp(-t(d) * 140)
def bass(n, d, cut=300):
    x = t(d); f = midi(n); return lp(signal.sawtooth(2 * np.pi * f * x) * 0.5 + np.sin(2 * np.pi * f * x), cut) * np.exp(-x * 5) * np.minimum(1, x / 0.004)
def pluck(n, d=0.32, cut=2600):
    x = t(d); f = midi(n); return lp(signal.square(2 * np.pi * f * x) * 0.35 + signal.sawtooth(2 * np.pi * f * 1.004 * x) * 0.65, cut) * np.exp(-x * 12) * np.minimum(1, x / 0.003)
def bell(n, d=1.2):
    x = t(d); f = midi(n); return (np.sin(2 * np.pi * f * x) + 0.3 * np.sin(2 * np.pi * 3.01 * f * x) * np.exp(-x * 6)) * np.exp(-x * 3.2) * np.minimum(1, x / 0.004)
def pad(notes, d, cut=1200):
    x = t(d); y = np.zeros(len(x))
    for n in notes:
        for det in (-0.06, 0.06):
            y += signal.sawtooth(2 * np.pi * midi(n + det) * x + rng.uniform(0, 6.28))
    return lp(y, cut) * np.minimum(1, x / 0.4) * np.minimum(1, (d - x) / 0.5) / (2 * len(notes))



def rim():
    x = t(0.06); return (np.sin(2 * np.pi * 1700 * x) * 0.5 + bp(noise(0.06), 1200, 3800) * 0.6) * np.exp(-x * 70)
def sub(n, d):
    x = t(d); f = midi(n); return lp(np.sin(2 * np.pi * f * x) + 0.25 * np.sin(2 * np.pi * 2 * f * x), 220) * np.exp(-x * 2.2) * np.minimum(1, x / 0.012)
def keys(notes, d=1.6, cut=1700):
    x = t(d); y = sum(np.sin(2 * np.pi * midi(n) * x) + 0.3 * np.sin(2 * np.pi * 2 * midi(n) * x) * np.exp(-x * 6) for n in notes) / len(notes)
    return lp(y, cut) * np.exp(-x * 2.4) * np.minimum(1, x / 0.01)
def whoosh(d, f0, f1, top=2600):
    n = int(d * SR); x = rng.standard_normal(n + 2048); out = np.zeros(n)
    for i in range(0, n, 512):
        f = min(top, f0 * (f1 / f0) ** (i / n)); seg = bp(x[i : i + 2560], f * 0.75, f * 1.35)[2048:]
        out[i : i + 512] = seg[: len(out[i : i + 512])]
    return lp(out, top) * np.hanning(n) ** 1.5
def thump(f, d=0.6, k=7, drop=24):
    x = t(d); return np.sin(2 * np.pi * np.cumsum(f + drop * np.exp(-x * 16)) / SR) * np.exp(-x * k) * np.minimum(1, x / 0.01)
def ping(n, d=0.6, k=7):
    x = t(d); f = midi(n); return (np.sin(2 * np.pi * f * x) + 0.22 * np.sin(2 * np.pi * 2 * f * x) * np.exp(-x * 9)) * np.exp(-x * k) * np.minimum(1, x / 0.005)
def glass(notes, d=1.6, att=0.02, k=2.5):
    x = t(d); return sum(np.sin(2 * np.pi * midi(n) * x + j) for j, n in enumerate(notes)) / len(notes) * np.minimum(1, x / att) * np.exp(-x * k)
def pop(f0, f1, d=0.07):
    x = t(d); return np.sin(2 * np.pi * np.cumsum(np.linspace(f0, f1, len(x))) / SR) * np.hanning(len(x))
def tick(f, d=0.03):
    x = t(d); return np.sin(2 * np.pi * f * x) * np.hanning(len(x))
def flick(lo, hi, d=0.1):
    return bp(noise(d), lo, hi) * np.hanning(int(d * SR)) ** 2
def glide(f0, f1, d):
    x = t(d); return np.sin(2 * np.pi * np.cumsum(np.linspace(f0, f1, len(x))) / SR) * np.hanning(len(x))





def build(name, dur, bpm, prog_of, level_of, hits, sfx_events, end):
    """level_of(t) -> 0 pausa · 1 só pad e pulso · 2 + bumbo leve e teclas · 3 cheio."""
    n = int(dur * SR)
    music = np.zeros((n, 2)); beat = 60 / bpm; bar = 4 * beat
    at = 0.0; b = 0
    while at < end - 0.05:
        root, ch = prog_of(at)[b % 4]
        lv = level_of(at)
        if lv > 0:
            put(music, pad([root + 24] + ch, min(bar, end - at) + 0.4, 800 if lv == 1 else 1300), at, 0.34 if lv < 3 else 0.3)
        for q in range(4):
            w = at + q * beat
            if w >= end - 0.03:
                continue
            lv = level_of(w)
            if lv == 0:
                continue
            put(music, sub(root, beat * 0.95), w, 0.42 if q in (0, 2) else 0.22)
            put(music, hat(0.016), w + beat / 2, 0.05 if lv == 1 else 0.085, pan=0.25)
            if lv >= 2:
                if q in (0, 2):
                    put(music, kick(), w, 0.5 if lv == 2 else 0.72)
                if q in (0, 3):
                    put(music, keys([x + 12 for x in ch], 1.4), w + (beat / 2 if q == 3 else 0), 0.2, pan=(0.2, -0.2)[q % 2])
            if lv >= 3:
                if q == 2:
                    put(music, rim(), w, 0.26, pan=-0.15)
                put(music, hat(0.012), w + beat / 4, 0.04, pan=-0.25); put(music, hat(0.012), w + 3 * beat / 4, 0.04, pan=-0.25)
                if q == 1:
                    put(music, bell(ch[2] + 12, 0.9), w + beat / 2, 0.1, pan=0.3)
        at += bar; b += 1
    for h in hits:                                              # subida curta + acorde em cada virada
        x = t(0.7); put(music, hp(noise(0.7), 1600) * (x / 0.7) ** 2.4, h - 0.7, 0.16)
        root, ch = prog_of(h)[0]; put(music, keys([root + 24] + [c + 12 for c in ch], 2.2, 2400), h, 0.3)
    root, ch = prog_of(end)[0]
    put(music, pad([root, root + 12, root + 24] + ch, dur - end, 1500), end, 0.6); put(music, kick(), end, 0.6); put(music, keys([c + 12 for c in ch], 2.6, 2400), end, 0.36); put(music, bell(ch[0] + 24, 2.4), end + 0.3, 0.14)
    music = reverb(music, 1.1, 0.12)
    music *= signal.windows.tukey(n, 0.01)[:, None]
    buf = music / max(1e-9, np.abs(music).max()) * 0.85
    with wave.open(str(OUT / f"{name}-music.wav"), "wb") as wv:
        wv.setnchannels(2); wv.setsampwidth(2); wv.setframerate(SR); wv.writeframes((buf * 32767).astype(np.int16).tobytes())
    sfx = np.zeros((n, 2))
    for ev in sfx_events:
        kind, at = ev[0], ev[1]; i = int(at * 97) % 7
        if kind == "cut":
            d = 0.24 + 0.02 * (i % 4); put(sfx, whoosh(d, *((420 + 60 * i, 1900) if i % 2 else (1800, 380 + 50 * i))), at - d * 0.55, 0.22, pan=(0.3, -0.3)[i % 2])
        elif kind == "tag":
            put(sfx, thump(58 + i * 3, 0.2, 22, 10), at, 0.34); put(sfx, tick(1800 + 90 * i, 0.008), at, 0.14)
        elif kind == "offer":
            put(sfx, thump(46 + i, 0.5, 8), at, 0.6); put(sfx, flick(700, 2400, 0.12), at - 0.05, 0.16)
        elif kind == "value":
            put(sfx, ping(74 + (i % 4) * 2, 0.8, 5), at, 0.26); put(sfx, pop(420, 760, 0.07), at, 0.22)
        elif kind == "pop":
            put(sfx, pop(380 + 40 * i, 700 + 60 * i, 0.07), at, 0.26)
        elif kind == "big":
            put(sfx, thump(40, 0.9, 5.5), at, 0.8); put(sfx, glass((62, 69, 74), 1.5), at + 0.02, 0.16)
        elif kind == "type":
            for j in range(int(ev[2])):
                put(sfx, tick(1500 + 120 * (j % 4), 0.011), at + j * ev[3], 0.16)
        elif kind == "street":
            x = t(ev[2]); put(sfx, lp(noise(ev[2]), 900) * np.hanning(len(x)) ** 0.5, at, 0.3)
    sfx = reverb(sfx, 0.4, 0.05)
    buf = sfx / max(1e-9, np.abs(sfx).max()) * 0.9
    with wave.open(str(OUT / f"{name}-sfx.wav"), "wb") as wv:
        wv.setnchannels(2); wv.setsampwidth(2); wv.setframerate(SR); wv.writeframes((buf * 32767).astype(np.int16).tobytes())
