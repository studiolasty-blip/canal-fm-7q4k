// Liga e desliga o painel da Fábrica de Motion em segundo plano (Mac, Windows e Linux): não precisa de terminal aberto.
//
//   node painel.mjs ligar      sobe o painel (se já estiver no ar, só avisa)
//   node painel.mjs abrir      liga se precisar e abre a página no navegador
//   node painel.mjs estado     diz se está no ar e se há vídeo em produção
//   node painel.mjs religar    desliga e liga de novo (depois de atualizar ou trocar um ajuste)
//   node painel.mjs desligar   derruba o painel
//
// Porta padrão 4310; outra porta pela variável PORTA. Com vídeo em produção, desligar e religar avisam e param;
// para interromper mesmo assim, acrescente --mesmo-assim.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import net from "node:net";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const AQUI = path.dirname(fileURLToPath(import.meta.url));
const PORTA = Number(process.env.PORTA) || 4310;
const URL_PAINEL = `http://localhost:${PORTA}`;
const LOG = path.join(AQUI, "painel.log");
const WIN = process.platform === "win32";
const espera = (ms) => new Promise((r) => setTimeout(r, ms));

const pedir = async (rota) => {
  try { const r = await fetch(URL_PAINEL + rota, { signal: AbortSignal.timeout(2000) }); return r.ok ? await r.json() : null; } catch { return null; }
};
const noAr = async () => (await pedir("/api/motor")) !== null;
const emProducao = async () => (await pedir("/api/motor"))?.rodando ?? [];
const portaOcupada = () => new Promise((ok) => {
  const s = net.connect({ port: PORTA, host: "127.0.0.1" });
  s.once("connect", () => { s.destroy(); ok(true); }); s.once("error", () => ok(false)); s.setTimeout(1500, () => { s.destroy(); ok(false); });
});

async function ligar() {
  if (await noAr()) { console.log(`O painel já está ligado: ${URL_PAINEL}`); return true; }
  if (await portaOcupada()) { console.log(`A porta ${PORTA} está ocupada por outro programa. Tente outra, por exemplo: PORTA=4400`); return false; }
  try { if (fs.existsSync(LOG)) fs.writeFileSync(LOG, fs.readFileSync(LOG, "utf8").split("\n").slice(-300).join("\n")); } catch {}
  // os programas que o instalador baixou ficam na pasta pessoal; o painel precisa achá-los (ffmpeg, python, claude)
  // (quando a instalação foi inteira para outro disco, eles ficam em <pasta de trabalho>/_sistema/bin)
  const extra = [path.join(os.homedir(), ".local", "bin"), path.join(AQUI, "..", "_sistema", "bin"), path.join(AQUI, "..", "_sistema", "apoio", "node"), ...(WIN ? [] : ["/opt/homebrew/bin", "/usr/local/bin"])].filter((d) => fs.existsSync(d));
  const env = { ...process.env, PATH: [process.env.PATH ?? process.env.Path, ...extra].filter(Boolean).join(path.delimiter) };
  if (WIN) delete env.Path;
  const saida = fs.openSync(LOG, "a");
  const filho = spawn(process.execPath, ["servidor.mjs", String(PORTA)], { cwd: AQUI, env, detached: true, windowsHide: true, stdio: ["ignore", saida, saida] });
  filho.on("error", () => {});
  filho.unref();
  for (let i = 0; i < 40 && !(await noAr()); i++) await espera(300);
  if (await noAr()) { console.log(`Painel ligado: ${URL_PAINEL}  (pode fechar esta janela, ele continua no ar)`); return true; }
  let fim = ""; try { fim = fs.readFileSync(LOG, "utf8").trim().split("\n").slice(-6).join("\n"); } catch {}
  console.log(`O painel não subiu. Fim do registro (${LOG}):\n${fim}`);
  return false;
}

async function desligar(forcar) {
  if (!(await noAr())) { console.log("O painel já está desligado."); return true; }
  const rodando = await emProducao();
  if (rodando.length && !forcar) {
    console.log(`Há vídeo em produção no painel (${rodando.join(", ")}). Desligar agora interrompe o trabalho.`);
    console.log("Espere terminar, ou repita com --mesmo-assim."); return false;
  }
  const pid = (await pedir("/api/ping"))?.pid;
  if (!pid) { console.log("Este painel é de uma versão antiga e não diz qual é o processo dele. Feche a janela de terminal onde ele está rodando e ligue de novo."); return false; }
  try { process.kill(pid); } catch {}
  for (let i = 0; i < 25 && (await noAr()); i++) await espera(200);
  if (await noAr()) { try { process.kill(pid, "SIGKILL"); } catch {} await espera(500); }
  const caiu = !(await noAr());
  console.log(caiu ? "Painel desligado." : "Não consegui desligar o painel.");
  return caiu;
}

async function estado() {
  if (!(await noAr())) { console.log("Painel desligado. Para ligar: dois cliques em Abrir Painel (ou o comando ligar)."); return false; }
  const rodando = await emProducao();
  console.log(`Painel no ar: ${URL_PAINEL}`);
  console.log(rodando.length ? `Em produção agora: ${rodando.join(", ")}` : "Nenhum vídeo em produção.");
  return true;
}

async function abrir() {
  if (!(await ligar())) return false;
  const [cmd, args] = WIN ? ["cmd", ["/c", "start", "", URL_PAINEL]] : process.platform === "darwin" ? ["open", [URL_PAINEL]] : ["xdg-open", [URL_PAINEL]];
  try { const p = spawn(cmd, args, { detached: true, stdio: "ignore", windowsHide: true }); p.on("error", () => console.log(`Abra no navegador: ${URL_PAINEL}`)); p.unref(); }
  catch { console.log(`Abra no navegador: ${URL_PAINEL}`); }
  return true;
}

const [acao = "abrir", opcao] = process.argv.slice(2);
const forcar = opcao === "--mesmo-assim";
const feito = acao === "ligar" ? await ligar() : acao === "abrir" ? await abrir() : acao === "estado" ? await estado()
  : acao === "desligar" ? await desligar(forcar) : acao === "religar" ? (await desligar(forcar)) && (await ligar())
  : (console.log("Uso: node painel.mjs ligar | abrir | estado | religar | desligar"), false);
process.exit(feito ? 0 : 1);
