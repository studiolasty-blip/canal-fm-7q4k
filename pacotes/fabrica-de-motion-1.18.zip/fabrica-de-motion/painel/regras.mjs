// Regras de permissão do motor: o que roda sem pergunta, o que vira cartão no painel e o que é recusado mesmo com autonomia.
// Não guarda estado nem toca em disco: recebe o computador (sistema e pastas) e devolve as funções. É assim que as regras
// do Windows podem ser testadas em qualquer máquina.
//
// No Mac os comandos rodam na área isolada do Claude Code e estas regras valem para o que sai dela. No Windows a área
// isolada não existe: todo comando passa por aqui, e só leitura e o render seguem sem pergunta.
import path from "node:path";

// programas que nunca ganham "permitir sempre": cada uso é perguntado
const ARRISCADOS = new Set(["rm", "sudo", "curl", "wget", "ssh", "scp", "rsync", "git", "osascript", "open", "kill", "killall", "pkill", "chmod", "chown", "dd", "launchctl", "defaults", "security", "brew", "npm", "pip", "pip3", "mv", "nc", "sh", "bash", "zsh", "eval", "xargs", "find"]);
// os equivalentes do Windows (PowerShell e Prompt), em minúsculas e sem .exe
const ARRISCADOS_WIN = new Set(["del", "erase", "rd", "rmdir", "remove-item", "ri", "move", "move-item", "mi", "ren", "rename-item", "rni", "clear-content", "clc",
  "invoke-webrequest", "iwr", "invoke-restmethod", "irm", "start-bitstransfer", "bitsadmin", "certutil", "start-process", "saps", "start", "explorer",
  "invoke-expression", "iex", "invoke-command", "icm", "invoke-item", "ii", "powershell", "pwsh", "cmd", "wsl", "cscript", "wscript", "mshta", "rundll32", "regsvr32", "msiexec",
  "reg", "regedit", "set-itemproperty", "sp", "new-itemproperty", "remove-itemproperty", "set-executionpolicy", "setx", "new-service", "sc", "schtasks", "register-scheduledtask",
  "taskkill", "stop-process", "spps", "net", "netsh", "runas", "format", "diskpart", "takeown", "icacls", "attrib", "wmic", "robocopy", "winget", "choco", "scoop", "cmdkey", "vaultcmd"]);
const SO_LEITURA = new Set(["tail", "head", "grep", "ls", "cat", "ffprobe", "echo", "wc", "cut", "sort", "tr", "true"]);
const SO_LEITURA_WIN = new Set(["dir", "type", "findstr", "where", "pwd", "get-childitem", "gci", "get-content", "gc", "get-item", "gi", "get-location", "gl", "test-path", "resolve-path", "rvpa",
  "split-path", "join-path", "select-string", "sls", "select-object", "select", "sort-object", "measure-object", "measure", "get-filehash", "write-output", "write-host", "out-string", "out-null",
  "format-table", "ft", "format-list", "fl"]);
const APAGAM_WIN = new Set(["rm", "del", "erase", "rd", "rmdir", "remove-item", "ri"]);
const TERMINAIS = new Set(["sh", "bash", "zsh", "cmd", "powershell", "pwsh", "wsl"]);
const MUDAM_PASTA = new Set(["cd", "chdir", "pushd", "set-location", "sl"]);
const APAGA_NO_TEXTO = /(^|[\s;&|("'])(rm|del|erase|rd|rmdir|remove-item|ri)(\.exe)?(\s|$)/i;
const SEGREDO = /(^|\/)(\.ssh|\.aws|\.gnupg|\.netrc|\.env[^/]*|Keychains|\.credentials\.json|id_rsa[^/]*|\.config\/gh|\.config\/fabrica-de-motion)(\/|$)/;
const SEGREDO_WIN = /(^|\/)(\.ssh|\.aws|\.gnupg|\.netrc|\.env[^/]*|\.credentials\.json|id_rsa[^/]*|\.config\/gh|\.config\/fabrica-de-motion|AppData\/Roaming\/(gh|GitHub[ /]CLI)|Microsoft\/(Credentials|Protect|Vault))(\/|$)/i;

// separa um trecho de comando em palavras respeitando aspas e barra invertida (caminhos com espaço ficam inteiros)
function palavras(trecho) {
  const out = []; let atual = "", aspas = "", tem = false;
  for (let i = 0; i < trecho.length; i++) {
    const ch = trecho[i];
    if (aspas) { if (ch === aspas) aspas = ""; else if (ch === "\\" && aspas === '"' && i + 1 < trecho.length) atual += trecho[++i]; else atual += ch; }
    else if (ch === '"' || ch === "'") { aspas = ch; tem = true; }
    else if (ch === "\\" && i + 1 < trecho.length) { atual += trecho[++i]; tem = true; }
    else if (/\s/.test(ch)) { if (atual || tem) out.push(atual); atual = ""; tem = false; }
    else atual += ch;
  }
  if (atual || tem) out.push(atual);
  return out;
}
// Windows: separa o comando em trechos (um por programa) e cada trecho em palavras, sem cortar dentro de aspas.
// ps = sintaxe do PowerShell: a barra invertida é só separador de pasta, e "&" na frente do programa é o operador de chamada.
function partir(cmd, ps) {
  const trechos = []; let pal = [], atual = "", aspas = "", tem = false;
  const fechaPalavra = () => { if (atual || tem) pal.push(atual); atual = ""; tem = false; };
  const fechaTrecho = () => { fechaPalavra(); if (pal.length) trechos.push(pal); pal = []; };
  for (let i = 0; i < cmd.length; i++) {
    const ch = cmd[i], prox = cmd[i + 1];
    if (aspas) {
      if (ch === aspas) { if (ps && prox === aspas) { atual += ch; i++; } else aspas = ""; }
      else if (!ps && aspas === '"' && ch === "\\" && prox !== undefined && '"\\$`\n'.includes(prox)) atual += cmd[++i];
      else atual += ch;
    }
    else if (ch === '"' || ch === "'") { aspas = ch; tem = true; }
    else if (!ps && ch === "\\" && prox !== undefined) { atual += cmd[++i]; tem = true; }
    else if (ch === "\n" || ch === ";") fechaTrecho();
    else if (ch === "|") { if (prox === "|") i++; fechaTrecho(); }
    else if (ch === "&") {
      if (prox === "&") { i++; fechaTrecho(); }
      else if (/^\d*>$/.test(atual)) atual += ch;            // 2>&1
      else if (ps) fechaPalavra();
      else fechaTrecho();
    }
    else if (/\s/.test(ch)) fechaPalavra();
    else atual += ch;
  }
  fechaTrecho();
  return trechos;
}
// Windows: o comando grava a saída num arquivo? (2>&1 e descartar a saída não contam)
const redireciona = (cmd) => /(^|[^0-9>&])\d?>>?\s*(?!&[12]\b)(?!(\/dev\/null|\$null|nul)\b)\S/i.test(cmd.replace(/"[^"]*"|'[^']*'/g, '""'));

export function criarRegras({ win = false, casa, pastas = [], temp = [], leitura = [], foraLivre }) {
  const P = win ? path.win32 : path;
  const FORA_LIVRE = new Set(foraLivre ?? ["npx remotion", "avconvert"]);
  const caixa = (s) => (win ? String(s).toLowerCase() : String(s));          // no Windows, maiúscula e minúscula são o mesmo arquivo
  const curto = (p) => String(p).replace(casa, "~");
  // no Windows o mesmo arquivo chega escrito de três jeitos: C:\pasta, C:/pasta e /c/pasta (Git Bash)
  const absoluto = (f) => {
    let a = String(f);
    if (!win) return path.resolve(a);
    if (a === "~" || /^~[\\/]/.test(a)) a = casa + a.slice(1);
    a = a.replace(/^\/([a-zA-Z])(?=\/|$)/, (_, letra) => letra.toUpperCase() + ":");
    if (/^[a-zA-Z]:$/.test(a)) a += "\\";
    return P.resolve(a);
  };
  const raizes = (lista) => lista.map((d) => caixa(P.resolve(d)));
  const R = { pastas: raizes(pastas), temp: raizes(temp), leitura: raizes(leitura) };
  const em = (arquivo, lista) => { const a = caixa(absoluto(arquivo)); return lista.some((d) => a === d || a.startsWith(d.endsWith(P.sep) ? d : d + P.sep)); };
  const bemDentro = (arquivo, lista) => { const a = caixa(absoluto(arquivo)); return lista.some((d) => a.startsWith(d.endsWith(P.sep) ? d : d + P.sep) && a !== d); };
  const segredo = (f) => (win ? SEGREDO_WIN.test(String(f).replace(/\\/g, "/")) : SEGREDO.test(String(f)));
  const segredoNoComando = (cmd) => (win ? SEGREDO_WIN.test(cmd.replace(/\\/g, "/").replace(/["'\s]+/g, "/")) : SEGREDO.test(cmd.replace(/["'\s]+/g, "/")));
  const nome = (x) => (win ? caixa(P.basename(String(x))).replace(/\.(exe|cmd|bat|com|ps1)$/, "") : path.basename(String(x)));

  // programas de um comando de terminal: um por trecho separado por && || ; | (cd e VAR=valor não contam).
  // Devolve null quando não dá para saber o que vai rodar: aí a pergunta é feita sempre.
  function programas(cmd, ps = false) {
    if (/\$\(|`|<\(/.test(cmd)) return null;                       // substituição de comando: não dá para saber, pergunta sempre
    const out = [];
    if (!win) {
      for (let seg of cmd.split(/&&|\|\||;|\||\n/)) {
        const t = seg.trim().split(/\s+/).filter((x) => !/^[A-Za-z_][A-Za-z0-9_]*=/.test(x));
        if (!t.length || !t[0] || t[0] === "cd") continue;
        const p = path.basename(t[0]);
        out.push((p === "npx" || p === "uv") && t[1] ? `${p} ${t[1]}` : p);
      }
      return out;
    }
    if (ps && /[{}]|@\(/.test(cmd)) return null;                    // bloco de script do PowerShell: pode esconder qualquer comando
    for (let t of partir(cmd, ps)) {
      t = t.filter((x) => !/^[A-Za-z_][A-Za-z0-9_]*=/.test(x));
      if (!t.length) continue;
      if (/^\$env:\w+/i.test(t[0])) continue;                       // $env:NOME = "valor"
      if (/^[$[(]/.test(t[0])) return null;                         // variável, tipo .NET ou expressão: não dá para saber
      const p = nome(t[0]);
      if (!p || MUDAM_PASTA.has(p)) continue;
      out.push((p === "npx" || p === "uv") && t[1] ? `${p} ${caixa(t[1])}` : p);
    }
    return out;
  }

  // descreve o pedido para a pessoa e diz se ele pode ganhar "permitir sempre" (e com que chaves)
  function analisar(ferramenta, entrada) {
    if (["Read", "Glob", "Grep", "LS", "NotebookRead"].includes(ferramenta)) {
      const f = String(entrada.file_path ?? entrada.path ?? entrada.notebook_path ?? "");
      const seg = segredo(f), livre = !!f && !seg && (em(f, R.pastas) || em(f, R.temp) || em(f, R.leitura));
      return { titulo: "Ler " + (f ? P.basename(f) : "arquivos"), detalhe: curto(f || JSON.stringify(entrada).slice(0, 200)), chaves: seg || !f ? null : ["leitura:" + (ferramenta === "Read" ? P.dirname(absoluto(f)) : absoluto(f))], rotuloSempre: seg || !f ? null : "Permitir sempre ler nesta pasta", perigo: seg, aviso: seg ? "Parece um arquivo de senhas ou chaves." : livre ? "" : "Fica fora das pastas de trabalho.", auto: livre };
    }
    if (["Edit", "Write", "MultiEdit", "NotebookEdit"].includes(ferramenta)) {
      const f = String(entrada.file_path ?? entrada.notebook_path ?? "");
      const ok = !!f && !segredo(f) && (em(f, R.pastas) || em(f, R.temp));
      return { titulo: (ferramenta === "Write" ? "Gravar o arquivo " : "Alterar o arquivo ") + P.basename(f), detalhe: curto(f), chaves: ok ? ["pasta:" + P.dirname(absoluto(f))] : null, rotuloSempre: ok ? "Permitir sempre nesta pasta" : null, perigo: !ok, aviso: ok ? "" : "Fica fora das pastas de trabalho.", auto: ok };
    }
    if (ferramenta === "Bash" || (win && ferramenta === "PowerShell")) {
      const cmd = String(entrada.command ?? ""), ps = programas(cmd, ferramenta === "PowerShell");
      const titulo = entrada.description ? String(entrada.description) : "Rodar um comando";
      if (!win) {
        const fora = entrada.dangerouslyDisableSandbox === true;
        const arriscado = !ps || !ps.length || ps.some((p) => ARRISCADOS.has(p.split(" ")[0]));
        return { titulo, detalhe: cmd.slice(0, 600), fora, chaves: arriscado ? null : ps.map((p) => (fora ? "fora:" : "cmd:") + p), rotuloSempre: arriscado ? null : "Permitir sempre " + [...new Set(ps)].join(", ") + (fora ? " fora da área isolada" : ""), perigo: arriscado, aviso: fora ? "Roda fora da área isolada." : "",
          auto: !arriscado && (!fora || (ps.some((p) => FORA_LIVRE.has(p)) && ps.every((p) => FORA_LIVRE.has(p) || SO_LEITURA.has(p)))) };
      }
      // Windows: sem área isolada, o cartão é a única trava. Só leitura e o render seguem direto; o resto a pessoa decide
      // (e pode dar "permitir sempre" por programa, menos para os arriscados, para senhas e para quem grava com ">").
      const senha = segredoNoComando(cmd);
      const arriscado = !ps || !ps.length || senha || redireciona(cmd) || ps.some((p) => ARRISCADOS.has(p.split(" ")[0]) || ARRISCADOS_WIN.has(p.split(" ")[0]));
      return { titulo, detalhe: cmd.slice(0, 600), fora: true, chaves: arriscado ? null : ps.map((p) => "cmd:" + p), rotuloSempre: arriscado ? null : "Permitir sempre " + [...new Set(ps)].join(", "), perigo: arriscado, aviso: senha ? "Parece mexer em senhas ou chaves." : "",
        auto: !arriscado && ps.every((p) => FORA_LIVRE.has(p) || SO_LEITURA.has(p) || SO_LEITURA_WIN.has(p)) };
    }
    if (ferramenta === "WebFetch" || ferramenta === "WebSearch") return { titulo: "Consultar a internet", detalhe: String(entrada.url ?? entrada.query ?? "").slice(0, 300), chaves: null, rotuloSempre: null, perigo: false, aviso: "" };
    return { titulo: "Usar a ferramenta " + ferramenta, detalhe: JSON.stringify(entrada).slice(0, 300), chaves: null, rotuloSempre: null, perigo: true, aviso: "" };
  }

  // o que continua recusado mesmo com autonomia ("perguntar": "nada"). Devolve o motivo, ou "" quando pode seguir.
  function bloqueio(ferramenta, entrada) {
    if (["Read", "Edit", "Write", "MultiEdit", "NotebookEdit", "NotebookRead", "Glob", "Grep", "LS"].includes(ferramenta)) {
      const f = String(entrada.file_path ?? entrada.path ?? entrada.notebook_path ?? "");
      return segredo(f) ? "arquivo de senhas ou chaves (" + curto(f) + ")" : "";
    }
    if (ferramenta !== "Bash" && !(win && ferramenta === "PowerShell")) return "";
    const cmd = String(entrada.command ?? "");
    if (/(^|[\s;&|(`])sudo(\s|$)/.test(cmd)) return "comando com sudo";
    if (/(^|[\s;&|(`])security\s/.test(cmd) || segredoNoComando(cmd)) return "comando que mexe em senhas ou chaves do computador";
    if (!win) {
      for (const seg of cmd.split(/&&|\|\||;|\||\n/)) {
        const t = palavras(seg.trim()), i = t.findIndex((x) => path.basename(x) === "rm");
        if (i < 0) continue;
        for (const a of t.slice(i + 1)) {
          if (a.startsWith("-")) continue;
          if (/^[.*~\/]*$/.test(a) || a.includes("..") || /[$`]/.test(a.replace(/^\$\{?HOME\}?/, ""))) return "apagar um caminho que não dá para conferir (" + a + ")";
          if (/^(\/|~|\$\{?HOME\}?)/.test(a)) {
            const abs = path.resolve(a.replace(/^\$\{?HOME\}?/, "~").replace(/^~(?=\/|$)/, casa));
            if (![...pastas, ...temp, "/tmp", "/var/folders"].some((d) => abs.startsWith(d + path.sep))) return "apagar fora das pastas de trabalho (" + curto(abs) + ")";
          }
        }
      }
      return "";
    }
    // Windows: não há área isolada por baixo, então estas recusas são a última trava da autonomia
    if (/(^|[\s;&|(`"'\\/])runas(\.exe)?(\s|$)/i.test(cmd) || /-Verb\s+["']?RunAs/i.test(cmd)) return "comando que pede poder de administrador";
    if (/(^|[\s;&|(`"'\\/])(cmdkey|vaultcmd)(\.exe)?(\s|$)/i.test(cmd)) return "comando que mexe em senhas ou chaves do computador";
    if (/::\s*Delete\s*\(|(^|[\s;&|(`"'\\/])(format|diskpart)(\.exe|\.com)?(\s|$)|robocopy[^|;&\n]*\s\/(mir|purge)\b/i.test(cmd)) return "comando que apaga sem dar para conferir o caminho";
    const HOME_NA_FRENTE = /^(\$\{?HOME\}?|\$env:(USERPROFILE|HOME))/i;
    const ps = ferramenta === "PowerShell";
    let saiu = false;                                               // um cd levou para fora das pastas de trabalho, ou para onde não dá para conferir
    for (const t of partir(cmd, ps)) {
      const n0 = nome(t[0]);
      if (MUDAM_PASTA.has(n0)) {
        const alvo = t.slice(1).find((a) => !a.startsWith("-"));
        const abs = alvo !== undefined && /^([a-zA-Z]:|[\\/]|~)/.test(alvo);
        if (alvo === undefined || /[$`%*]/.test(alvo) || alvo.includes("..") || alvo === "-" || (abs && !em(alvo, [...R.pastas, ...R.temp]))) saiu = true;
        continue;
      }
      if (TERMINAIS.has(n0) && t.slice(1).some((a) => APAGA_NO_TEXTO.test(a))) return "apagar por dentro de outro terminal, onde não dá para conferir o caminho";
      const i = t.findIndex((x) => APAGAM_WIN.has(nome(x)));
      if (i < 0) continue;
      const alvos = t.slice(i + 1).filter((a) => !a.startsWith("-")).flatMap((a) => (ps ? a.split(",") : [a])).filter(Boolean);
      if (!alvos.length) return "apagar sem dizer o caminho (o que vem de outro comando não dá para conferir)";
      for (const a of alvos) {
        const resto = a.replace(HOME_NA_FRENTE, "");
        if (/^[.*~\/\\]*$/.test(a) || a.includes("..") || /[$`%]/.test(resto)) return "apagar um caminho que não dá para conferir (" + a + ")";
        if (HOME_NA_FRENTE.test(a) || /^([a-zA-Z]:|[\\/]|~)/.test(a)) {
          const alvo = a.replace(HOME_NA_FRENTE, "~");
          if (!bemDentro(alvo, [...R.pastas, ...R.temp])) return "apagar fora das pastas de trabalho (" + curto(absoluto(alvo)) + ")";
        } else if (saiu) return "apagar depois de sair das pastas de trabalho (" + a + ")";
      }
    }
    return "";
  }

  return { analisar, bloqueio, programas, curto, caixa, sep: P.sep };
}
