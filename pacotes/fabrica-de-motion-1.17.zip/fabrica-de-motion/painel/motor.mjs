// Motor do FM: a conversa de cada cliente é uma sessão do Claude Code em segundo plano (claude -p), SEMPRE supervisionada.
//
// Três travas, nesta ordem:
//  1. Área isolada: os comandos rodam no sandbox do Claude Code (isolado.json) e só gravam nas pastas de trabalho.
//  2. Permissão: a sessão roda no modo "default". Gravar arquivo, sair da área isolada (o render precisa) ou acessar a
//     internet gera um pedido que aparece no painel; quem decide é a pessoa, pelos botões Permitir / Negar.
//  3. "Permitir sempre" vale só para aquele cliente, só para aquela pasta ou aquele programa, e nunca é oferecido para
//     ações arriscadas (apagar, rede, git, fora das pastas de trabalho).
// Sem resposta, a ação é negada. Conversas ficam em chats/<id>.json. Ajustes opcionais em motor.json.
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const CHATS = path.join(HERE, "chats");
const lerJson = (p, padrao) => { try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return padrao; } };
const casa = (p) => (typeof p === "string" ? p.replace(/^~(?=\/|$)/, os.homedir()) : p);
const CFG = lerJson(path.join(HERE, "motor.json"), {});
const SKILL = path.join(os.homedir(), ".claude", "skills", "fabrica-de-motion");
const SKILL_CFG = lerJson(path.join(SKILL, "config.json"), {});

// No Windows a conversa ao vivo fica desligada (o painel cai no modo recado): lá o Claude Code não tem área isolada,
// e esse caminho ainda não foi testado. Para experimentar por sua conta: "aoVivoNoWindows": true em motor.json.
const WIN = process.platform === "win32";
const BIN = WIN && CFG.aoVivoNoWindows !== true ? undefined
  : [casa(CFG.bin), path.join(os.homedir(), ".local/bin/claude"), "/opt/homebrew/bin/claude", "/usr/local/bin/claude",
    ...(WIN ? [path.join(os.homedir(), ".local", "bin", "claude.exe"), path.join(os.homedir(), ".local", "node_modules", "@anthropic-ai", "claude-code", "bin", "claude.exe"),
      path.join(process.env.APPDATA ?? "", "npm", "node_modules", "@anthropic-ai", "claude-code", "bin", "claude.exe")] : [])].find((p) => p && fs.existsSync(p));
const MODELO = CFG.modelo ?? "opus";
const RAIZ = casa(CFG.raiz) ?? path.resolve(HERE, "..");
// pastas de trabalho: onde a sessão pode ler e, com permissão, gravar
const PASTAS = [...new Set([RAIZ, ...(CFG.pastas ?? []), SKILL_CFG.template, SKILL_CFG.projetos, SKILL_CFG.entregas, SKILL_CFG.entregas_antigas, SKILL_CFG.painel].map(casa).filter((p) => p && fs.existsSync(p)).map((p) => fs.realpathSync(p)))];
const SOLEITURA = [SKILL, ...(CFG.leitura ?? []).map(casa)].filter((p) => p && fs.existsSync(p));
const SIMULTANEOS = CFG.simultaneos ?? 3;
// programas que nunca ganham "permitir sempre": cada uso é perguntado
const ARRISCADOS = new Set(["rm", "sudo", "curl", "wget", "ssh", "scp", "rsync", "git", "osascript", "open", "kill", "killall", "pkill", "chmod", "chown", "dd", "launchctl", "defaults", "security", "brew", "npm", "pip", "pip3", "mv", "nc", "sh", "bash", "zsh", "eval", "xargs", "find"]);

// "perguntar" em motor.json: "arriscado" (padrão) só mostra o cartão para o que foge do trabalho normal; "tudo" pergunta
// cada gravação e cada comando fora da área isolada; "nada" dá autonomia: nenhum cartão aparece, e só o que está em
// bloqueio() é recusado, sem pergunta (sudo, arquivos de senha ou chave, apagar fora das pastas de trabalho).
const PERGUNTAR = ["tudo", "arriscado", "nada"].includes(CFG.perguntar) ? CFG.perguntar : "arriscado";
const TEMP = [...new Set(["/private/tmp", "/tmp", "/private/var/folders", os.tmpdir()].map((p) => { try { return fs.realpathSync(p); } catch { return p; } }))];
const LEITURA = [...SOLEITURA, path.join(os.homedir(), "Downloads"), path.join(os.homedir(), ".claude", "skills"), path.join(os.homedir(), ".claude", "projects")];
const SEGREDO = /(^|\/)(\.ssh|\.aws|\.gnupg|\.netrc|\.env[^/]*|Keychains|\.credentials\.json|id_rsa[^/]*|\.config\/gh|\.config\/fabrica-de-motion)(\/|$)/;
const em = (arquivo, raizes) => { const a = path.resolve(arquivo); return raizes.some((d) => a === d || a.startsWith(d + path.sep)); };
// fora da área isolada, só o que o trabalho de vídeo realmente precisa roda sem pergunta; o resto do comando tem de ser só leitura
const FORA_LIVRE = new Set(CFG.foraLivre ?? ["npx remotion", "avconvert"]);
const SO_LEITURA = new Set(["tail", "head", "grep", "ls", "cat", "ffprobe", "echo", "wc", "cut", "sort", "tr", "true"]);

let PORTA = 4310, SENHA = "";
export const iniciarMotor = ({ porta, senha }) => { PORTA = porta; SENHA = senha; };

const vivos = new Map();      // id → { proc, status, desde, parado }
const pedidos = new Map();    // id → [{ n, ferramenta, entrada, info, responder }]
let contador = 0;
const arq = (id) => path.join(CHATS, `${id}.json`);
const ler = (id) => memoria.get(id) ?? lerJson(arq(id), { sessao: null, sempre: [], msgs: [] });
// gravar nunca derruba o painel: se o disco encher, a conversa segue na memória e o aviso aparece na tela
const memoria = new Map();
let erroDisco = "";
const gravar = (id, c) => {
  memoria.set(id, c);
  try { fs.mkdirSync(CHATS, { recursive: true }); fs.writeFileSync(arq(id) + ".tmp", JSON.stringify(c, null, 1)); fs.renameSync(arq(id) + ".tmp", arq(id)); memoria.delete(id); erroDisco = ""; }
  catch (e) { erroDisco = e.code === "ENOSPC" ? "O disco do computador está cheio: libere espaço. A conversa continua, mas não está sendo salva." : "Não consegui salvar a conversa: " + e.message; }
};
const juntar = (id, msg) => { const c = ler(id); c.msgs.push({ n: (c.msgs.at(-1)?.n ?? 0) + 1, quando: new Date().toISOString(), ...msg }); gravar(id, c); return c; };
const curto = (p) => String(p).replace(os.homedir(), "~");
const dentro = (arquivo) => { const a = path.resolve(arquivo); return PASTAS.some((d) => a === d || a.startsWith(d + path.sep)); };

// programas de um comando de terminal: um por trecho separado por && || ; | (cd e VAR=valor não contam)
function programas(cmd) {
  if (/\$\(|`|<\(/.test(cmd)) return null;                       // substituição de comando: não dá para saber, pergunta sempre
  const out = [];
  for (let seg of cmd.split(/&&|\|\||;|\||\n/)) {
    const t = seg.trim().split(/\s+/).filter((x) => !/^[A-Za-z_][A-Za-z0-9_]*=/.test(x));
    if (!t.length || !t[0] || t[0] === "cd") continue;
    const p = path.basename(t[0]);
    out.push((p === "npx" || p === "uv") && t[1] ? `${p} ${t[1]}` : p);
  }
  return out;
}
// descreve o pedido para a pessoa e diz se ele pode ganhar "permitir sempre" (e com que chaves)
function analisar(ferramenta, entrada) {
  if (["Read", "Glob", "Grep", "LS", "NotebookRead"].includes(ferramenta)) {
    const f = String(entrada.file_path ?? entrada.path ?? entrada.notebook_path ?? "");
    const segredo = SEGREDO.test(f), livre = !!f && !segredo && (dentro(f) || em(f, TEMP) || em(f, LEITURA));
    return { titulo: "Ler " + (f ? path.basename(f) : "arquivos"), detalhe: curto(f || JSON.stringify(entrada).slice(0, 200)), chaves: segredo || !f ? null : ["leitura:" + (ferramenta === "Read" ? path.dirname(path.resolve(f)) : path.resolve(f))], rotuloSempre: segredo || !f ? null : "Permitir sempre ler nesta pasta", perigo: segredo, aviso: segredo ? "Parece um arquivo de senhas ou chaves." : livre ? "" : "Fica fora das pastas de trabalho.", auto: livre };
  }
  if (["Edit", "Write", "MultiEdit", "NotebookEdit"].includes(ferramenta)) {
    const f = String(entrada.file_path ?? entrada.notebook_path ?? "");
    const ok = !!f && !SEGREDO.test(f) && (dentro(f) || em(f, TEMP));
    return { titulo: (ferramenta === "Write" ? "Gravar o arquivo " : "Alterar o arquivo ") + path.basename(f), detalhe: curto(f), chaves: ok ? ["pasta:" + path.dirname(path.resolve(f))] : null, rotuloSempre: ok ? "Permitir sempre nesta pasta" : null, perigo: !ok, aviso: ok ? "" : "Fica fora das pastas de trabalho.", auto: ok };
  }
  if (ferramenta === "Bash") {
    const cmd = String(entrada.command ?? ""), fora = entrada.dangerouslyDisableSandbox === true, ps = programas(cmd);
    const arriscado = !ps || !ps.length || ps.some((p) => ARRISCADOS.has(p.split(" ")[0]));
    return { titulo: entrada.description ? String(entrada.description) : "Rodar um comando", detalhe: cmd.slice(0, 600), fora, chaves: arriscado ? null : ps.map((p) => (fora ? "fora:" : "cmd:") + p), rotuloSempre: arriscado ? null : "Permitir sempre " + [...new Set(ps)].join(", ") + (fora ? " fora da área isolada" : ""), perigo: arriscado, aviso: fora ? "Roda fora da área isolada." : "",
      auto: !arriscado && (!fora || (ps.some((p) => FORA_LIVRE.has(p)) && ps.every((p) => FORA_LIVRE.has(p) || SO_LEITURA.has(p)))) };
  }
  if (ferramenta === "WebFetch" || ferramenta === "WebSearch") return { titulo: "Consultar a internet", detalhe: String(entrada.url ?? entrada.query ?? "").slice(0, 300), chaves: null, rotuloSempre: null, perigo: false, aviso: "" };
  return { titulo: "Usar a ferramenta " + ferramenta, detalhe: JSON.stringify(entrada).slice(0, 300), chaves: null, rotuloSempre: null, perigo: true, aviso: "" };
}

// separa um trecho de comando em palavras respeitando aspas e barra invertida (caminhos com espaço ficam inteiros)
function palavras(trecho) {
  const out = []; let atual = "", aspas = "", tem = false;
  for (let i = 0; i < trecho.length; i++) {
    const ch = trecho[i];
    if (aspas) { if (ch === aspas) aspas = ""; else if (ch === "\\" && aspas === '"' && i + 1 < trecho.length) atual += trecho[++i]; else atual += ch; }
    else if (ch === '"' || ch === "'") { aspas = ch; tem = true; }
    else if (ch === "\\" && i + 1 < trecho.length) { atual += trecho[++i]; tem = true; }
    else if (/\s/.test(ch)) { if (atual || tem) out.push(atual); atual = ""; tem = false; }
    else atual += ch;
  }
  if (atual || tem) out.push(atual);
  return out;
}
// o que continua recusado mesmo com autonomia ("perguntar": "nada"). Devolve o motivo, ou "" quando pode seguir.
function bloqueio(ferramenta, entrada) {
  if (["Read", "Edit", "Write", "MultiEdit", "NotebookEdit", "NotebookRead", "Glob", "Grep", "LS"].includes(ferramenta)) {
    const f = String(entrada.file_path ?? entrada.path ?? entrada.notebook_path ?? "");
    return SEGREDO.test(f) ? "arquivo de senhas ou chaves (" + curto(f) + ")" : "";
  }
  if (ferramenta !== "Bash") return "";
  const cmd = String(entrada.command ?? "");
  if (/(^|[\s;&|(`])sudo(\s|$)/.test(cmd)) return "comando com sudo";
  if (/(^|[\s;&|(`])security\s/.test(cmd) || SEGREDO.test(cmd.replace(/["'\s]+/g, "/"))) return "comando que mexe em senhas ou chaves do computador";
  for (const seg of cmd.split(/&&|\|\||;|\||\n/)) {
    const t = palavras(seg.trim()), i = t.findIndex((x) => path.basename(x) === "rm");
    if (i < 0) continue;
    for (const a of t.slice(i + 1)) {
      if (a.startsWith("-")) continue;
      if (/^[.*~\/]*$/.test(a) || a.includes("..") || /[$`]/.test(a.replace(/^\$\{?HOME\}?/, ""))) return "apagar um caminho que não dá para conferir (" + a + ")";
      if (/^(\/|~|\$\{?HOME\}?)/.test(a)) {
        const abs = path.resolve(casa(a.replace(/^\$\{?HOME\}?/, "~")));
        if (![...PASTAS, ...TEMP, "/tmp", "/var/folders"].some((d) => abs.startsWith(d + path.sep))) return "apagar fora das pastas de trabalho (" + curto(abs) + ")";
      }
    }
  }
  return "";
}

// chamado pelo servidor quando o aprovador (aprovador.mjs) traz um pedido do Claude; resolve quando a pessoa decide
export function pedirPermissao(id, ferramenta, entrada) {
  const info = analisar(ferramenta, entrada);
  const viva = vivos.get(id); if (viva) viva.pedidos = (viva.pedidos ?? 0) + 1;
  if (PERGUNTAR === "nada") {
    const motivo = bloqueio(ferramenta, entrada);
    if (!motivo) return Promise.resolve({ behavior: "allow" });
    juntar(id, { quem: "sistema", texto: "Bloqueei sem perguntar: " + motivo + ". O resto do trabalho segue." });
    return Promise.resolve({ behavior: "deny", message: "Bloqueado por regra fixa do painel: " + motivo + ". Não tente por outro caminho. Siga o trabalho sem isso e, se for mesmo necessário, explique à pessoa o que precisava." });
  }
  const c = ler(id);
  if (PERGUNTAR !== "tudo" && info.auto) return Promise.resolve({ behavior: "allow" });   // trabalho normal, dentro das pastas: segue sem cartão
  if (info.chaves && info.chaves.every((k) => (c.sempre ?? []).some((s) => s === k || ((k.startsWith("pasta:") || k.startsWith("leitura:")) && s.split(":")[0] === k.split(":")[0] && (k + path.sep).startsWith(s + path.sep))))) return Promise.resolve({ behavior: "allow" });
  if (!vivos.has(id)) return Promise.resolve({ behavior: "deny", message: "A conversa deste cliente não está ativa no painel." });
  return new Promise((responder) => {
    const fila = pedidos.get(id) ?? []; pedidos.set(id, fila);
    fila.push({ n: ++contador, ferramenta, entrada, info, responder });
  });
}
// decisão da pessoa no painel: "uma" (só esta vez), "sempre" (guarda a chave para este cliente) ou "negar"
export function decidir(id, n, decisao) {
  const fila = pedidos.get(id) ?? [], i = fila.findIndex((p) => p.n === n);
  if (i < 0) return false;
  const [p] = fila.splice(i, 1);
  if (decisao === "sempre" && p.info.chaves) { const c = ler(id); c.sempre = [...new Set([...(c.sempre ?? []), ...p.info.chaves])]; gravar(id, c); }
  if (decisao === "negar") juntar(id, { quem: "sistema", texto: "Você negou: " + p.info.titulo + "." });
  p.responder(decisao === "negar" ? { behavior: "deny", message: "A pessoa negou esta ação no painel. Não tente fazer a mesma coisa por outro caminho; explique o que precisava e pergunte como seguir." } : { behavior: "allow" });
  return true;
}
const negarTudo = (id, motivo) => { for (const p of pedidos.get(id) ?? []) p.responder({ behavior: "deny", message: motivo }); pedidos.delete(id); };

export const motorInfo = () => ({ ok: !!BIN, modelo: MODELO, perguntar: PERGUNTAR, rodando: [...vivos.keys()], pastas: PASTAS.map(curto), aviso: erroDisco,
  ativos: [...vivos.entries()].map(([id, v]) => ({ id, status: v.status, desde: v.desde, pedido: (pedidos.get(id)?.length ?? 0) > 0 })) });
// ao ligar o painel: conversa que estava no meio de um trabalho quando ele caiu ganha um aviso para ser retomada
export function retomarInterrompidas() {
  let n = 0;
  try {
    for (const f of fs.readdirSync(CHATS).filter((x) => /^\.mcp-.+\.json$/.test(x))) {
      const id = f.slice(5, -5);
      try { fs.rmSync(path.join(CHATS, f), { force: true }); } catch {}
      juntar(id, { quem: "sistema", texto: "O painel saiu do ar no meio deste trabalho e foi religado. O que já estava salvo continua; escreva \"continue\" para o Claude retomar de onde parou." }); n++;
    }
  } catch {}
  return n;
}
export function lerChat(id) {
  const c = ler(id), v = vivos.get(id), p = (pedidos.get(id) ?? [])[0];
  return { msgs: c.msgs, hist: c.hist ?? null, aviso: erroDisco, rodando: !!v, status: v?.status ?? "", desde: v?.desde ?? null, diag: v ? { ...v.diag, pedidos: v.pedidos ?? 0 } : null, sempre: (c.sempre ?? []).map((s) => curto(s.replace(/^\w+:/, (m) => ({ "pasta:": "pasta ", "leitura:": "ler ", "cmd:": "comando ", "fora:": "fora da área isolada: " }[m] ?? m)))),
    pedido: p ? { n: p.n, titulo: p.info.titulo, detalhe: p.info.detalhe, aviso: p.info.aviso, perigo: !!p.info.perigo, sempre: p.info.rotuloSempre, outros: (pedidos.get(id)?.length ?? 1) - 1 } : null };
}
export const esquecerPermissoes = (id) => { const c = ler(id); c.sempre = []; gravar(id, c); return true; };
export const parar = (id) => { const v = vivos.get(id); if (!v) return false; v.parado = true; negarTudo(id, "A conversa foi parada."); v.proc.kill("SIGTERM"); setTimeout(() => { try { v.proc.kill("SIGKILL"); } catch {} }, 4000); return true; };

const resumoFerramenta = (b) => {
  const i = b.input ?? {};
  if (b.name === "Bash") return i.description || "rodando um comando";
  if (b.name === "Edit" || b.name === "Write") return "escrevendo " + path.basename(i.file_path ?? "arquivo");
  if (b.name === "Read") return "lendo " + path.basename(i.file_path ?? "arquivo");
  if (b.name === "Skill") return "abrindo o método";
  return b.name.replace(/^mcp__fm__/, "");
};

// limite de uso do plano do Claude: vira um aviso em português, com a hora em que volta e o que fazer
const LIMITE = /hit your (session|usage|weekly|\w+ )?limit|usage limit reached/i;
const avisoDeLimite = (t) => {
  if (!LIMITE.test(t)) return null;
  const volta = /resets?\s+(?:at\s+)?([^·(\n]+?)(?:\s*\(|$)/i.exec(t)?.[1]?.trim();
  return "O limite de uso do seu plano do Claude foi atingido" + (volta ? " e volta às " + volta : "") + ". Nada se perdeu: o que já estava pronto continua salvo. Quando o limite voltar, escreva \"continue\" aqui. O limite é o da conta em que o Claude de terminal está logado neste computador.";
};
export function enviarMensagem({ id, nome, texto, anexos = [], refs = [], hist = 0 }) {
  if (!BIN) return { erro: "O Claude Code de terminal não foi encontrado neste computador.", status: 503 };
  if (vivos.has(id)) return { erro: "O Claude ainda está trabalhando neste cliente. Espere terminar ou aperte Parar.", status: 409 };
  if (vivos.size >= SIMULTANEOS) return { erro: `Já há ${vivos.size} clientes em andamento. Espere um terminar.`, status: 429 };
  const conv = juntar(id, { quem: "voce", texto, anexos, ...(refs.length ? { refs: refs.map(({ nome: n, url, thumb, tipo, cliente }) => ({ nome: n, url, thumb, tipo, cliente })) } : {}) });
  if (conv.hist == null) { conv.hist = hist; gravar(id, conv); }      // quantas linhas do fichário já existiam antes da primeira mensagem pelo painel
  const caminhos = anexos.map((a) => path.join(HERE, a));
  const corpo = texto + (caminhos.length ? "\n\nArquivos enviados agora (material deste cliente; copie para a pasta src do cliente antes de usar):\n" + caminhos.map((p) => "- " + p).join("\n") : "")
    + (refs.length ? "\n\nReferências escolhidas no painel (vídeos que já fizemos: use o estilo, o ritmo e as soluções deles como base, adaptando à identidade deste cliente, sem copiar):\n" + refs.map((r) => `- ${r.arquivo} (feito para ${r.cliente}${r.codigo?.length ? "; código: " + r.codigo.join(", ") : ""})`).join("\n") : "");
  const prompt = conv.sessao ? corpo : [
    `Você está atendendo pelo painel do FM (Fábrica de Motion). Esta conversa é só do cliente "${nome}" (id ${id}).`,
    `Siga a skill fabrica-de-motion. Antes de qualquer coisa, rode: python3 ~/.claude/skills/fabrica-de-motion/cliente.py abrir ${id}`,
    ...(CFG.preferencias ? [`Leia também as preferências do dono em ${casa(CFG.preferencias)} antes de criar qualquer vídeo.`] : []),
    "Regras desta conversa:",
    "- Não mexa em arquivos de outros clientes. Outras conversas podem estar trabalhando ao mesmo tempo no mesmo projeto de vídeo: edite só a pasta deste cliente e, no arquivo de registro das composições, acrescente apenas as linhas dele.",
    PERGUNTAR === "nada"
      ? "- Você tem autonomia: nada vira pedido de permissão, então não pare para pedir licença; decida e siga. Só três coisas são recusadas na hora, sem pergunta: sudo, arquivos de senha ou chave, e apagar fora das pastas de trabalho. Versão antiga de entrega nunca se apaga."
      : "- Trabalho normal dentro das pastas do projeto, do cliente e das entregas segue direto. O que foge disso (apagar, rede, git, arquivos fora dessas pastas) vira um pedido de permissão no painel; se a pessoa negar, não tente por outro caminho: explique o que precisava e pergunte como seguir.",
    "- Seus comandos rodam numa área isolada. O render do Remotion não abre o navegador dentro dela: quando falhar por isso, repita o mesmo comando fora dela.",
    "- Responda em português do Brasil, curto e direto, sem tabelas largas (a tela é estreita).",
    "- Entrega nova vai para a pasta do cliente dentro da pasta de entregas (a ficha mostra o caminho exato em \"Onde está cada coisa\"). Ao entregar, escreva o nome exato do arquivo: o painel mostra o vídeo sozinho.",
    "- Você não ouve áudio: diga isso quando entregar vídeo com som.",
    "", "Mensagem do usuário:", corpo,
  ].join("\n");

  const mcp = path.join(CHATS, `.mcp-${id}.json`);
  try { fs.mkdirSync(CHATS, { recursive: true }); fs.writeFileSync(mcp, JSON.stringify({ mcpServers: { fm: { command: process.execPath, args: [path.join(HERE, "aprovador.mjs")], env: { FM_PORTA: String(PORTA), FM_ID: id, FM_SENHA: SENHA } } } }), { mode: 0o600 }); }
  catch (e) { juntar(id, { quem: "sistema", texto: "Não consegui começar: " + (e.code === "ENOSPC" ? "o disco do computador está cheio." : e.message) }); return { ok: true }; }
  const args = ["-p", "--model", MODELO, "--permission-mode", "default", "--settings", path.join(HERE, "isolado.json"), "--mcp-config", mcp, "--strict-mcp-config", "--permission-prompt-tool", "mcp__fm__aprovar",
    "--output-format", "stream-json", "--verbose", ...(conv.sessao ? ["--resume", conv.sessao] : []), ...[...PASTAS.filter((d) => d !== RAIZ), ...SOLEITURA].flatMap((d) => ["--add-dir", d])];
  const env = { ...process.env, MCP_TOOL_TIMEOUT: "3600000", PATH: [process.env.PATH, "/opt/homebrew/bin", "/usr/local/bin", path.join(os.homedir(), ".local/bin")].filter(Boolean).join(":") };
  if (!CFG.usarChaveApi) delete env.ANTHROPIC_API_KEY;                // por padrão usa o login do Claude Code, não uma chave paga por uso
  const proc = spawn(BIN, args, { cwd: RAIZ, env, stdio: ["pipe", "pipe", "pipe"] });
  const v = { proc, status: "começando", desde: Date.now(), parado: false };
  vivos.set(id, v);
  proc.stdin.end(prompt);

  let resto = "", terminou = false, erros = "";
  const linha = (l) => {
    let d; try { d = JSON.parse(l); } catch { return; }
    if (d.session_id) { const c = ler(id); if (c.sessao !== d.session_id) { c.sessao = d.session_id; gravar(id, c); } }
    if (d.type === "system" && d.subtype === "init") {
      // trava de segurança: se a sessão não subiu no modo supervisionado, com o aprovador ligado, ela é encerrada na hora
      const aprovador = (d.mcp_servers ?? []).find((m) => m.name === "fm")?.status;
      v.diag = { modo: d.permissionMode, aprovador };
      if (d.permissionMode !== "default" || aprovador !== "connected") {
        v.abortada = `modo "${d.permissionMode}", aprovador "${aprovador ?? "ausente"}"`;
        negarTudo(id, "Sessão sem supervisão."); proc.kill("SIGKILL");
      }
    } else if (d.type === "assistant") {
      for (const b of d.message?.content ?? []) {
        if (b.type === "text" && b.text.trim() && !LIMITE.test(b.text)) { juntar(id, { quem: "claude", texto: b.text.trim() }); v.status = "escrevendo"; }
        if (b.type === "tool_use") v.status = resumoFerramenta(b);
      }
    } else if (d.type === "system" && d.subtype === "task_summary" && d.detail && d.detail !== "None") {
      v.status = String(d.detail).slice(0, 90);
    } else if (d.type === "result") {
      terminou = true;
      if (d.is_error) juntar(id, { quem: "sistema", texto: avisoDeLimite(String(d.result ?? "")) ?? "Não consegui concluir: " + String(d.result ?? d.subtype ?? "erro").slice(0, 600) });
    }
  };
  proc.stdout.on("data", (buf) => { resto += buf; const ls = resto.split("\n"); resto = ls.pop(); ls.forEach(linha); });
  proc.stderr.on("data", (buf) => { erros = (erros + buf).slice(-800); });
  proc.on("error", (e) => { erros += e.message; });
  proc.on("close", (cod) => {
    if (resto.trim()) linha(resto);
    vivos.delete(id); negarTudo(id, "A conversa terminou.");
    try { fs.rmSync(mcp, { force: true }); } catch {}
    if (v.abortada) juntar(id, { quem: "sistema", texto: "Interrompi a sessão antes de ela fazer qualquer coisa: a supervisão não ficou ativa (" + v.abortada + "). Nada foi executado." });
    else if (v.parado) juntar(id, { quem: "sistema", texto: "Parado por você. O que já estava pronto continua salvo; é só mandar a próxima mensagem." });
    else if (!terminou) juntar(id, { quem: "sistema", texto: "A sessão terminou sem resposta" + (cod ? ` (código ${cod})` : "") + (erros.trim() ? ": " + erros.trim().split("\n").at(-1).slice(0, 300) : ".") });
  });
  return { ok: true };
}
